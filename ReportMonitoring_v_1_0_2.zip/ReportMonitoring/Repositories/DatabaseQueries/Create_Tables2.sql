﻿CREATE TABLE Sektor (
	Id int not null PRIMARY KEY IDENTITY,
	Sektor nvarchar(255) not null
)
GO
CREATE TABLE PredaniIzvjestaji (
	Id int not null PRIMARY KEY IDENTITY,
	FilePath nvarchar(255) not null,
	ReportId int not null,
    ReportVersionId int not null,
	VrstaSubjektaNadzoraId int not null FOREIGN KEY REFERENCES VrstaSubjektaNadzora(Id),
    ImeIzvjestaja nvarchar(255) not null,
	TipObrascaId int not null FOREIGN KEY REFERENCES TipObrasca(Id),
	VrijemePredaje datetime2(0) not null,
	KorisnikId int not null,
	KorisnikNaziv nvarchar(255) not null,
	Status int not null default(1)
)
GO
CREATE TABLE IzvjesceSektor (
    IzvjesceId int not null,
    SektorId int not null FOREIGN KEY REFERENCES Sektor(Id)
)
GO