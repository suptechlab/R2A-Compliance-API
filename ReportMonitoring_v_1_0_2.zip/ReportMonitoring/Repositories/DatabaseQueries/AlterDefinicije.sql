﻿ALTER TABLE [DefinicijeIzvjesca] ADD IdIzvjesca int null;
ALTER TABLE [DefinicijeIzvjesca] ADD Naziv nvarchar(500) null;
ALTER TABLE [DefinicijeIzvjesca] ADD Digitalni bit not null default 0;

ALTER TABLE [DefinicijeIzvjesca] ADD RedBr int null default 0;