﻿
CREATE TABLE  [dbo].[ViewPrijevodi] (
	ViewName nvarchar(100) NOT NULL,
	[Key]      nvarchar(32) NOT NULL,
	Name    nvarchar(256)
);
ALTER TABLE [dbo].[ViewPrijevodi]
ADD CONSTRAINT PK_ViewPrijevodi PRIMARY KEY NONCLUSTERED (ViewName,[Key]);
GO

INSERT INTO [dbo].[ViewPrijevodi]VALUES ('[BP2].[Supervision].[InstitutionSubType]','1','Zadruga');
INSERT INTO [dbo].[ViewPrijevodi]VALUES ('[BP2].[Supervision].[InstitutionSubType]','2','Udruga');
INSERT INTO [dbo].[ViewPrijevodi]VALUES ('[BP2].[Supervision].[InstitutionSubType]','3','Trgovacko društvo');
INSERT INTO [dbo].[ViewPrijevodi]VALUES ('[BP2].[Supervision].[InstitutionSubType]','4','Javno trgovacko društvo');
INSERT INTO [dbo].[ViewPrijevodi]VALUES ('[BP2].[Supervision].[InstitutionSubType]','5','Gospodarsko interesno udruženje');
INSERT INTO [dbo].[ViewPrijevodi]VALUES ('[BP2].[Supervision].[InstitutionSubType]','6','Dionicko društvo (d.d.)');
INSERT INTO [dbo].[ViewPrijevodi]VALUES ('[BP2].[Supervision].[InstitutionSubType]','7','Društvo s ogranicenom odgovornošcu (d.o.o.)');
INSERT INTO [dbo].[ViewPrijevodi]VALUES ('[BP2].[Supervision].[InstitutionSubType]','8','Jednostavno društvo s ogranicenom odgovornošcu (j.d.o.o.)');
INSERT INTO [dbo].[ViewPrijevodi]VALUES ('[BP2].[Supervision].[InstitutionSubType]','9','Javna ustanova');
INSERT INTO [dbo].[ViewPrijevodi]VALUES ('[BP2].[Supervision].[InstitutionSubType]','10','Privatna ustanova');
INSERT INTO [dbo].[ViewPrijevodi]VALUES ('[BP2].[Supervision].[InstitutionSubType]','11','Nedefinirano');

INSERT INTO [dbo].[ViewPrijevodi]VALUES ('[BP2].[Supervision].[FundType]','1','investicijski');
INSERT INTO [dbo].[ViewPrijevodi]VALUES ('[BP2].[Supervision].[FundType]','2','mirovinski');
INSERT INTO [dbo].[ViewPrijevodi]VALUES ('[BP2].[Supervision].[FundType]','3','ostali');

INSERT INTO [dbo].[ViewPrijevodi]VALUES ('[BP2].[Supervision].[FundSubType]','1','UCITS');
INSERT INTO [dbo].[ViewPrijevodi]VALUES ('[BP2].[Supervision].[FundSubType]','2','AIF');
INSERT INTO [dbo].[ViewPrijevodi]VALUES ('[BP2].[Supervision].[FundSubType]','3','Obavezan');
INSERT INTO [dbo].[ViewPrijevodi]VALUES ('[BP2].[Supervision].[FundSubType]','4','Dobrovoljan');
GO

CREATE VIEW [dbo].[RelevantBusinessEntityTypeView1] AS
SELECT [Id] as Value , [Name] as Text
FROM  [BP2].[Supervision].[RelevantBusinessEntityType]
WHERE Id in (13,14,18)
GO

CREATE VIEW [dbo].[RelevantBusinessEntityTypeView2] AS
SELECT [Id] as Value , [Name] as Text
FROM  [BP2].[Supervision].[RelevantBusinessEntityType]
WHERE Id in (13,14,18,43)
GO

CREATE VIEW [dbo].[RelevantBusinessEntityTypeView3] AS
SELECT [Id] as Value , [Name] as Text
FROM  [BP2].[Supervision].[RelevantBusinessEntityType]
WHERE Id in (8,9,10)
GO

CREATE VIEW [dbo].[InstitutionTypeView] AS
SELECT [Id] as Value , [Name] as Text
FROM  [BP2].[Supervision].[InstitutionType]
GO

-- potrebno prevesti
CREATE VIEW [dbo].[InstitutionSubTypeView] AS
SELECT [Id] as Value ,ISNULL(t.[Name],v.[Name]) as Text
FROM  [BP2].[Supervision].[InstitutionSubType] as v 
LEFT JOIN [dbo].[ViewPrijevodi] t ON t.ViewName = '[BP2].[Supervision].[InstitutionSubType]' AND t.[Key] = v.Id
GO
-- potrebno prevesti
CREATE VIEW [dbo].[FundTypeView] AS
SELECT [Id] as Value ,ISNULL(t.[Name],v.[Name]) as Text
FROM  [BP2].[Supervision].[FundType] as v
LEFT JOIN [dbo].[ViewPrijevodi] t ON t.ViewName = '[BP2].[Supervision].[FundType]' AND t.[Key] = v.Id
GO

-- potrebno prevesti
CREATE VIEW [dbo].[FundSubTypeView] AS
SELECT [Id] as Value , ISNULL(t.[Name], v.[Name]) as Text
FROM  [BP2].[Supervision].[FundSubType] as v
LEFT JOIN [dbo].[ViewPrijevodi] t ON t.ViewName = '[BP2].[Supervision].[FundSubType]' AND t.[Key] = v.Id
GO

CREATE VIEW [dbo].[CountryView] AS
SELECT [Id] as Value , [Name] as Text
FROM  [BP2].[Location].[Country]
GO

CREATE VIEW [dbo].[ActivityPermitRegisterTypeView1] AS
SELECT ap.[Code] AS Value,
       CONCAT(ap.[CODE],' ',ap.[Name]) as Text
         
  FROM [BP2].[Supervision].[ActivityPermit] ap
  inner join [BP2].[Supervision].[ActivityPermitRegisterType] aprt on 
             ap.Id = aprt.ActivityPermitId
  inner join [BP2].[Supervision].[RegisterType] rt on rt.Id = aprt.RegisterTypeId
  where ap.RowDeleted = 0 and rt.RowDeleted = 0 and rt.Id = 19
GO

CREATE VIEW [dbo].[ActivityPermitRegisterTypeView2] AS
SELECT ap.[Code] AS Value,
       CONCAT(ap.[CODE],' ',ap.[Name]) as Text
         
  FROM [BP2].[Supervision].[ActivityPermit] ap
  inner join [BP2].[Supervision].[ActivityPermitRegisterType] aprt on 
             ap.Id = aprt.ActivityPermitId
  inner join [BP2].[Supervision].[RegisterType] rt on rt.Id = aprt.RegisterTypeId
  where ap.RowDeleted = 0 and rt.RowDeleted = 0 and rt.Id = 18
GO


CREATE VIEW [dbo].[ActivityPermitRegisterTypeView3] AS
 SELECT ap.[Code] AS Value,
       CONCAT(ap.[CODE],' ',ap.[Name]) as Text
         
  FROM [BP2].[Supervision].[ActivityPermit] ap
  inner join [BP2].[Supervision].[ActivityPermitRegisterType] aprt on 
             ap.Id = aprt.ActivityPermitId
  inner join [BP2].[Supervision].[RegisterType] rt on rt.Id = aprt.RegisterTypeId
  where ap.RowDeleted = 0 and rt.RowDeleted = 0 and rt.Id = 23
GO

CREATE VIEW [dbo].[ActivityPermitRegisterTypeView4] AS
 SELECT ap.[Code] AS Value,
       CONCAT(ap.[CODE],' ',ap.[Name]) as Text
         
  FROM [BP2].[Supervision].[ActivityPermit] ap
  inner join [BP2].[Supervision].[ActivityPermitRegisterType] aprt on 
             ap.Id = aprt.ActivityPermitId
  inner join [BP2].[Supervision].[RegisterType] rt on rt.Id = aprt.RegisterTypeId
  where ap.RowDeleted = 0 and rt.RowDeleted = 0 and rt.Id = 33
GO

CREATE VIEW [dbo].[ActivityPermitRegisterTypeView5] AS
 SELECT ap.[Code] AS Value,
       CONCAT(ap.[CODE],' ',ap.[Name]) as Text
         
  FROM [BP2].[Supervision].[ActivityPermit] ap
  inner join [BP2].[Supervision].[ActivityPermitRegisterType] aprt on 
             ap.Id = aprt.ActivityPermitId
  inner join [BP2].[Supervision].[RegisterType] rt on rt.Id = aprt.RegisterTypeId
  where ap.RowDeleted = 0 and rt.RowDeleted = 0 
  and rt.Id = 1
  and not (ap.Code like 'ID')
  GO

CREATE VIEW [dbo].[ActivityPermitRegisterTypeView6] AS
 SELECT ap.[Code] AS Value,
       CONCAT(ap.[CODE],' ',ap.[Name]) as Text
         
  FROM [BP2].[Supervision].[ActivityPermit] ap
  inner join [BP2].[Supervision].[ActivityPermitRegisterType] aprt on 
             ap.Id = aprt.ActivityPermitId
  inner join [BP2].[Supervision].[RegisterType] rt on rt.Id = aprt.RegisterTypeId
  where ap.RowDeleted = 0 and rt.RowDeleted = 0 
  and rt.Id = 7
  GO

CREATE VIEW [dbo].[ActivityPermitRegisterTypeView7] AS
 SELECT ap.[Code] AS Value,
       CONCAT(ap.[CODE],' ',ap.[Name]) as Text
         
  FROM [BP2].[Supervision].[ActivityPermit] ap
  inner join [BP2].[Supervision].[ActivityPermitRegisterType] aprt on 
             ap.Id = aprt.ActivityPermitId
  inner join [BP2].[Supervision].[RegisterType] rt on rt.Id = aprt.RegisterTypeId
  where ap.RowDeleted = 0 and rt.RowDeleted = 0 
  and rt.Id = 13
  GO

CREATE VIEW [dbo].[ActivityPermitRegisterTypeView8] AS
 SELECT ap.[Code] AS Value,
       CONCAT(ap.[CODE],' ',ap.[Name]) as Text
         
  FROM [BP2].[Supervision].[ActivityPermit] ap
  inner join [BP2].[Supervision].[ActivityPermitRegisterType] aprt on 
             ap.Id = aprt.ActivityPermitId
  inner join [BP2].[Supervision].[RegisterType] rt on rt.Id = aprt.RegisterTypeId
  where ap.RowDeleted = 0 and rt.RowDeleted = 0 
  and rt.Id = 44
  GO

CREATE VIEW [dbo].[ActivityPermitRegisterTypeView9] AS
 SELECT ap.[Code] AS Value,
       CONCAT(ap.[CODE],' ',ap.[Name]) as Text
         
  FROM [BP2].[Supervision].[ActivityPermit] ap
  inner join [BP2].[Supervision].[ActivityPermitRegisterType] aprt on 
             ap.Id = aprt.ActivityPermitId
  inner join [BP2].[Supervision].[RegisterType] rt on rt.Id = aprt.RegisterTypeId
  where ap.RowDeleted = 0 and rt.RowDeleted = 0 
  and rt.Id = 45
  GO





