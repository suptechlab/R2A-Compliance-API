﻿DELETE FROM IzvjesceSektor
GO
DELETE FROM Sektor
GO

SET IDENTITY_INSERT Sektor ON
INSERT INTO Sektor (Id,Sektor) VALUES 
(1, N'SID - Sektor za investicijska društva'),
(2, N'SIMF - Sektor za investicijske i mirovinske fondove'),
(3, N'STK - Sektor za tržište kapitala'),
(4, N'SO - Sektor za osiguranja'),
(5, N'SLF - Sektor za leasing i faktoring')

SET IDENTITY_INSERT Sektor OFF