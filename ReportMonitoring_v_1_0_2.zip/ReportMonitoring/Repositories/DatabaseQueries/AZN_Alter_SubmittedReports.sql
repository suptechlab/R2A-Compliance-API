﻿ALTER TABLE dbo.PredaniIzvjestaji ALTER COLUMN VrstaSubjektaNadzoraId int NULL
ALTER TABLE dbo.PredaniIzvjestaji ALTER COLUMN TipObrascaId int NULL