﻿ALTER PROCEDURE [dbo].[zaprimiIzvjestaj]
	@FilePath nvarchar(255) ,
	@ReportId int ,
	@ReportVersionId int ,
	@ImeIzvjestaja nvarchar(255) ,
	@VrijemePredaje datetime2(0) ,
	@KorisnikId int ,
	@KorisnikNaziv nvarchar(255) ,
	@ZaprimljeniIzvId int
AS	
BEGIN

DECLARE @RestUrl AS VARCHAR(512);
DECLARE @Object AS INT;
DECLARE @ResponseText AS VARCHAR(8000);

	INSERT INTO [dbo].[PredaniIzvjestaji]
			   ([FilePath]
			   ,[ReportId]
			   ,[ReportVersionId]
			   ,[ImeIzvjestaja]
			   ,[VrijemePredaje]
			   ,[KorisnikId]
			   ,[KorisnikNaziv]
			   ,[Status]
			   ,[UnesiUBP2]
			   ,[ZaprimljeniIzvId])
		 VALUES
			   (

			   @FilePath  ,
		@ReportId  ,
		@ReportVersionId  ,
		@ImeIzvjestaja ,
		@VrijemePredaje ,
		@KorisnikId ,
		@KorisnikNaziv ,
		1,
		0,
		@ZaprimljeniIzvId
	)
	BEGIN TRY
		EXEC sp_OACreate 'MSXML2.XMLHTTP', @Object OUT;
		SET @RestUrl = CONCAT('http://localhost:8083/api/submittedReports/', @ZaprimljeniIzvId,'/status?newStatus=2')
		EXEC sp_OAMethod @Object, 'open', NULL, 'post',
			@RestUrl, 'false'	
		EXEC sp_OAMethod @Object, 'send'
		EXEC sp_OAMethod @Object, 'responseText', @ResponseText OUTPUT
	END TRY
	BEGIN CATCH
	END CATCH
END


