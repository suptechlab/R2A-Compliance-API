﻿using System;
using System.Collections.Generic;
using System.Linq;
using BSP.ReportDataConverter.Implementations;
using BSP.ReportDataConverter.Implementations.DynamicFields;
using Xunit;

namespace ReportMonitoringTests
{
    public class LookupTests
    {
        [Fact]
        public void GetsExchangeRateLookup()
        {
            var service = BspLookupService.GetService(
                "Data Source=10.100.93.6;initial catalog=R2A_S1A;persist security info=True;user id=r2a;password=r2a;MultipleActiveResultSets=True;");
            var pureValue = service.GetValue("XERATE", "USD2PHP", new List<string>(new[] { new DateTime(2018, 3, 6).Ticks.ToString()})).GetDecimalValue();
            Assert.NotNull(pureValue);
            Assert.NotEqual(0, pureValue);
            var multipliedBy100 = service.GetValue("XERATE", "USD2PHP", new List<string>(new[] { new DateTime(2018, 3, 6).Ticks.ToString(), "100"})).GetDecimalValue();
            Assert.Equal(multipliedBy100,pureValue*100);

            pureValue = service.GetValue("XERATE", "PHP2USD", new List<string>(new[] { new DateTime(2018, 3, 6).Ticks.ToString() })).GetDecimalValue();
            Assert.NotNull(pureValue);
            Assert.NotEqual(0, pureValue);
            multipliedBy100 = service.GetValue("XERATE", "PHP2USD", new List<string>(new[] { new DateTime(2018, 3, 6).Ticks.ToString(), "100" })).GetDecimalValue();
            Assert.Equal(multipliedBy100, pureValue * 100);

            var olderPureValue = service.GetValue("XERATE", "PHP2USD", new List<string>(new[] { new DateTime(2014,3,6).Ticks.ToString() })).GetDecimalValue();
            Assert.NotNull(olderPureValue);
            Assert.NotEqual(0, olderPureValue);
            Assert.NotEqual(pureValue,olderPureValue);
        }
    }
}
