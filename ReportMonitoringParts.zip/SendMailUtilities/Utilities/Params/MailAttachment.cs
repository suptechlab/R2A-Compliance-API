﻿namespace SendMailUtilities.Utilities
{
    public class MailAttachment
    {
        public string Name { get; set; }
        public byte[] Contents { get; set; }
    }
}