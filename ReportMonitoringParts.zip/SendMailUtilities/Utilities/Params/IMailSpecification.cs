﻿using System.Collections.Generic;

namespace SendMailUtilities.Utilities
{
    public interface IMailSpecification
    {
        List<string> Recipitents { get; }
        string Subject { get; }
        string From { get; } // IF NULL -> USE DEFAULT
        
        string PlainTextMessage { get; }
        string HtmlMessage { get; }
        List<MailAttachment> Attachments { get; }
        string ReplyTo { get; } // IF NULL NOTHING IS SET
    }
}