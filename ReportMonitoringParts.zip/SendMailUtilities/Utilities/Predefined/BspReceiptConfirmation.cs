﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Web.UI;

namespace SendMailUtilities.Utilities.Predefined
{
    public class BspReceiptConfirmation : IMailSpecification
    {
        public List<string> Recipitents { get; } = new List<string>();
        public string Subject { get; } = "Potrdilo o prejemu poročila";
        public string From { get; } = null;
        public string PlainTextMessage { get; }
        public string HtmlMessage { get; internal set; }
        public List<MailAttachment> Attachments { get; } = new List<MailAttachment>();
        public string ReplyTo { get; } = "no-replay@a-zn.si";
        
        
        public BspReceiptConfirmation(
            string submitterFullName,
            string companyName,
            DateTime submittionDateTime,
            string reportName,
            string reportPeriodText,
            DateTime? processingDateTime,
            string statusText
        )
        {
            
            var sb = new StringBuilder();
            sb.Append("S tem potrdilom potrjujemo, da je ")
                .Append(submitterFullName)
                .Append(" v imenu ")
                .Append(companyName)
                .Append(", dne ")
                .Append(submittionDateTime.ToString("dd.MM.yyyy"))
                .Append(" ob ")
                .Append(submittionDateTime.ToString("hh.mm.ss"))
                .Append("predal/a poročilo ")
                .Append(reportName)
                .Append(" za ")
                .Append(reportPeriodText)
                .Append(".");
            if (processingDateTime != null)
            {
                sb.Append("Poročilo je bilo obdelano v sistemu elektronskega poročanja ob ")
                    .Append(processingDateTime.Value.ToString("hh.mm.ss"));
            }
            sb.Append("\r\n\r\n")
                .Append("Status poročila: ")
                .Append(statusText);
            PlainTextMessage = sb.ToString();


            sb.Clear();
            using (var stringWriter = new StringWriter(sb))
            {
                using (var htmlWriter = new HtmlTextWriter(stringWriter))
                {
                    htmlWriter.RenderBeginTag(HtmlTextWriterTag.Html);
                    htmlWriter.RenderBeginTag(HtmlTextWriterTag.Head);
                    htmlWriter.RenderBeginTag(HtmlTextWriterTag.Title);
                    htmlWriter.Write(Subject);
                    htmlWriter.RenderEndTag();
                    htmlWriter.RenderEndTag();
                    htmlWriter.RenderBeginTag(HtmlTextWriterTag.Body);
                    htmlWriter.RenderBeginTag(HtmlTextWriterTag.P);
                    
                    WriteHtmlText(htmlWriter, "S tem potrdilom potrjujemo, da je ", false);
                    WriteHtmlText(htmlWriter, submitterFullName, true);
                    WriteHtmlText(htmlWriter, " v imenu ", false);
                    WriteHtmlText(htmlWriter, companyName, true);
                    WriteHtmlText(htmlWriter, ", dne ", false);
                    WriteHtmlText(htmlWriter, submittionDateTime.ToString("dd.MM.yyyy"), true);
                    WriteHtmlText(htmlWriter, " ob ", false);
                    WriteHtmlText(htmlWriter, submittionDateTime.ToString("HH.mm.ss"), true);
                    WriteHtmlText(htmlWriter, " predal/a poročilo ", false);
                    WriteHtmlText(htmlWriter, reportName, true);
                    WriteHtmlText(htmlWriter, " za ", false);
                    WriteHtmlText(htmlWriter, reportPeriodText, true);
                    WriteHtmlText(htmlWriter, ".", false);

                    htmlWriter.RenderEndTag();
                    if (processingDateTime != null)
                    {
                        htmlWriter.RenderBeginTag(HtmlTextWriterTag.P);
                        WriteHtmlText(htmlWriter, " Poročilo je bilo obdelano v sistemu elektronskega poročanja ob ",
                            false);
                        WriteHtmlText(htmlWriter, processingDateTime.Value.ToString("HH.mm.ss"), true);
                        htmlWriter.RenderEndTag();
                    }

                    htmlWriter.RenderBeginTag(HtmlTextWriterTag.P);
                    htmlWriter.RenderBeginTag(HtmlTextWriterTag.Br);
                    htmlWriter.RenderEndTag();
                    htmlWriter.RenderEndTag();

                    htmlWriter.RenderBeginTag(HtmlTextWriterTag.P);
                    WriteHtmlText(htmlWriter, "Status poročila: ", false);
                    WriteHtmlText(htmlWriter, statusText, true);
                    htmlWriter.RenderEndTag();
                    
                    htmlWriter.RenderBeginTag(HtmlTextWriterTag.P);
                    htmlWriter.RenderEndTag();

                    htmlWriter.RenderBeginTag(HtmlTextWriterTag.P);
                    htmlWriter.RenderBeginTag(HtmlTextWriterTag.Br);
                    htmlWriter.RenderEndTag();
                    htmlWriter.RenderBeginTag(HtmlTextWriterTag.Br);
                    htmlWriter.RenderEndTag();
                    WriteHtmlText(htmlWriter, "AZN", true);
                    WriteHtmlText(htmlWriter, " - Agencija za zavarovalni nadzor", false);
                    htmlWriter.RenderEndTag();
                    htmlWriter.RenderEndTag();
                    htmlWriter.RenderEndTag();
                                        
                }
            }
            HtmlMessage = sb.ToString();
        }

        private static void WriteHtmlText(HtmlTextWriter writer, string text, bool bold)
        {
            writer.RenderBeginTag(HtmlTextWriterTag.Span);
            if (bold) writer.RenderBeginTag(HtmlTextWriterTag.B);
            writer.Write(text);
            if (bold) writer.RenderEndTag();
            writer.RenderEndTag();
        }
        
        public BspReceiptConfirmation(
            string plainTextMessage
        )
        {
            PlainTextMessage = plainTextMessage;
            HtmlMessage = null;
        }

        public void AddRecipient(string recipientMail)
        {
            Recipitents.Add(recipientMail);
        }
        
        
        
    }
}