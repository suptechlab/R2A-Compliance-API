﻿using System;
using System.Collections.Specialized;
using System.Configuration;

namespace SendMailUtilities.Utilities.Config
{
    public class MailConfiguration
    {
        public string FromAddress { get; set; } = "no-reply";
        public string SmtpServer { get; set; } = "localhost";
        public int Port { get; set; } = 25;
        public string SmtpUser { get; set; } = string.Empty;
        public string SmtpPassword { get; set; } = string.Empty;
        public bool UseTls { get; set; }
        public bool RequiresAuthentication { get; set; }
        public string PreferredEncoding { get; set; } = string.Empty;

        private static string GetValue(NameValueCollection sendMailCollection, string propertyName, string defaultValue)
        {
            var res = sendMailCollection.Get(propertyName);
            return res ?? defaultValue;
        }
        
        public static MailConfiguration LoadFromWebConfig()
        {
            var config = new MailConfiguration();
            var sendMailConfiguration = ConfigurationManager.GetSection("sendMailConfiguration") as NameValueCollection;
            if (sendMailConfiguration == null) return null;

            config.FromAddress = GetValue(sendMailConfiguration, "from", config.FromAddress);
            config.SmtpServer = GetValue(sendMailConfiguration, "smtpServer", config.SmtpServer);
            if (int.TryParse(GetValue(sendMailConfiguration, "smtpServerPort", "25"), out var port))
            {
                config.Port = port;
            }
            config.SmtpUser = GetValue(sendMailConfiguration, "smtpUser", string.Empty);
            config.SmtpPassword = GetValue(sendMailConfiguration, "smtpPassword", string.Empty);
            if (bool.TryParse(GetValue(sendMailConfiguration, "useTls", "false"), out var tls))
            {
                config.UseTls = tls;
            }

            if (bool.TryParse(GetValue(sendMailConfiguration, "requiresAuth", "false"), out var auth))
            {
                config.RequiresAuthentication = auth;
            }

            config.PreferredEncoding = GetValue(sendMailConfiguration, "preferredEncoding", string.Empty);

            return config;
        }
    }
}