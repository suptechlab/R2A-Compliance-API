﻿using System;
using System.Threading;
using System.Threading.Tasks;
using MailKit.Net.Smtp;
using MailKit.Security;
using MimeKit;
using SendMailUtilities.Utilities.Config;

namespace SendMailUtilities.Utilities
{
    public class EmailSender
    {
        public MailConfiguration Configuration { get; }
        private readonly ILogger _logger;

        public EmailSender(MailConfiguration configuration, ILogger logger)
        {
            Configuration = configuration;
            _logger = logger;
        }

        public bool SendEmail(IMailSpecification mailSpecification)
        {
            return SendEmail(Configuration, _logger, mailSpecification);
        }

        public Task<bool> SendEmailAsync(IMailSpecification mailSpecification, CancellationToken cancellationToken = default(CancellationToken))
        {
            return SendEmailAsync(Configuration, _logger, mailSpecification, cancellationToken);
        }

        public static bool SendEmail(MailConfiguration config, ILogger logger, IMailSpecification mailSpecification,
            CancellationToken cancellationToken = default(CancellationToken))
        {
            var result = SendEmailAsync(config, logger, mailSpecification, cancellationToken).Result;
            return result;
        }

        public static async Task<bool> SendEmailAsync(MailConfiguration config, ILogger logger,
            IMailSpecification mailSpecification, CancellationToken cancellationToken = default(CancellationToken))
        {
            cancellationToken.ThrowIfCancellationRequested();
            var succes = true;
            try
            {
                if (mailSpecification.Recipitents == null || mailSpecification.Recipitents.Count == 0)
                {
                    throw new ArgumentException("Cant' send mail - no recipients address provided");
                }

                var @from = string.IsNullOrWhiteSpace(mailSpecification.From)
                    ? config.FromAddress
                    : mailSpecification.From;

                if (string.IsNullOrWhiteSpace(mailSpecification.Subject))
                {
                    throw new ArgumentException("Can't send mail - no subject provided");
                }

                var hasPlainText = !string.IsNullOrWhiteSpace(mailSpecification.PlainTextMessage);
                var hasHtml = !string.IsNullOrWhiteSpace(mailSpecification.HtmlMessage);

                if (!hasPlainText && !hasHtml)
                {
                    throw new ArgumentException("Can't send mail - no message provided");
                }

                var m = new MimeMessage();
                m.From.Add(new MailboxAddress("", from));

                if (!string.IsNullOrWhiteSpace(mailSpecification.ReplyTo))
                {
                    m.ReplyTo.Add(new MailboxAddress("", mailSpecification.ReplyTo));
                }

                m.Subject = mailSpecification.Subject;

                var bodyBuilder = new BodyBuilder();
                if (hasPlainText)
                {
                    bodyBuilder.TextBody = mailSpecification.PlainTextMessage;
                }

                if (hasHtml)
                {
                    bodyBuilder.HtmlBody = mailSpecification.HtmlMessage;
                }

                mailSpecification.Attachments?.ForEach(a => { bodyBuilder.Attachments.Add(a.Name, a.Contents); });

                m.Body = bodyBuilder.ToMessageBody();

                using (var client = new SmtpClient())
                {
                    await client.ConnectAsync(
                        config.SmtpServer,
                        config.Port,
                        config.UseTls ? SecureSocketOptions.StartTls : SecureSocketOptions.None, cancellationToken);

                    // Note: since we don't have an OAuth2 token, disable
                    // the XOAUTH2 authentication mechanism.
                    client.AuthenticationMechanisms.Remove("XOAUTH2");

                    // Note: only needed if the SMTP server requires authentication
                    if (config.RequiresAuthentication)
                    {
                        await client.AuthenticateAsync(config.SmtpUser, config.SmtpPassword, cancellationToken)
                            .ConfigureAwait(false);
                    }

                    foreach (var recipient in mailSpecification.Recipitents)
                    {
                        m.To.Clear();
                        m.To.Add(new MailboxAddress("", recipient));
                        try
                        {
                            await client.SendAsync(m, cancellationToken).ConfigureAwait(false);
                        }
                        catch (Exception e)
                        {
                            logger.Error(e, $"An exception occured while trying to send mail to {recipient}.");
                            succes = false;
                        }
                    }

                    await client.DisconnectAsync(true, cancellationToken).ConfigureAwait(false);
                }
            }
            catch (Exception e)
            {
                logger.Error(e, "An exception occured while trying to send mail.");
                succes = false;
            }

            return succes;
        }
    }
}