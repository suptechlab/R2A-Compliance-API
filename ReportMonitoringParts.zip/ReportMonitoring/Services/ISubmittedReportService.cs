﻿using System.Collections.Generic;
using ReportMonitoring.Models;
//using ReportMonitoring.Utilities;

namespace ReportMonitoring.Services
{
    public interface ISubmittedReportService
    {
        List<ReportListViewModel> GetSubmittedReports(int? divisionId, HashSet<string> userGroups );
        SubmittedReportDetailsViewModel GetSubmittedReport(int id);

        AdditionalReportFile GetReportFile(int? submittedReportId, int? fileTypeInt);
    }
}