﻿using System.Collections.Generic;
using System.Configuration;
using ReportMonitoring.Models;
using ReportMonitoring.Repositories;
using Pinecone.ReportDataConverter;
using Pinecone.ReportDataConverter.Config;
using Pinecone.ReportDataConverter.Extensions.Xml;
using System.IO;
using Pinecone.ReportDataConverter.Extensions.Json;
using Pinecone.ReportDataConverter.Extensions.Excel;
using System;
using System.Collections.Concurrent;
using System.Collections.ObjectModel;
using System.Net.Http;
using BSP.ReportDataConverter.Implementations;
using BSP.ReportDataConverter.Implementations.DynamicFields;
using Pinecone.ReportDataConverter.Config.Interfaces;
using Pinecone.ReportDataConverter.Extensions.Misc;
using Pinecone.ReportFormula.Interpreter.Lookup;

namespace ReportMonitoring.Services
{
    public class ReportService : IReportService
    {
        private readonly IFormRepository _formRepository;
        private readonly IReportRepository _reportRepository;
        private readonly IDynamicDropdownDataResolver _dataResolver;
        private readonly ILookupResolver _lookupResolver;
        private readonly bool _useBinaryCache;

        private static readonly ConcurrentDictionary<int, ReportConfig> ReportConfigCache =
            new ConcurrentDictionary<int, ReportConfig>();


        public ReportService()
        {
            _reportRepository = new ReportRepository(ConfigurationManager.AppSettings["SqlConnectionString"]);
            _formRepository = new FormRepository(ConfigurationManager.AppSettings["SqlConnectionString"]);
            _dataResolver = new ServiceDynamicDataResolver(new DynamicOptionsService(new DynamicOptionsRepository(ConfigurationManager.AppSettings["SqlConnectionString"])));
            _useBinaryCache = "true" == ConfigurationManager.AppSettings["BinaryReportViewerCache"];
            _lookupResolver = BspLookupService.GetService(ConfigurationManager.AppSettings["SqlConnectionString"]);
        }


        private ReportData GetConfiguration(int reportVersionId)
        {
            if (!ReportConfigCache.TryGetValue(reportVersionId, out var reportConfig))
            {
                var reportDefinition = _formRepository.GetReportDefinitionByVersionId(reportVersionId);

                if (_useBinaryCache && File.Exists(reportDefinition.JsonDefinition + ".bin"))
                {
                    reportConfig = ReportConfig.Deserialize(new FileInfo(reportDefinition.JsonDefinition + ".bin"));
                }
                else
                {
                    reportConfig = ConfigFactoryDpmV2.LoadReportConfigFromFile(reportDefinition.JsonDefinition, reportDefinition.XsdNamespace);
                    
                    if (_useBinaryCache)
                    {
                        ReportConfig.Serialize(new FileInfo(reportDefinition.JsonDefinition + ".bin"), reportConfig);
                    }
                }

                ReportConfigCache.AddOrUpdate(reportVersionId, reportConfig, (key, oldValue) => reportConfig);
            }

            return new ReportData(reportConfig, _lookupResolver);
        }

        public Tuple<string, byte[]> GetJson(Stream xml, int reportVersionId)
        {
            ReportData rd = GetConfiguration(reportVersionId);
            var sb = new MemoryStream();
            rd.LoadFromXmlV2(xml).SaveToJson(sb);
            return new Tuple<string, byte[]>(rd.ReportConfig.XmlNode, sb.ToArray());
        }

        public Tuple<string, byte[]> GetJson(Collection<HttpContent> httpContent, int reportVersionId)
        {
            var rd = GetConfiguration(reportVersionId);
            foreach (var content in httpContent)
            {
                var rd2 = new ReportData(rd.ReportConfig, _lookupResolver);
                using (var stream = content.ReadAsStreamAsync().Result)
                {
                    rd2.LoadFromXmlV2(stream);
                }

                rd.MergeReportData(rd2);
            }

            using (var sb = new MemoryStream())
            {
                rd.SaveToJson(sb);
                return new Tuple<string, byte[]>(rd.ReportConfig.XmlNode, sb.ToArray());
            }
        }

        public Tuple<string, byte[]> GetXml(Stream json, int reportVersionId)
        {
            var rd = GetConfiguration(reportVersionId);
            using (var ms = new MemoryStream())
            {
                using (var sw = new StreamWriter(ms))
                {
                    rd.LoadFromJson(json).SaveToXmlV2(sw);
                }

                return new Tuple<string, byte[]>(rd.ReportConfig.XmlNode, ms.ToArray());
            }
        }

        private void ExpandReportForms(ReportData reportData)
        {
            var rootData = reportData.Data[reportData.ReportConfig.Code] as Dictionary<string, object>;
            if (rootData != null)
            {
                var headerData = rootData[reportData.ReportConfig.HeaderForm.XmlNode] as Dictionary<string, object>;
                if (headerData != null)
                {
                    var period = headerData["Period"];
                    var bankCode = headerData["Undertaking"];
                    if (period != null && bankCode != null)
                    {
                        var bspTemplateRequirementChecker = new BspTemplateRequirementChecker(
                            bankCode.ToString(), reportData.ReportConfig.Code,
                            Convert.ToInt32(period), ConfigurationManager.AppSettings["SqlConnectionString"]);

                        reportData.ExpandAllForms(bspTemplateRequirementChecker);
                    }
                }
            }
        }

        public Tuple<string, byte[]> GetExcel(int submittedFileId)
        {
            var reportFile = _reportRepository.GetReportFile(submittedFileId, FileType.XmlFile);
            var reportVersionId = _reportRepository.GetReportVersionId(submittedFileId);

            if (reportFile != null && !string.IsNullOrEmpty(reportFile.FilePath) && reportVersionId.HasValue)
            {
                try
                {
                    var rd = GetConfiguration(reportVersionId.Value);
                    rd.DynamicDropdownDataResolver = _dataResolver;
                    using (var ms = new MemoryStream())
                    {

                        rd.LoadFromXmlV2(File.ReadAllText(reportFile.FilePath));
                        ExpandReportForms(rd);
                        rd.SaveToExcel(ms);

                        return new Tuple<string, byte[]>($"{Path.GetFileNameWithoutExtension(reportFile.FilePath)}.xlsx", ms.ToArray());
                    }
                }
                catch (Exception e)
                {
                    return null;
                }
            }

            return null;
        }

        public Tuple<string, byte[]> GetExcel(Stream json, int reportVersionId)
        {
            var rd = GetConfiguration(reportVersionId);
            rd.DynamicDropdownDataResolver = _dataResolver;
            using (var ms = new MemoryStream())
            {
                rd.LoadFromJson(json);
                ExpandReportForms(rd);
                rd.SaveToExcel(ms);
                return new Tuple<string, byte[]>(rd.ReportConfig.XmlNode, ms.ToArray());
            }
        }

        public Tuple<string, byte[]> GetExcel(string json, int reportVersionId)
        {
            var rd = GetConfiguration(reportVersionId);
            rd.DynamicDropdownDataResolver = _dataResolver;
            using (var ms = new MemoryStream())
            {
                rd.LoadFromJson(json);
                ExpandReportForms(rd);
                rd.SaveToExcel(ms);
                return new Tuple<string, byte[]>(rd.ReportConfig.XmlNode, ms.ToArray());
            }
        }

        /*
                public string[] ValidateReport(string json, int reportDefinitionId)
                {
                    return ValidateReport(CreateReportDocument(json), reportDefinitionId);
                }
        */
        public ReportDefinitionModel GetReportDefinitionByVersionId(int reportVersionId)
        {
            return _formRepository.GetReportDefinitionByVersionId(reportVersionId);
        }

        /*
                public string[] ValidateReport(XmlDocument report, int reportDefinitionId)
                {
                    var results = new List<string>();
                    //fetch xsd schema
                    if (report.Schemas.Count == 0)
                    {
                        var schemaPath = _formRepository.GetReportSchemaPath(reportDefinitionId);
                        if (schemaPath == string.Empty)
                        {
                            results.Add("Datoteka ni najdena"); // TODO prijevod
                            return results.ToArray();
                        }

                        if (System.IO.Path.IsPathRooted(schemaPath))
                        {
                            report.Schemas.Add("", schemaPath);
                        }
                        else
                        {
                            report.Schemas.Add("", HostingEnvironment.MapPath(schemaPath));
                        }
                    }

                    report.Validate((e, args) => { results.Add(args.Message); });

                    return results.ToArray();
                }
        */
        /*       public dynamic GetReportDefiniton(int verzijaSubjektaNadzoraId, int tipObrascaId)
               {
                   //TODO optimizirati jednim upitom
                   var definitionId = _formRepository.GetAssignedReportDefinition(verzijaSubjektaNadzoraId, tipObrascaId);
                   if (definitionId != null)
                   {
                       return new {definition = _formRepository.GetReportDefinitionById(definitionId.Value), definitionId};
                   }
       
                   return null;
               }
       */
        /*
                public IList<dynamic> GetDropDownListItems(string dbView)
                {
                    return _formRepository.GetDropDownListItems(dbView);
                }
        */
        /*
                public int InsertOrUpdateReportDefinition(ReportDefinitionModel reportDefinition)
                {
                    if (reportDefinition == null) return 0;

                  //  if(reportDefinition.IsDigital && _formRepository.CheckIfReportExists(reportDefinition.ReportId))
                  //  {
                  //      return _formRepository.UpdateReportDefinitionByReportId(reportDefinition);
                  //  }

                    if (_formRepository.CheckIfVersionExists(reportDefinition.ReportVersionId))
                    {
                        return _formRepository.UpdateReportDefinition(reportDefinition);
                    }

                    return _formRepository.InsertNewReportDefinition(reportDefinition);
                }
        */
        /*
                public IList<dynamic> GetReportMenuItems()
                {
                    return _formRepository.GetReportDigitalItems();
                }
        */
        /*
                private static XmlDocument CreateReportDocument(string json)
                {
                    var doc = JsonConvert.DeserializeXmlNode(json);
                    var xdoc = doc.ToXDocument();
                    xdoc.Descendants()
                        .Where(e => e.IsEmpty || string.IsNullOrWhiteSpace(e.Value))
                        .Remove();


                    if (xdoc.Root != null)
                    {
                        return xdoc.ToXmlDocument();
                    }
                    else
                    {
                        if (doc.DocumentElement != null) doc.DocumentElement.RemoveAll();
                        return doc;
                    }
                }
        */
        /*
                public string ConvertToJson(XmlDocument form)
                {
                    return JsonConvert.SerializeXmlNode(form);
                }
        */
        public IList<dynamic> GetDivisions()
        {
            return _reportRepository.GetDivisions();
        }


        public ISet<int> GetReportsOfDivision(int divisionId)
        {
            return _reportRepository.GetReportsOfDivision(divisionId);
        }

        public Tuple<string, byte[]> GetConfig(int reportVersionId)
        {
            var configPath = _reportRepository.GetReportConfigFile(reportVersionId);

            if(configPath != null)
            {
                if(File.Exists(configPath))
                {
                    return new Tuple<string, byte[]>(Path.GetFileName(configPath), File.ReadAllBytes(configPath));
                }
            }

            return null;
        }
    }

    /*
        public static class DocumentExtensions
        {
            public static XmlDocument ToXmlDocument(this XDocument xDocument)
            {
                var xmlDocument = new XmlDocument();
                using (var xmlReader = xDocument.CreateReader())
                {
                    xmlDocument.Load(xmlReader);
                }

                return xmlDocument;
            }

            public static XDocument ToXDocument(this XmlDocument xmlDocument)
            {
                using (var nodeReader = new XmlNodeReader(xmlDocument))
                {
                    nodeReader.MoveToContent();
                    return XDocument.Load(nodeReader);
                }
            }
        }
       */
}