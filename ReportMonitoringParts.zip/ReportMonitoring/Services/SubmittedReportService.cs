﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Xml;
using ReportMonitoring.Models;
using ReportMonitoring.Repositories;
//using ReportMonitoring.Utilities;
using log4net;
using System.IO;

namespace ReportMonitoring.Services
{
    public class SubmittedReportService : ISubmittedReportService
    {
        private readonly IReportRepository _reportRepository;
        private readonly IReportService _reportService;

        private static readonly ILog Logger =
            LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public SubmittedReportService()
        {
            _reportService = new ReportService();
            _reportRepository = new ReportRepository(ConfigurationManager.AppSettings["SqlConnectionString"]);
        }

        public SubmittedReportService(IReportRepository reportRepository, IReportService reportService)
        {
            _reportRepository = reportRepository;
            _reportService = reportService;
        }

        public List<ReportListViewModel> GetSubmittedReports(int? divisionId, HashSet<string> userGroups)
        {
            List<ReportListViewModel> submittedReports;
            if (divisionId.HasValue)
            {
                //if (userGroups.Contains((ActiveDomainGroups.Groups) divisionId.Value) ||
                //    userGroups.Contains(ActiveDomainGroups.Groups.Admin))
                //{
                submittedReports = _reportRepository.GetSubmittedReports(new List<int>() {divisionId.Value});
                //}
                //else
                //{
                //return new List<ReportListViewModel>();
                //}
            }
            /*else if (userGroups.Contains(ActiveDomainGroups.Groups.Admin))
            {
                submittedReports = _reportRepository.GetSubmittedReports(null);
            }
            else if (userGroups.Count == 0)
            {
                return new List<ReportListViewModel>();
            }*/
            else
            {
                submittedReports = _reportRepository.GetSubmittedReports(null);
            }

            /*
            foreach (var submittedReport in submittedReports)
            {
                var xml = new XmlDocument();
                try
                {
                    xml.Load(submittedReport.FilePath);
                }
                catch (Exception)
                {
                    // ignored
                    continue;
                }
                var oib = ExtractOib(xml);
                var nazivSubjekta = string.Empty;
                if (!string.IsNullOrEmpty(oib))
                {
                    nazivSubjekta = _reportRepository.GetSubjectName(oib);
                }
                submittedReport.NazivSubjekta = string.IsNullOrEmpty(nazivSubjekta) ? "Nepoznato" : nazivSubjekta;
            }*/
            /*
            if (submittedReports.Count == 0)
            {
                return submittedReports;
            }

            var submittedReportIds = submittedReports.Select(sr => sr.SubmittedReportId).Distinct();
            var subjectNames = _reportRepository.GetSubjectNamesOfReports(submittedReportIds);
            foreach (var report in submittedReports)
            {
                report.NazivSubjekta = subjectNames.ContainsKey(report.SubmittedReportId) ? subjectNames[report.SubmittedReportId] : "Nepoznato";
            }*/
            return submittedReports;
        }

        public SubmittedReportDetailsViewModel GetSubmittedReport(int id)
        {
            var report = _reportRepository.GetSubmittedReport(id);

            if (!string.IsNullOrEmpty(report.SubmittedReportFilePath) && report.SubmittedReport.IsViewable)
            {
                try
                {
                    using (var stream = File.OpenRead(report.SubmittedReportFilePath))
                    {
                        report.ReportValuesString = report.SubmittedReport.ReportVersionId.HasValue
                            ? System.Text.Encoding.UTF8.GetString(_reportService
                                .GetJson(stream, report.SubmittedReport.ReportVersionId.Value).Item2)
                            : null;
                    }
                }
                catch (Exception e)
                {
                    Logger.Error(
                        $"Error loading xml for report with Id {id} from path {report.SubmittedReportFilePath}", e);
                    return null;
                }
            }
            else
            {
                report.ReportValuesString = null;
            }

            return report;
        }

        public AdditionalReportFile GetReportFile(int? submittedReportId, int? fileTypeInt)
        {
            if (!submittedReportId.HasValue || !fileTypeInt.HasValue ||
                !Enum.IsDefined(typeof(FileType), fileTypeInt.Value))
            {
                return null;
            }

            var fileType = (FileType) fileTypeInt.Value;

            return _reportRepository.GetReportFile(submittedReportId.Value, fileType);
        }
    }
}