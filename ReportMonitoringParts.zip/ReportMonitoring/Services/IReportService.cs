﻿using System.Collections.Generic;
using System.Xml;
using ReportMonitoring.Models;
using System.IO;
using System;
using System.Collections.ObjectModel;
using System.Net.Http;

namespace ReportMonitoring.Services
{
    public interface IReportService
    {
        ReportDefinitionModel GetReportDefinitionByVersionId(int reportVersionId);
        Tuple<string, byte[]> GetJson(Stream xml, int reportVersionId);
        Tuple<string, byte[]> GetJson(Collection<HttpContent> httpContent, int reportVersionId);
        Tuple<string, byte[]> GetXml(Stream json, int reportVersionId);
        Tuple<string, byte[]> GetExcel(Stream json, int reportVersionId);
        Tuple<string, byte[]> GetExcel(String json, int reportVersionId);
        Tuple<string, byte[]> GetExcel(int submittedFileId);
        IList<dynamic> GetDivisions();
        ISet<int> GetReportsOfDivision(int divisionId);
        Tuple<string, byte[]> GetConfig(int reportVersionId);
    }
}