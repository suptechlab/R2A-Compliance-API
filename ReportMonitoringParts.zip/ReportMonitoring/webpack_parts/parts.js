const webpack = require('webpack');

const CleanWebpackPlugin = require('clean-webpack-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');
// const ImageminWebpackPlugin = require('imagemin-webpack-plugin').default;
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const CompressionPlugin = require("compression-webpack-plugin");


/**** Postavke za webpack-dev-server ****/
exports.devServer = ({host, port}) => {
    return {

        // In case of vagrant
        // watchOptions: {
        //     // Delay the rebuild after the first change
        //     aggregateTimeout: 300,
        //     // Poll using interval (in ms, accepts boolean too)
        //     poll: 1000
        // },
        //

        devServer: {
            // Enable history API fallback so HTML5 History API based
            // routing works. This is a good default that will come
            // in handy in more complicated setups.
            historyApiFallback: true,

            // Refresh if hot loading fails. If don't want
            // refresh behavior, set hotOnly: true instead.
            hot: true,
            inline: true,

            // Display only errors to reduce the amount of output.
            //stats: 'errors-only',
            stats: 'normal',

            //Enable gzip compression for everything served
            compress: true,

            publicPath: "http://localhost:3000/resources/",


            proxy: {
                // "/resources/scripts/*": "http://localhost:3000/",
                // "/*.hot-update.json":"http://localhost:3000/",
                "*": "http://localhost:8081"

            },
            // Parse host and port from env to allow customization.
            //
            // If you use Vagrant or Cloud9, set
            // host: options.host || '0.0.0.0';
            //
            // 0.0.0.0 is available to all network devices
            // unlike default `localhost`.
            host: host, // Defaults to `localhost`
            port: port // Defaults to 8080
        },
        plugins: [
            // Enable multi-pass compilation for enhanced performance
            // in larger projects. Good default.
            new webpack.HotModuleReplacementPlugin({
                multiStep: true
            })
        ]
    }
};


/**** Postavke za lintere *****/
exports.lintJavaScript = ({include, exclude, options}) => {
    return {
        module: {
            rules: [
                {
                    enforce: 'pre',
                    test: /\.(js|jsx)$/,
                    include,
                    exclude,

                    loader: 'eslint-loader?{fix:true}',
                    options
                }
            ]
        }
    }
};

exports.lintTypeScript = ({include, exclude, options}) => {
    return {
        module: {
            rules: [
                {
                    enforce: 'pre',
                    test: /\.(ts|tsx)$/,
                    include,
                    exclude,

                    loader: 'tslint-loader',
                    options
                }
            ]
        }
    }
};

/*** Postavke za javascript loadere  ***/

exports.loadJavaScript = ({include, exclude}) => {
    return {
        module: {
            rules: [
                {
                    test: /\.(js|jsx)$/,
                    include,
                    exclude,

                    loader: 'babel-loader',
                    options: {
                        // Enable caching for improved performance during
                        // development.
                        // It uses default OS directory by default. If you need
                        // something more custom, pass a path to it.
                        // I.e., { cacheDirectory: '<path>' }
                        cacheDirectory: true
                    }
                }
            ]
        }
    };
};

exports.loadTypeScript = function ({include, exclude}) {
    return {
        module: {
            rules: [
                {
                    test: /\.(ts|tsx)$/,
                    include,
                    exclude,

                    use: [
                        {
                            loader: 'babel-loader',
                            options: {
                                cacheDirectory: true
                            }
                        },
                        {
                            loader: 'ts-loader'
                        }
                    ]
                }
            ]
        }
    };
};


/*** Ostale postavke ***/

exports.generateSourceMaps = function ({type}) {
    return {
        devtool: type
    };
};

exports.gzipScripts = () => {
    return {
        plugins: [
            // Extract bundles.
            new CompressionPlugin()
        ]
    }
};


exports.extractBundles = ({bundles, options}) => {
    const entry = {};
    const names = [];

    // Set up entries and names.
    bundles.forEach(({name, entries}) => {
        if (entries) {
            entry[name] = entries;
        }

        names.push(name);
    });

    return {
        // Define an entry point needed for splitting.
        entry,
        plugins: [
            // Extract bundles.
            new webpack.optimize.CommonsChunkPlugin(
                Object.assign({}, {names:names},options)
            )
        ]
    };
};


exports.extractBundle = function (options) {
    const entry = {};
    entry[options.name] = options.entries;

    return {
        // Define an entry point needed for splitting.
        entry: entry,
        plugins: [
            // Extract bundle and manifest files. Manifest is
            // needed for reliable caching.
            new webpack.optimize.CommonsChunkPlugin({
                names: [options.name, 'manifest']
            })
        ]
    };
};


exports.clean = function (path, exclude) {
    return {
        plugins: [
            new CleanWebpackPlugin([path], {
                // Without `root` CleanWebpackPlugin won't point to our
                // project and will fail to work.
                root: process.cwd(),
                "verbose": true,
                "dry": false,
                exclude
            })
        ]
    };
};

// exports.copyImages = (path, minimise, options) => {
//     const {from, to} = path;
//     return {
//         plugins: [
//             // Copy the images folder and optimize all the images
//             new CopyWebpackPlugin([{
//                 from,
//                 to
//             }]),
//             new ImageminWebpackPlugin({
//                 disable: minimise !== true,
//                 test: /\.(jpe?g|png|gif|svg)$/i,
//                 options
//             })
//         ]
//     }
// };

//Postavke za DefinePlugin
exports.setFreeVariable = function (key, value) {
    const env = {};
    env[key] = JSON.stringify(value);

    return {
        plugins: [
            new webpack.DefinePlugin(env)
        ]
    };
};


//Postavke za uglify
exports.minify = (useSourceMaps = false) => {
    return {
        plugins: [
            new webpack.optimize.UglifyJsPlugin({
                compress: {
                    screw_ie8: true,
                    warnings: false
                },
                sourceMap: useSourceMaps
            })
        ]
    };
};


/**** Style loaders *****/

exports.loadCSS = function ({include, exclude} = {}) {
    return {
        module: {
            rules: [
                {
                    test: /\.css$/,
                    include,
                    exclude,

                    use: ['style-loader', 'css-loader']
                }
            ]
        }
    };
};


exports.loadLess = function ({include, exclude} = {}) {
    return {
        module: {
            rules: [
                {
                    test: /\.less$/,
                    include,
                    exclude,

                    use: ['style-loader', 'css-loader', 'less-loader']
                }
            ]
        }
    };
};

exports.extractLess = function ({include, exclude, use}) {
    return {
        module: {
            rules: [
                {
                    test: /\.less$/,
                    include,
                    exclude,

                    use: ExtractTextPlugin.extract({
                        use: use,
                        fallback: 'style-loader'
                    })
                }
            ]
        },
        plugins: [
            // Output extracted CSS to a file
            new ExtractTextPlugin('css/[name].css')
        ]
    };
};

exports.autoprefix = function () {
    return {
        loader: 'postcss-loader',
        options: {
            plugins: function () {
                return [
                    require('autoprefixer')
                ];
            }
        }
    };
};

exports.loadFonts = function ({include, exclude, options} = {}) {
    return {
        module: {
            rules: [
                {
                    // Capture eot, ttf, svg, woff, and woff2
                    test: /\.(woff2?|ttf|svg|eot)(\?v=\d+\.\d+\.\d+)?$/,
                    include,
                    exclude,

                    use: {
                        loader: 'file-loader',
                        options
                    }
                }
            ]
        }
    };
};


exports.shimmModules = (modules) => {
    return {
        plugins: [
            new webpack.ProvidePlugin(modules)
        ]
    }
}
