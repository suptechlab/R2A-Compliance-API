﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Http;
using BSP.ReportDataConverter.Implementations.DynamicFields;
using Pinecone.ReportDataConverter.Config;
using Pinecone.ReportDataConverter.Config.Interfaces;

namespace ReportMonitoring.PublicApi
{
    [RoutePrefix("api/dynamicOptions")]
    public class DynamicController : ApiController
    {
        private IDynamicDropdownDataResolver _dynamicResolver;

        public DynamicController()
        {
            _dynamicResolver = new ServiceDynamicDataResolver(new DynamicOptionsService(new DynamicOptionsRepository(
                ConfigurationManager.AppSettings["SqlConnectionString"])
                ));
        }

        [HttpGet]
        [Route]
        public IEnumerable<dynamic> GetDynamicOptions(string sourceType, string sourceParam)
        {
            return _dynamicResolver.GetAllDropDownValuesForSource(sourceType, sourceParam).Select(d => new
            {
                value = d.Value, text = d.Title
            });
        }
    }
}