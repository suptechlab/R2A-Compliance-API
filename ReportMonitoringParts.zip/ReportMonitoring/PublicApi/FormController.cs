﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web.Http;
using ReportMonitoring.Models;
using ReportMonitoring.Services;
using log4net;
using System.Net;
using System.IO;
using System.Threading.Tasks;
using System.Web;
using System.Net.Http.Headers;
using System.Text;

namespace ReportMonitoring.PublicApi
{
    [RoutePrefix("api/form")]
    public class FormController : ApiController
    {
        private readonly IReportService _reportService;

        private static readonly ILog Logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);


        public FormController()
        {
            _reportService = new ReportService();
        }
/*
        [Route("definition")]
        public dynamic GetFormGeneratorDefinition(int verzijaSubjektaNadzoraId, int tipObrascaId)
        {
            return _reportService.GetReportDefiniton(verzijaSubjektaNadzoraId, tipObrascaId);
        }
*/
/*
        [HttpPost]
        [Route("validate")]
        public string[] ValidateSchema([FromUri] int reportDefinitionId, HttpRequestMessage request)
        {
            try
            {
                var json = request.Content.ReadAsStringAsync().Result;
                return _reportService.ValidateReport(json.ToString(), reportDefinitionId);
            }
            catch (Exception e)
            {
                Logger.Error("Error validating schema.", e);
                throw;
            }

        }
*/
        [HttpPost]
        [Route("getJson")]
        public async Task<HttpResponseMessage> GetJsonAsync([FromUri] int reportVersionId)
        {
            try
            {
                if (!Request.Content.IsMimeMultipartContent())
                    throw new HttpResponseException(HttpStatusCode.UnsupportedMediaType);

                var provider = new MultipartMemoryStreamProvider();
                await Request.Content.ReadAsMultipartAsync(provider);
                Tuple<string, byte[]> data;
                if (provider.Contents.Count > 1)
                {
                    data = _reportService.GetJson(provider.Contents, reportVersionId);
                }
                else
                {
                    var content = provider.Contents.First();
                    var file = await content.ReadAsStreamAsync();

                    data = _reportService.GetJson(file, reportVersionId);
                }
                
                var response = new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new ByteArrayContent(data.Item2)
                };

                response.Content.Headers.Add("Content-Type", "application/json");
                response.Content.Headers.Add("Content-Length", data.Item2.Length.ToString());


                return response;
            }
            catch (Exception e)
            {
                Logger.Error("Error converting xml to json.", e);
                throw;
            }

        }

        [HttpPost]
        [Route("getXml")]
        public async Task<HttpResponseMessage> GetXml([FromUri] int reportVersionId)
        {
            try
            {
                var json = await Request.Content.ReadAsStreamAsync();

                var data = _reportService.GetXml(json, reportVersionId);

                var response = new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new ByteArrayContent(data.Item2)
                };

                response.Content.Headers.Add("Content-Type", "application/json");
                response.Content.Headers.Add("Content-Length", data.Item2.Length.ToString());
                response.Content.Headers.Add("Content-Disposition",
                "attachment;filename=" + HttpUtility.UrlEncode($"{data.Item1}.xml"));
                return response;
            }
            catch (Exception e)
            {
                Logger.Error("Error converting json to xml.", e);
                throw;
            }

        }

        [HttpPost]
        [Route("getExcel")]
        public async Task<HttpResponseMessage> GetExcel([FromUri] int reportVersionId)
        {
            try
            {
                var json = await Request.Content.ReadAsStreamAsync();

                var data = _reportService.GetExcel(json, reportVersionId);

                var response = new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new ByteArrayContent(data.Item2)
                };

                response.Content.Headers.Add("Content-Type", "application/json");
                response.Content.Headers.Add("Content-Length", data.Item2.Length.ToString());
                response.Content.Headers.Add("Content-Disposition",
                "attachment;filename=" + HttpUtility.UrlEncode($"{data.Item1}.xlsx"));

                return response;
            }
            catch (Exception e)
            {
                Logger.Error("Error converting json to excel.", e);
                throw;
            }

        }

        [HttpPost]
        [Route("exportExcel")]
        public HttpResponseMessage ExportExcel([FromUri] int reportVersionId, ExcelJson json)
        {
            try
            {
                    var data = _reportService.GetExcel(json.Json, reportVersionId);

                    var response = new HttpResponseMessage(HttpStatusCode.OK)
                    {
                        Content = new ByteArrayContent(data.Item2)
                    };

                    response.Content.Headers.Add("Content-Type", "application/octet-stream");
                    response.Content.Headers.Add("Content-Length", data.Item2.Length.ToString());
                    response.Content.Headers.Add("Content-Disposition",
                    "attachment;filename=" + HttpUtility.UrlEncode($"{data.Item1}.xlsx"));

                    return response;
            }
            catch (Exception e)
            {
                Logger.Error("Error converting json to excel.", e);
                throw;
            }

        }
/*
        [HttpGet]
        [Route("dropdown")]
        public IList<dynamic> GetDropdownOptions(string key)
        {

            if (string.IsNullOrEmpty(key))
            {
                return null;
            }

            string destination;
            if (key.Contains("dbview"))
            {
                if (key.Count(c => c == ':') != 1)
                {
                    return null;
                }
                var options = key.Split(':');
                var schema = options[0];
                destination = options[1];
            }
            else
            {
                destination = key;
            }

            return _reportService.GetDropDownListItems(destination);
        }
*/
/*
        [Route("listItems")]
        public IEnumerable<dynamic> GetDropdownListItemsFromView([FromUri] string dbView)
        {
            return _reportService.GetDropDownListItems(dbView);
        }
*/
/*
        [Route("menuItems")]
        public IEnumerable<dynamic> GetReportMenuItems()
        {
            return _reportService.GetReportMenuItems();
        }

*/
        [Route("reportDefinition")]
        public ReportDefinitionModel GetReportDefinition(int reportVersionId)
        {
            return _reportService.GetReportDefinitionByVersionId(reportVersionId);
        }

    }
}