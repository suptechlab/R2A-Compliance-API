﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using log4net;
using ReportMonitoring.Services;

namespace ReportMonitoring.PublicApi
{
    [System.Web.Http.RoutePrefix("api")]
    public class ReportController : ApiController
    {
        private static readonly ILog Logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private readonly IReportService _reportService;
        private readonly ISubmittedReportService _submittedService;

        public ReportController()
        {
            _submittedService = new SubmittedReportService();
            _reportService = new ReportService();
        }

        [System.Web.Http.Route("reports")]
        public IEnumerable<int> GetReports(int divisionId)
        {
            
            return _reportService.GetReportsOfDivision(divisionId);
        }

        [System.Web.Http.Route("divisions")]
        public IEnumerable<dynamic> GetDivisions()
        {
            return _reportService.GetDivisions();
        }


        [System.Web.Http.Route("configuration")]
        public HttpResponseMessage GetConfig([FromUri] int reportVersionId)
        {
            var data = _reportService.GetConfig(reportVersionId);

            try
            {

                var response = new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new ByteArrayContent(data.Item2)
                };

                response.Content.Headers.Add("Content-Type", "application/octet-stream");
                response.Content.Headers.Add("Content-Length", data.Item2.Length.ToString());
                response.Content.Headers.Add("Content-Disposition",
                "attachment;filename=" + HttpUtility.UrlEncode($"{data.Item1}.json"));

                return response;
            }
            catch (Exception e)
            {
                Logger.Error("get config", e);
                throw;
            }
        }
    }
}
