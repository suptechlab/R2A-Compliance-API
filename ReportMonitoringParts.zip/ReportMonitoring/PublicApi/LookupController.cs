﻿using System.Configuration;
using System.Linq;
using System.Web.Http;
using BSP.ReportDataConverter.Implementations;
using Pinecone.ReportFormula.Interpreter.Lookup;

namespace ReportMonitoring.PublicApi
{
    [RoutePrefix("api/lookup")]
    public class LookupController : ApiController
    {
        private readonly ILookupResolver _lookupResolver;
        
        public LookupController()
        {
            _lookupResolver = BspLookupService.GetService(ConfigurationManager.AppSettings["SqlConnectionString"]);
        }


        [HttpGet]
        [Route]
        public object Lookup([FromUri] LookupRequest lookupRequest)
        {
            return _lookupResolver.GetObject(lookupRequest.LookupType, lookupRequest.Expressions.ToList());
        }
    }

    public class LookupRequest
    {
        public string LookupType { get; set; }
        public string Property { get; set; }
        public string[] Expressions { get; set; }
    }
}