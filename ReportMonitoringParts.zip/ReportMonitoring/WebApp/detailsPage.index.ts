import * as React from "react";
import * as ReactDOM from "react-dom";
import * as ReactModal from "react-modal";

import Details from "./Container/Details";

ReactModal.setAppElement(document.getElementById("test"));

ReactDOM.render(React.createElement(Details, detailsPageConfigData.details), document.getElementById("test"));
