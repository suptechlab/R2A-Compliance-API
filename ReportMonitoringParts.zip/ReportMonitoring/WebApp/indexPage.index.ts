
import * as React from "react";
import * as ReactDOM from "react-dom";
import ReportListTable from "./Container/ReportListTable.jsx";
import BrowserStorage from "./Stores/BrowserStorage.js";
import ReportListTableStore from "./Stores/ReportListTableStore.js";


ReactDOM.render(React.createElement(ReportListTable, {
        browserStorage: new BrowserStorage("session"),
        store: new ReportListTableStore(indexPageConfigData)}),
        document.getElementById("izv-table"));


