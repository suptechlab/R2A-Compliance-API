import * as  React from "react";
import {DataStore} from "./DataStore";

export class ExcelExport extends React.Component<{ dataStore: DataStore }, {}> {


    private formRef;

    constructor(props) {
        super(props);
    }


    public render() {
        return (
            <form
                action={`/api/form/exportExcel?reportVersionId=${this.props.dataStore.reportVersionId}`}
                method="POST"
                onSubmit={this.handleSubmit}
                ref={(f) => (this.formRef = f )}
                target="_blank"
            >
                <input
                    className="hidden"
                    name="Json"
                    ref="jsonInput"
                    type="text"
                    value=""
                />
                <input
                    className="btn btn-primary"
                    type="submit"
                    value="Export to Excel"
                />
            </form>
        );
    }


    private handleSubmit = () => {
        //    var json = Validator.getDataJson(this.props.uiStore.mainNode);
        const jsonString = this.props.dataStore.getReportData();
        this.formRef.Json.value = JSON.stringify(jsonString);
        return true;
    }
}

