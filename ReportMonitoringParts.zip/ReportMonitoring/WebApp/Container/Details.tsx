"use strict";

import { observer } from "mobx-react";
import React from "react";
import AsyncReportViewer from "./AsyncReportViewer";
import { DataStore } from "./DataStore";

interface IDetailsProps {
    formValuesData: any;
    id: number;
    hasForms: boolean;
    reportVersionId: number;
    title: string;
}

interface IDetailsState {
    showViewer: boolean;
}

@observer
export default class Details extends React.Component<IDetailsProps, IDetailsState> {
    public static defaultProps: Partial<IDetailsProps> = {
        hasForms: true,
    };

    private store: any;

    constructor(props) {
        super(props);
        this.store = new DataStore(props.reportVersionId, 0, null);
    }

    public render() {
        const button = (
            <button
                className="btn btn-primary"
                type="buttom"
                value="Details"
                onClick={this.handleOpenDetails}
            >
                {"Details"}
            </button>
        );

        const viewer = (
            <div>
                <div className="page-header">
                    <h2>{this.props.title}</h2>
                </div>
                <div className="form-content">
                    <div className="row">
                        <AsyncReportViewer
                            store={this.store}
                            reportConfig={this.store.config}
                            reportData={this.props.formValuesData}
                            readOnly={true}
                        />
                    </div>
                </div>
            </div>
        );

        const canShow = this.props.hasForms;

        return (
            <div>
                <div>
                    {canShow && button}
                </div>
                {this.store.showViewer && viewer}
            </div >
        );
    }

    private handleOpenDetails = () => {
        this.store.getConfig();
    }
}
