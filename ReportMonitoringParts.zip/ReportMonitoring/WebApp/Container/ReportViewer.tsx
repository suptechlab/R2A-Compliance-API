import React, { Component } from "react";
import { ReportView } from "report-viewer";



export interface IReportViewProps {
    store: any;
    reportConfig: any;
    reportData?: any;
    readOnly?: boolean;
}

export default class ReportViewer extends Component<IReportViewProps, {}> {


    constructor(props) {
        super(props);
    }

    public render() {
        return (
            <ReportView
                reportConfig={this.props.reportConfig}
                reportData={this.props.reportData}
                readOnly={this.props.readOnly}
            />
        );
    }
}
