import React from "react";
import {asyncComponent} from "react-async-component";
import * as  ReactDOM from "react-dom";

export default asyncComponent({
    resolve: () => import("./ReportViewer"),
    LoadingComponent: () => <div>{"Loading component.."}</div>,
});
