/**
 * Created by Alan Fluka on 15.3.2017..
 */
/* global process */

'use strict';
import * as React from "react";
import {BootstrapTable, TableHeaderColumn} from "react-bootstrap-table";
import {observer} from 'mobx-react';
import moment from 'moment';
import * as _ from "lodash";

/* eslint-disable react/display-name */
const DevTool = (process.env.NODE_ENV === 'production') ? () => <div /> : require('mobx-react-devtools').default;
/* eslint-enable react/display-name */

const STORAGE_KEY_PREFIX = "ReportListTable_filter_";

const ReportListTable = observer(React.createClass({
    displayName: "ReportListTable",

    propTypes: {
        browserStorage: React.PropTypes.object.isRequired,
        store: React.PropTypes.object.isRequired
    },

    _onFilterChange(filterObj) {
        const fields = Object.keys(filterObj);
        let items = [];
        _.forEach(fields, (field) => items.push({key:STORAGE_KEY_PREFIX+field, value:filterObj[field].value}));
        this.props.browserStorage.setAllItems(items);
    },

    render() {
        const tableOptions = {
            noDataText: "... no data ...",
            sortName: "SubmissionTime",
            sortOrder: "desc",
            page: this.props.store.state.page,
            sizePerPageList: [5, 10, 20, 50, 100],
            sizePerPage: 100,
            expandBy: "column",
            onFilterChange: this._onFilterChange
        };
        let reportFilter = this.props.browserStorage.getItem(STORAGE_KEY_PREFIX + "ReportId");
        if(reportFilter === null) {
            reportFilter = -1;
        } else {
            reportFilter = parseInt(reportFilter);
        }
        const subjectFilter = this.props.browserStorage.getItem(STORAGE_KEY_PREFIX + "NazivSubjekta");
        const periodFilter = this.props.browserStorage.getItem(STORAGE_KEY_PREFIX + "Period");
        const userFilter = this.props.browserStorage.getItem(STORAGE_KEY_PREFIX + "Korisnik");
        let statusFilter = this.props.browserStorage.getItem(STORAGE_KEY_PREFIX + "Status");
        if(statusFilter === null) {
            statusFilter = -1;
        } else {
            statusFilter = parseInt(statusFilter);
        }

        return (
            <div>
                <DevTool/>
                {this.props.store.state.isLoading ? <div className="loader"/> :
                    (this.props.store.state.isError ?
                        <p className="text-danger">{"There was an error while trying to retreive the data"}</p> :
                        <BootstrapTable
                            hover
                            multiColumnSearch
                            pagination
                            striped
                            data={this.props.store.data}
                            keyField={"Id"}
                            options={tableOptions}
                            ref={(table) => {
                                this.table = table;
                                this.props.store.setPage(table);
                            }}
                        >
                            <TableHeaderColumn
                                dataField={"SubmittedReportId"}
                                searchable={false}
                                width={"75px"}
                            >
                                {"Submission Id"}
                            </TableHeaderColumn>
                            <TableHeaderColumn
                                dataSort
                                dataField={'ReportId'}
                                dataFormat={(value, row) => { return row.ReportName; }}
                                filter={{
                                    options: this.props.store.reportsSelect,
                                    type: "SelectFilter",
                                    placeholder: "All",
                                    condition: 'eq',
                                    defaultValue: reportFilter
                                }}
                                width={"130px"}
                            >
                                {"Report"}
                            </TableHeaderColumn>
                            <TableHeaderColumn
                                dataSort
                                dataField={"SubjectName"}
                                filter={{
                                    condition: "like",
                                    type: "TextFilter",
                                    placeholder: "...",
                                    defaultValue: subjectFilter
                                }}
                                tdStyle={{whiteSpace: "normal"}}
                                width={"20%"}
                            >
                                {"Subject Name"}
                            </TableHeaderColumn>
                            <TableHeaderColumn
                                dataSort
                                dataField={"SubmissionTime"}
                                dataFormat={(value) => {
                                    return moment(value).format('DD MMM YYYY h:mm:ss A');
                                }}
                                searchable={false}
                                width={"150px"}
                            >
                                {"Submission time"}
                            </TableHeaderColumn>
                            <TableHeaderColumn
                                filterFormatted
                                dataField={"ReportingPeriod"}
                                filter={{
                                    condition: "like",
                                    type: "TextFilter",
                                    placeholder: "...",
                                    defaultValue: periodFilter
                                }}
                                searchable={false}
                                width={"100px"}
                            >
                                {"Reporting period"}
                            </TableHeaderColumn>
                            <TableHeaderColumn
                                dataSort
                                dataField={"UserName"}
                                filter={{
                                    condition: "like",
                                    type: "TextFilter",
                                    placeholder: "...",
                                    defaultValue: userFilter
                                }}
                                tdStyle={{whiteSpace: "normal"}}
                                width={"10%"}
                            >
                                {"User"}
                            </TableHeaderColumn>
                            <TableHeaderColumn
                                dataSort
                                dataField={"Status"}
                                dataFormat={(value) => {
                                    "use strict";
                                    switch (value) {
                                        case 0:
                                            return 'Rejected';
                                        case 1:
                                            return 'Accepted';
                                        case 2:
                                            return 'Re-submitted';
                                    }
                                }}
                                filter={{
                                    type: "SelectFilter",
                                    options: {"0": "Rejected", "1": "Accepted", "2": "Re-submitted"},
                                    placeholder: "All",
                                    condition: 'eq',
                                    defaultValue: statusFilter
                                }}
                                width={"100px"}
                            >
                                {"Status"}
                            </TableHeaderColumn>
                            <TableHeaderColumn
                                dataAlign={"center"}
                                dataField={"Id"}
                                dataFormat={(id) => {
                                    return (
                                        <span>
                                            <a className={"btn btn-info"}
                                                href={"/Administration/Details/" + id.toString() + "?divisionId=" + this.props.store.currentDivision.toString()}
                                                title={"Details"}
                                            >
                                                <span className="glyphicon glyphicon-info-sign"/>
                                                {" Details"}
                                            </a>
                                        </span>
                                    );
                                }}
                                searchable={false}
                                width={"100px"}
                            />
                        </BootstrapTable>
                    )}
            </div>
        );
    }
}));
/*
 <a
 style={{ cursor: 'pointer' }}
 onClick={this._handleClickCleanFiltered}
 >Očisti filtre</a>
 </TableHeaderColumn>*/
/*
 ReportListTable.propTypes = {
 store: React.PropTypes.object
 };
 */

export default ReportListTable;