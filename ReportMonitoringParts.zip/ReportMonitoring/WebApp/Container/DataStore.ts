import { action, observable } from 'mobx';

export class DataStore {
    public reportData: any;
    public config: string;
    public reportViewRef: any;
    public reportVersionId: number;
    @observable public showViewer: boolean;
    private reportDefinitionId: number;

    public get uploadUrl() {
        return `api/form/import?reportVersionId=${this.reportVersionId}`;
    }

    constructor(reportVersionId: number, reportDefinitionId: number, reportData: any) {
        this.reportDefinitionId = reportDefinitionId;
        this.reportData = reportData;
        this.reportVersionId = reportVersionId;
        this.showViewer = false;
    }

    @action
    public updateReportData(newData: any) {
        this.reportViewRef.loadData(newData);
    }

    public getReportData() {
        return this.reportViewRef.getData();
    }

    @action
    private getConfig() {
        fetch(`/api/configuration?reportVersionId=${this.reportVersionId}`)
            .then((data) => data.json())
            .then((data) => {
                this.config = data;
                this.showViewer = true;
            })
            .catch((err) => console.log(err));
    }
}
