import * as mobservable from 'mobx';
import _ from 'lodash';

const ValidationMixin = {

    getInitialState: function () {
        return {
            valid: true
        }
    },

    componentDidMount: function () {
        this.disposer = mobservable.observe(this.props.storeLocator.store,this.props.fieldId, () => {
           this.validateComponent();
        });
    },

    validateComponent: function () {
        if (this.props.properties.required === true || this.props.properties.required === "true" ) {
            const value = this.props.storeLocator.store[this.props.fieldId];
            if (_.isUndefined(value) || _.isNull(value) || _.isEmpty(value)) {
                this.setState({valid: false});
            } else {
                this.setState({valid: true});
            }
        }
    },

    componentWillUnmount: function () {
        this.disposer()
    }

};

export default ValidationMixin;