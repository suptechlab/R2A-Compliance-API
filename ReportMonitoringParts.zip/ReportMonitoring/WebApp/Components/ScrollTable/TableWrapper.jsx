import React from 'react';

const TableWrapper = React.createClass({
    displayName: "TableWrapper",
    propTypes: {
        children: React.PropTypes.node,
        id: React.PropTypes.string,
        onScroll: React.PropTypes.func,
        scrollLeft: React.PropTypes.number,
        scrollTop: React.PropTypes.number,
        style: React.PropTypes.object
    },

    getDefaultProps: function () {
        return {
            onScroll: function () {
            },
            scrollLeft: -1,
            scrollTop: -1
        };
    },
    render: function () {
        return (
            <div
                ref={this.props.id}
                style={this.props.style}
                onScroll={this.props.onScroll}
            >
                {this.props.children}
            </div>
        );
    }
});
export default TableWrapper;