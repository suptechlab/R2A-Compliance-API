//TODO eliminate refs usage
/* eslint-disable react/no-string-refs */

import React from 'react';
import * as mobservableReact from 'mobx-react';
import ReactDOM from 'react-dom';
import * as _ from 'lodash';

const ColumnRow = React.createClass({
    displayName: "ColumnRow",

    propTypes: {
        columnWidths: React.PropTypes.object,
        depth: React.PropTypes.number,
        maxDepth: React.PropTypes.number,
        row: React.PropTypes.array
    },

    getInitialState: function () {
        return {};
    },

    render: function () {
        const columns = [];
        for (let i = 0; i < this.props.row.length; i++) {
            const column = this.props.row[i];

            let scope = 'col';
            let rowSpan = 1;
            if (column.leafIndex > -1) {
                rowSpan = this.props.maxDepth - this.props.depth + 1;
            }
            if (column.colSpan > 1) {
                scope = 'colgroup';
            }
                
            
            if (column.leafIndex > -1) {
                columns.push(
                    <th
                        className="columnHeader"
                        colSpan={column.colSpan}
                        key={'col_'+i}
                        ref={'leaf_'+column.leafIndex.toString()}
                        rowSpan={rowSpan}
                        scope={scope}
                        style={{width: this.props.columnWidths[column.leafIndex]}}
                    >
                        {column.title}
                    </th>
                );
            }
            else {
                columns.push(
                    <th
                        className="columnHeader"
                        colSpan={column.colSpan}
                        key={'col_'+i}
                        rowSpan={rowSpan}
                        scope={scope}
                    >
                        {column.title}
                    </th>
                );
            }
        }
        return (
            <tr>
                {columns}
            </tr>
        );
    }

});

const ColumnsTable = mobservableReact.observer(React.createClass({
    displayName: "ColumnsTable",

    propTypes: {
        children: React.PropTypes.node,
        uiStore: React.PropTypes.object
    },

    getInitialState: function () {
        return {
            structure: this._transformColumnsTree(this.props.uiStore.get.columns)
        };
    },

    componentWillReceiveProps: function (nextProps) {
        this.setState({
            structure: this._transformColumnsTree(nextProps.uiStore.get.columns)
        });
    },

    _recursive: function(node, row, column, maxDepth, maxSpan, rows, leaves, getLeafIndex) {
        if(_.isNil(rows[row])) {
            rows[row] = [];
        }

        maxDepth = Math.max(maxDepth, row + 1);
        maxSpan = Math.max(maxSpan, column + 1);
        let lastColumn = column;

        if (_.isNil(node.children) || node.children.length === 0) {
            rows[row].push({
                colSpan: 1, title: node.title, leafIndex: getLeafIndex()
            });
            leaves.push(row);
        }
        else {
            const startColumn = column;
            for (let i = 0; i < node.children.length; i++) {
                const result = this._recursive(node.children[i], row + 1, lastColumn, maxDepth, maxSpan, rows, leaves, getLeafIndex);
                maxDepth = Math.max(maxDepth, result.maxDepth);
                maxSpan = Math.max(maxSpan, result.maxSpan);
                lastColumn = result.lastColumn+1;
            }
            lastColumn--;

            rows[row].push({
                colSpan: lastColumn - startColumn + 1, title: node.title, leafIndex: -1
            });
        }
        return { maxDepth: maxDepth, maxSpan: maxSpan, lastColumn: lastColumn }
        
    },


    _transformColumnsTree: function (content) {
        const rows = [];
        const leaves = [];
        let maxSpan = 0;
        let maxDepth = 0;
        let leafIndex = -1;
        const accIndex = function () {
            leafIndex += 1;
            return leafIndex;
        };
        let lastColumn = 0;

        for (let i = 0; i < content.length; i++) {
            const result = this._recursive(content[i], 0, lastColumn, maxDepth, maxSpan, rows, leaves, accIndex);
            maxDepth = Math.max(maxDepth, result.maxDepth);
            maxSpan = Math.max(maxSpan, result.maxSpan);
            lastColumn = result.lastColumn + 1;
        }

        return {rows: rows, maxSpan: maxSpan, maxDepth: maxDepth, leaves: leaves}
    },



    getRenderedWidths: function () {
        const structure = this.state.structure;
        const widths = new Array(structure.maxSpan);

        for (let i = 0; i < structure.maxSpan; i++) {
            const leafRow = structure.leaves[i];
            const node = ReactDOM.findDOMNode(this.refs['col_row_' + leafRow].refs['leaf_' + i]);
            widths[i] = node.offsetWidth;
        }
        return widths;
    },

    render: function () {
        const store = this.props.uiStore;
        const rows = [];
        const structure = this.state.structure;
        for (let i = 0; i < structure.maxDepth; i++) {
            rows.push(
                <ColumnRow
                    columnWidths={store.get.columnWidths}
                    depth={i+1}
                    key={'col_row_'+i}
                    maxDepth={structure.maxDepth}
                    ref={'col_row_'+i}
                    row={structure.rows[i]}
                />

            );
        }
        return (
            <table
                className="table table-bordered scrolltable-section"
                style={{width:store.get.totalSize.width, minWidth: store.get.totalSize.width}}
            >
                <thead>
                    {rows}
                </thead>
                {this.props.children}
            </table>
        );
    }
}));

export default ColumnsTable;