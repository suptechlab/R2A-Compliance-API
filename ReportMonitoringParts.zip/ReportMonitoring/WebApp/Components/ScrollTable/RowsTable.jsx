//TODO eliminate refs usage
/* eslint-disable react/no-string-refs */

import React from 'react';
import * as mobservableReact from 'mobx-react';
import ReactDOM from 'react-dom';
import * as _ from 'lodash';


const RowDepths = React.createClass({
    displayName: "RowDepths",

    propTypes: {
        maxDepth: React.PropTypes.number,
        row: React.PropTypes.array,
        rowHeight: React.PropTypes.string
    },

    render: function () {
        const depths = [];

        for (let i = 0; i < this.props.row.length; i++) {
            const node = this.props.row[i];

            let colSpan = 1;
            let scope = 'row';
            if (node.rowSpan > 1) {
                scope = 'rowgroup';
            }
            if (node.isLeaf) {
                colSpan = this.props.maxDepth - node.depth + 1;
            }
            depths.push(
                <th
                    className="rowHeader"
                    colSpan={colSpan}
                    key={'col_'+i}
                    rowSpan={node.rowSpan}
                    scope={scope}
                >{node.title}</th>
            );
        }

        return (
            <tr style={{height: this.props.rowHeight}}>
                {depths}
            </tr>
        );
    }
});

const RowsTable = mobservableReact.observer(React.createClass({
    displayName: "RowsTable",

    propTypes: {
        uiStore: React.PropTypes.object
    },

    getInitialState: function () {
        return {
            structure: this._transformRowsTree(this.props.uiStore.get.rows)
        };
    },

    _recursive: function (node, rowNum, depth, maxDepth, rows) {
        if (rows[rowNum] == null)
            rows[rowNum] = [];

        maxDepth = Math.max(maxDepth, depth);
        let lastRow = rowNum;

        if (_.isNil(node.children) || node.children.length === 0) {
            rows[rowNum].push({
                rowSpan: 1, depth: depth, title: node.title, isLeaf: true
            });

        }
        else {
            const index = rows[rowNum].length;
            rows[rowNum][index] = {
                rowSpan: 0, depth: depth, title: node.title, isLeaf: false
            };
            const startRow = rowNum;
            for (let i = 0; i < node.children.length; i++) {
                const res = this._recursive(node.children[i], lastRow, depth + 1, maxDepth, rows);
                lastRow = res.lastRow + 1;
                maxDepth = Math.max(maxDepth, res.maxDepth);
            }
            lastRow--;
            rows[rowNum][index].rowSpan = lastRow - startRow + 1;
        }

        return {lastRow: lastRow, maxDepth: maxDepth};
    },

    _transformRowsTree: function (rowsTree) {
        const headerRows = [];
        let maxSpan = 0;
        let maxDepth = 0;
        let lastRow = 0;

        for (let i = 0; i < rowsTree.length; i++) {
            let res = this._recursive(rowsTree[i], lastRow, 1, maxDepth, headerRows);
            lastRow = res.lastRow + 1;
            maxSpan = Math.max(maxSpan, lastRow);
            maxDepth = Math.max(maxDepth, res.maxDepth);
        }

        return {headerRows: headerRows, maxDepth: maxDepth, maxSpan: maxSpan};
    },

    getRenderedHeights: function () {
        const numRows = this.state.structure.maxSpan;
        const heights = new Array(numRows);
        for (let i = 0; i < numRows; i++) {
            heights[i] = ReactDOM.findDOMNode(this.refs['row_' + i.toString()]).offsetHeight;
        }
        return heights;
    },

    render: function () {
        const structure = this.state.structure;
        const rows = [];
        for (let i = 0; i < structure.maxSpan; i++) {
            rows.push(
                <RowDepths
                    key={"row_" + i}
                    maxDepth={structure.maxDepth}
                    ref={"row_" + i}
                    row={structure.headerRows[i]}
                    rowHeight={this.props.uiStore.get.rowHeights[i]}
                />
            );
        }

        return (
            <table className="table table-bordered scrolltable-section">
                <thead>
                    {rows}
                </thead>
            </table>
        );
    }
}));
export default RowsTable;
