import React from 'react';
import * as mobservableReact from 'mobx-react';
import TableStore from './TableStore';
import {OpenTableLocator, OpenTableRowLocator} from '../../Stores/DataStore';
import AddRowButton from './AddRowButton';
import RemoveRowButton from './RemoveRowButton';
import * as _ from 'lodash';
import InputSwitcher from '../InputSwitcher';
import {DataRow} from './DataTable';
import ColumnsTable from './ColumnsTable';

const AddRowTable = mobservableReact.observer(React.createClass({

    displayName: "AddRowTable",

    propTypes: {
        fieldId: React.PropTypes.string,
        formId: React.PropTypes.string,
        initialData: React.PropTypes.object,
        readOnly: React.PropTypes.bool
    },

    getDefaultProps: function () {
        return {
            readOnly: false
        }
    },

    getInitialState: function () {
        return {
            uiStore: new TableStore(),
            fieldDefs: undefined,
            buttonColumn: 1,
            label: ""
        };
    },
    componentWillMount: function () {
        this.initFromProperties(this.props);
    },

    componentWillReceiveProps: function (nextProps) {
        this.initFromProperties(nextProps)
    },

    initFromProperties: function (nextProps) {
        const data = nextProps.initialData;
        const s = new TableStore();

        //extract ui info from data
        const tableInfo = data.properties;
        const headers = tableInfo.headers.slice(0);
        headers.push({title: "", required: false});
        s.setValue('columns', headers);

        //ui defaults
        s.setValue('columnWidths', _.fill(new Array(tableInfo.fields.length + 1), 'auto'));
        s.setValue('totalSize', {width: 'auto', height: 'auto'});
        s.setValue('minimumSize', {width: 'auto', height: 'auto'});
        s.setValue('visibleSize', {width: 'auto', height: 'auto'});

        this.setState({
            label: data.title,
            fieldDefs: tableInfo.fields,
            buttonColumn: tableInfo.fields.length,
            uiStore: s
        });
    },


    gridElementRenderer: function (row, column) {
        if (column == this.state.buttonColumn) {
            if (this.props.readOnly)
                return (
                    <span>{"Vnos "+(row + 1)}</span> // TODO prijevod
                );

            const rowNum = OpenTableLocator(this.props.formId, this.props.fieldId).store.length;
            if (rowNum === 1) {
                return (
                    <span>
                        <AddRowButton
                            fieldId={this.props.fieldId}
                            formId={this.props.formId}
                            rowFields={this.state.fieldDefs}
                            rowNum={row}
                        />
                    </span>
                );
            }
            return (
                <span className="btn-group scrolltable-button-cell">
                    <AddRowButton
                        fieldId={this.props.fieldId}
                        formId={this.props.formId}
                        rowFields={this.state.fieldDefs}
                        rowNum={row}
                    />
                    <RemoveRowButton
                        fieldId={this.props.fieldId}
                        formId={this.props.formId}
                        rowNum={row}
                    />
                </span>
            );
        }


        return (
            <span>
                <InputSwitcher
                    className="scrolltable-cell-expand"
                    fieldData={this.props.initialData.properties.fields[column]}
                    fieldId={this.props.initialData.properties.fields[column].xmlNode}
                    readOnly={this.props.readOnly}
                    storeLocator={OpenTableRowLocator(this.props.formId, this.props.fieldId, row)}
                />
            </span>
        );
    },

    render: function () {
        const source = OpenTableLocator(this.props.formId, this.props.fieldId).store;
        const rows = [];
        for (let i = 0; i < source.length; i++) {
            rows.push(
                <DataRow
                    columns={this.state.uiStore.get.columnWidths}
                    contentRenderer={this.gridElementRenderer}
                    key={"row_" + i}
                    rowHeight="auto"
                    rowNum={i}
                />
            );
        }

        return (
            <div className="addrowtable col-xs-12">
                <div><label className="control-label">{this.state.label}</label></div>
                <div>
                    <ColumnsTable uiStore={this.state.uiStore}>
                        <tbody>
                            {rows}
                        </tbody>
                    </ColumnsTable>
                </div>
            </div>
        );
    }

}));

export default AddRowTable;