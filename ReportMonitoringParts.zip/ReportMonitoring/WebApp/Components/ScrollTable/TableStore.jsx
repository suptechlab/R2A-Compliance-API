import * as mobservable from 'mobx';

const TableStore = function () {

    const _data = mobservable.observable({
        columns: [],
        rows: [],
        grid: [],
        columnWidths: [],
        rowHeights: [],
        visibleSize: {width: 'auto', height: 'auto'},
        totalSize: {width: 'auto', height: 'auto'},
        scroll: {top: 0, left: 0, width: 0, height: 0}
    });

    const setValue = function (key, newValue) {
        _data[key] = newValue;
    };


    return {setValue: setValue, get: _data}
};

export default TableStore;
