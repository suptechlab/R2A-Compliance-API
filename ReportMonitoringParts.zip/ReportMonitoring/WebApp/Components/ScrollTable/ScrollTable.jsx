//TODO eliminate refs usage
/* eslint-disable react/no-string-refs */

import React from 'react';
import * as mobservableReact from 'mobx-react';
import ReactDOM from 'react-dom';
import TableStore from './TableStore';
import _ from 'lodash';
const $ = require('jquery');
import InputSwitcher from '../InputSwitcher';
import {ScrollTableLocator} from '../../Stores/DataStore';
import TableWrapper from './TableWrapper';
import ColumnsTable from './ColumnsTable';
import RowsTable from './RowsTable';
import DataTable from './DataTable';

const ScrollTable = mobservableReact.observer(React.createClass({
    displayName: "ScrollTable",

    propTypes: {
        fieldId: React.PropTypes.string,
        formId: React.PropTypes.string,
        initialData: React.PropTypes.object,
        readOnly: React.PropTypes.bool
	},
	
    getDefaultProps: function(){
        return {
            readOnly: false
        }
    },
    
	getInitialState: function() {
		return { 
                uiStore: new TableStore(),
                title: ""
            };
	},
	
    componentWillMount: function() {
        const s = this.state.uiStore;
        this.setState({
            uiStore: s,
            title: this.props.initialData.title
        });
        const tableData = this.props.initialData.properties;
        
        //extract from data

        s.setValue('columns', tableData.headers.slice(0));

        let rows = tableData.rows;
        if(_.isUndefined(rows))
            rows = [{title:""}];
        s.setValue('rows',rows.slice(0));
        s.setValue('grid',tableData.fields.slice(0));
        //defaults
        s.setValue('columnWidths',_.fill(new Array(tableData.fields[0].length),'auto'));
        s.setValue('rowHeights',_.fill(new Array(tableData.fields.length),'auto'));
        s.setValue('totalSize',{width:'auto',height:'auto'});
        s.setValue('minimumSize',{width:'auto',height:'auto'});
        s.setValue('visibleSize',{width:'auto',height:'auto'});

    },
	
	componentDidMount: function() {
		//synchronize widths and heights of table elements
        const columnsWidths = this.refs.columns.getRenderedWidths();
        const gridWidths = this.refs.grid.getRenderedWidths();
        const syncedWidths = _.map(columnsWidths, function (elem, i) {
            return Math.max(elem, gridWidths[i]);
        });
        
        const totalWidth = _.sum(syncedWidths) + 'px';
        const newWidths = _.map(syncedWidths, function (elem) {
            return elem.toString() + 'px';
        });
        this.state.uiStore.setValue('columnWidths',newWidths);
        
        
        const rowsHeights = this.refs.rows.getRenderedHeights();
        const gridHeights = this.refs.grid.getRenderedHeights();
        const syncedHeights = _.map(rowsHeights, function (elem, i) {
            return Math.max(elem, gridHeights[i]);
        });
        const totalHeight = _.sum(syncedHeights) + 'px';
        this.state.uiStore.setValue('rowHeights',_.map(syncedHeights,function(e){return e+'px';}))
        
        this.state.uiStore.setValue('totalSize',{ width: totalWidth, height: totalHeight });
        this._handleResize();

        window.addEventListener('resize', this._handleResize);
	},
    
    componentDidUpdate: function() {
        if(this._componentDidResize)
        {
            this._componentDidResize = false;
            $(this._node('columnsWrapper')).width(this._node('gridWrapper').clientWidth);
            $(this._node('rowsWrapper')).height(this._node('gridWrapper').clientHeight);
        }
        
    },

	componentWillUnmount: function() {
		window.removeEventListener('resize', this._handleResize);
	},

    _componentDidResize: false,

    _handleScroll: function() {

        
        const gridWrapper = this._node('gridWrapper');
        const columnsWrapper = this._node('columnsWrapper');
        const rowsWrapper = this._node('rowsWrapper');
        columnsWrapper.scrollLeft = gridWrapper.scrollLeft;
        rowsWrapper.scrollTop = gridWrapper.scrollTop;
            
    },
    
    _resizeId: 0,
    _resizeDone: function() {
        const visibleWidth = (this._node('outer').clientWidth - this._node('rows').clientWidth);
        const visibleHeight = (this._node('outer').clientHeight - this._node('columns').clientHeight);
        this._componentDidResize = true;
        this.state.uiStore.setValue('visibleSize',{width: visibleWidth+'px', height: visibleHeight+'px'});
    },
    
    _handleResize: function() {
        clearTimeout(this.resizeId);
        this.resizeId = setTimeout(this._resizeDone,500);
	},

    _node: function(ref) {
        return ReactDOM.findDOMNode(this.refs[ref]);
    },
    
    _renderGridElement: function(row,column) {
        const cell = this.state.uiStore.get.grid[row][column];
        return (
            <InputSwitcher
                className="scrolltable-cell-expand"
                fieldData={cell}
                fieldId={cell.type == 'empty' ? "" : cell.xmlNode}
                readOnly={this.props.readOnly}
                storeLocator={ScrollTableLocator(this.props.formId, this.props.fieldId)}
            />
        );
    },
	
	render: function() {
        const store = this.state.uiStore;
		return (
    <div className="col-xs-12">
        <label className="control-label">{this.state.title}</label>
        <div
            className='scrolltable'
            ref="outer"
        >
            <table>
                <tbody>
                    <tr>
                        <td />
                        <td>
                            <TableWrapper
                                id="columnsWrapper"
                                ref='columnsWrapper'
                                style={{width: store.get.visibleSize.width, overflow:'hidden'}}
                            >
                                <ColumnsTable
                                    ref='columns'
                                    uiStore={this.state.uiStore}
                                />
                            </TableWrapper>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <TableWrapper
                                id="rowsWrapper"
                                ref="rowsWrapper"
                                style={{height: store.get.visibleSize.height, overflow:'hidden'}}
                            >
                                <RowsTable
                                    ref="rows"
                                    uiStore={this.state.uiStore}
                                />
                            </TableWrapper>
                        </td>
                        <td>
                            <TableWrapper
                                id="gridWrapper"
                                ref="gridWrapper"
                                style={{
                                    width: store.get.visibleSize.width,
                                    height: store.get.visibleSize.height,
                                    overflow: 'scroll'}}
                                onScroll={this._handleScroll}
                            >
                                <DataTable
                                    cellRenderer={this._renderGridElement}
                                    ref="grid"
                                    uiStore={this.state.uiStore}
                                />
                            </TableWrapper>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
		);	
	}
}));

export default ScrollTable;