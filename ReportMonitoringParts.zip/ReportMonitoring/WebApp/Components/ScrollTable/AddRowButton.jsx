﻿import React from 'react';
import DataStore from '../../Stores/DataStore';

export const AddRowButton = React.createClass({
    displayName: "AddRowButton",

    propTypes: {
        fieldId: React.PropTypes.string,
        formId: React.PropTypes.string,
        rowFields: React.PropTypes.object,
        rowNum: React.PropTypes.number
    },

    _handleClick: function () {
        DataStore.addTableRow(this.props.formId, this.props.fieldId,
            this.props.rowNum + 1, this.props.rowFields);
    },

    render: function () {
        return (
            <div
                className="btn btn-primary btn-add-row"
                onClick={this._handleClick}
            >
                {"Dodaj"} // TODO prijevod
            </div>
        );
    }
});
export default AddRowButton;