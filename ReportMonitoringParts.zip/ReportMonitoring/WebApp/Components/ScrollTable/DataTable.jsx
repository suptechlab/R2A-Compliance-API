//TODO eliminate refs usage
/* eslint-disable react/no-string-refs */

import React from 'react';
import * as mobservableReact from 'mobx-react';
import ReactDOM from 'react-dom';

export const DataRow = React.createClass({
    displayName: "DataRow",

    propTypes: {
        children: React.PropTypes.node,
        columns: React.PropTypes.oneOfType([React.PropTypes.array, React.PropTypes.object]),
        contentRenderer: React.PropTypes.func,
        rowHeight: React.PropTypes.string,
        rowNum: React.PropTypes.number
    },

    getInitialState: function () {
        return {};
    },

    getRenderedWidths: function () {
        const widths = [];

        for (let i = 0; i < this.props.columns.length; i++) {
            const node = ReactDOM.findDOMNode(this.refs['elem_0_' + (i).toString()]);
            widths[i] = node.offsetWidth;
        }
        return widths;
    },

    render: function () {
        const columns = [];
        for (let i = 0; i < this.props.columns.length; i++) {
            columns.push(
                <td key={'elem_' + this.props.rowNum + '_' + i}
                    ref={'elem_' + this.props.rowNum + '_' + i}
                    style={{width: this.props.columns[i], height: this.props.rowHeight}}
                >
                    {this.props.contentRenderer(this.props.rowNum, i)}
                </td>
            );
        }
        return (
            <tr>
                {columns}
                {this.props.children}
            </tr>
        );
    }

});

const DataTable = mobservableReact.observer(React.createClass({
    displayName: "DataTable",

    propTypes: {
        cellRenderer: React.PropTypes.func,
        uiStore: React.PropTypes.object
    },

    getRenderedWidths: function () {
        return this.refs.row_0.getRenderedWidths();
    },

    getRenderedHeights: function () {
        const heights = new Array(this.props.uiStore.get.rowHeights.length);

        for (let i = 0; i < this.props.uiStore.get.rowHeights.length; i++) {
            heights[i] = ReactDOM.findDOMNode(this.refs['row_' + i]).offsetHeight;
        }
        return heights;
    },

    render: function () {
        const rowsRender = [];
        const store = this.props.uiStore;
        const totalSize = store.get.totalSize;

        for (let i = 0; i < store.get.rowHeights.length; i++) {
            rowsRender.push(
                <DataRow
                    columns={store.get.columnWidths}
                    contentRenderer={this.props.cellRenderer}
                    key={'row_' + i}
                    ref={'row_' + i}
                    rowHeight={store.get.rowHeights[i]}
                    rowNum={i}
                    tableWidth={totalSize.width}
                />
            );
        }

        return (
            <table
                className="table table-bordered scrolltable-section"
                ref="grid"
                style={{
                    width: totalSize.width,
                    minWidth: totalSize.width,
                    height: totalSize.height,
                    minHeight: totalSize.height
                }}
            >
                <tbody >
                    {rowsRender}
                </tbody>
            </table>
        );
    }
}));
export default DataTable;

