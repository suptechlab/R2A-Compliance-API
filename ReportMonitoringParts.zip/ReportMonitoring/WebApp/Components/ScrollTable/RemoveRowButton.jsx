﻿import React from 'react';
import DataStore from '../../Stores/DataStore';

export const RemoveRowButton = React.createClass({
    displayName: "RemoveRowButton",
    propTypes: {
        fieldId: React.PropTypes.string,
        formId: React.PropTypes.string,
        rowNum: React.PropTypes.number
    },

    _handleClick: function () {
        DataStore.removeTableRow(this.props.formId, this.props.fieldId,
            this.props.rowNum);
    },


    render: function () {
        return (
            <div
                className="btn btn-default btn-add-row"
                onClick={this._handleClick}
            >{'Brisanje'}</div> // TODO prijevod
        );
    }
});
export default RemoveRowButton;