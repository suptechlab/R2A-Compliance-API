import React from 'react';

const Switch = React.createClass({
    displayName: "Switch",

    propTypes: {                
        disabled: React.PropTypes.boolean,
        status: React.PropTypes.number,
        onSwitch: React.PropTypes.func,
        statuses: React.PropTypes.array
	},
    
    getDefaultProps: function()
    {
        return {
            disabled: false,
            status: -1,
            onSwitch: function (newStatus) {
                console.log(newStatus);
            },
            statuses: []
        }
    },

    _handleClick: function(newState)
    {
        const self = this;
        return function()
        {
            if (!self.props.disabled) {
                self.props.onSwitch(newState);
            }
        }
    },

    render: function() {
        return(
            <div className="btn-group">
                <button
                    className={(this.props.disabled?"disabled ":"")+(this.props.status===1?"btn btn-success":"btn btn-secondary")}
                    type="button"
                    onClick={this._handleClick(1)}
                >{this.props.statuses[1]}</button>
                <button
                    className={(this.props.disabled ? "disabled " : "") + (this.props.status===2?"btn btn-success":"btn btn-secondary")}
                    type="button"
                    onClick={this._handleClick(2)}
                >{this.props.statuses[2]}
                </button>
                <button
                    className={(this.props.disabled ? "disabled " : "") + (this.props.status===0?"btn btn-success":"btn btn-secondary")}
                    type="button"
                    onClick={this._handleClick(0)}
                >{this.props.statuses[0]}
                </button>
            </div>
        )

    }
});

export default Switch;