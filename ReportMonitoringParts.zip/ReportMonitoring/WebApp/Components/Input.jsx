﻿import React from 'react';
import * as mobservableReact from 'mobx-react';
import ValidationMixin from '../Mixins/ValidationMixin';
import classNames from '../Helpers/classNames';

const Input = mobservableReact.observer(React.createClass({
    displayName: "Input",
    propTypes: {
        className: React.PropTypes.string,
        fieldId: React.PropTypes.string.isRequired,
        placeholder: React.PropTypes.string,
        readOnly: React.PropTypes.bool,
        required: React.PropTypes.bool,
        storeLocator: React.PropTypes.object.isRequired
    },

    mixins: [ValidationMixin],

    getDefaultProps: function () {
        return {
            required: false,
            readOnly: false
        }
    },

    _handleChange: function (e) {
        this.props.storeLocator.set(this.props.fieldId, e.target.value);
    },


    render: function () {
        const className = classNames(this.props.className, {'error' : !this.state.valid});
        return (
            <input
                className={className}
                placeholder={this.props.placeholder}
                readOnly={this.props.readOnly}
                type="text"
                value={this.props.storeLocator.store[this.props.fieldId]}
                onChange={this._handleChange}
            />
        )
    }
}));
export default Input;