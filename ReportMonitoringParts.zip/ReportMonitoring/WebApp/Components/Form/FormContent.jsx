import React from 'react';
import * as mobservableReact from 'mobx-react';
import FieldInput from './FieldInput';
import InputSwitcher from '../InputSwitcher';
import AddRowTable from '../ScrollTable/AddRowTable';
import ScrollTable from '../ScrollTable/ScrollTable';
import {FormLocator} from '../../Stores/DataStore';

export const FormContent = mobservableReact.observer(React.createClass({
    displayName: "FormContent",

    propTypes: {
        readOnly: React.PropTypes.bool,
        uiStore: React.PropTypes.object.isRequired
    },

    getDefaultProps: function () {
        return {
            readOnly: false
        }
    },

    render: function () {
        const formData = this.props.uiStore.activeFormData();
        let fields = formData.fields.map((field, index) => (
            <FormField
                fieldData={field}
                formId={formData.xmlNode}
                key={formData.xmlNode +  index}
                readOnly={this.props.readOnly}
            />)
        );
        return (
            <div>
                {fields}
            </div>
        );
    }
}));

export const FormField = React.createClass({
    displayName: "FormField",

    propTypes: {
        fieldData: React.PropTypes.object.isRequired,
        formId: React.PropTypes.string.isRequired,
        readOnly: React.PropTypes.bool
    },

    getDefaultProps: function () {
        return {
            readOnly: false
        }
    },

    render: function () {
        switch (this.props.fieldData.type) {
            case "opentable":
                return (
                    <AddRowTable
                        fieldId={this.props.fieldData.xmlNode}
                        formId={this.props.formId}
                        initialData={this.props.fieldData}
                        readOnly={this.props.readOnly}
                    />);
            case "table":
                return (
                    <ScrollTable
                        fieldId={this.props.fieldData.xmlNode}
                        formId={this.props.formId}
                        initialData={this.props.fieldData}
                        readOnly={this.props.readOnly}
                    />);
            default:
                return (
                    <FieldInput
                        label={this.props.fieldData.title}
                        required={this.props.fieldData.properties.required}
                    >
                        <InputSwitcher
                            fieldData={this.props.fieldData}
                            fieldId={this.props.fieldData.xmlNode}
                            readOnly={this.props.readOnly}
                            storeLocator={FormLocator(this.props.formId)}
                        />
                    </FieldInput>
                );
        }


    }
});