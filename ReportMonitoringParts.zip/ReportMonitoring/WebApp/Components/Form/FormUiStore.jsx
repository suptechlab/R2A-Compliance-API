import * as mobservable from 'mobx';

const FormUiStore = function(data){
    mobservable.extendObservable(this, {
        hideAlert:true,
        validationResult: [],
        mainNode : data.xmlNode,
        formHeader: data.header,
        formData: data.forms,
        activeFormIndex: 0,
        activeFormData: function() {
            return this.formData[this.activeFormIndex];
        }
    });

    this.setValidationResult = function setValidationResult (data){
        this.validationResult = data;
        this.hideAlert = false;
    }
};

export default FormUiStore;