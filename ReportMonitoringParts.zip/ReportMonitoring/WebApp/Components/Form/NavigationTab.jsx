import React from 'react';
import * as mobservableReact from 'mobx-react';

const NavigationTab = mobservableReact.observer(React.createClass({
    displayName: "NavigationTab",

    propTypes: {
        uiStore: React.PropTypes.object.isRequired
    },

    _handleChangeActive: function(index){
        this.props.uiStore.activeFormIndex = index;
    },

    render: function() {
        const activeFormIndex = this.props.uiStore.activeFormIndex;
        const formData = this.props.uiStore.formData;
        let selectionOptions = formData.map( (option,index) => (
            <li
                className={index===activeFormIndex ? "active": null}
                key={index}
            >
                <a
                    style={{cursor: 'pointer'}}
                    onClick={this._handleChangeActive.bind(this,index)}
                >
                    {option.shortTitle}
                </a>
            </li>));
        return (
            <ul className="nav nav-pills">
                {selectionOptions}
            </ul>
        );

    }
}));

export default NavigationTab;