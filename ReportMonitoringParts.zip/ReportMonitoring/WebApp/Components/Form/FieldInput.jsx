import React from 'react';

const FieldInput = React.createClass({
    displayName: "FieldInput",

    propTypes: {
        children: React.PropTypes.node,
        label: React.PropTypes.string,
        required: React.PropTypes.bool,
        tooltip: React.PropTypes.string
    },

    render: function () {
        return (
            <div className={this.props.required === true ? "form-group required": "form-group"}>
                <label className="control-label col-xs-4 col-sm-2">{this.props.label}</label>
                <div className="col-xs-8 col-sm-10">
                    {this.props.children}
                </div>
            </div>
        );

    }
});
export default FieldInput;