﻿import React from 'react';
import * as mobservableReact from 'mobx-react';
const $ = require('jquery');
import _ from 'lodash';

const FormDropDown = mobservableReact.observer(React.createClass({
    displayName: "FormDropDown",

    propTypes: {
        className: React.PropTypes.string,
        defaultValue: React.PropTypes.string,
        fieldId: React.PropTypes.string.isRequired,
        readOnly: React.PropTypes.bool,
        required: React.PropTypes.bool,
        source: React.PropTypes.oneOfType([React.PropTypes.string, React.PropTypes.object]).isRequired,
        storeLocator: React.PropTypes.object.isRequired
    },
    getDefaultProps: function () {
        return {
            required: false,
            defaultValue: "default",
            readOnly: false
        };
    },

    getInitialState: function () {
        return this._initFromProperties(this.props);
    },

    componentWillReceiveProps: function (nextProps) {
        this.setState(this._initFromProperties(nextProps));
    },

    _initOptions: function (source) {
        let options = [];

        if (!_.isUndefined(source) && !_.isNull(source)) {
            options = source.map(function (option) {
                return (
                    <option
                        key={option["value"]}
                        value={option["value"]}
                    >
                        {option["text"]}
                    </option>
                )
            });
        }

        if (!this.props.required) {
            const emptyOption = (
                <option
                    key="default"
                    value="default"
                >
                    {'---'}
                </option>
            );
            options.splice(0, 0, emptyOption);
        }
        return options;
    },

    _initFromProperties: function (props) {
        let source = props.source;

        if (typeof source === 'string' || source instanceof String) {
            const self = this;
            $.get('/api/form/dropdown?key=' + encodeURIComponent(source), function (data) {
                if (typeof data === 'string' || data instanceof String) {
                    source = JSON.parse(data);
                } else {
                    source = data;
                }

                self.setState({options: self._initOptions(source)});
            }).fail(function () {
                console.log('Error fetching FormDropDown options from "' + source + '"');
            });

            return {options: this._initOptions(undefined)}
        }
        else {
            return {options: this._initOptions(source)};
        }
    },

    _handleChange: function (e) {
        if (!this.props.readOnly)
            this.props.storeLocator.set(this.props.fieldId, e.target.value);
    },

    render: function () {
        let value = this.props.storeLocator.store[this.props.fieldId];
        if (_.isUndefined(value) || _.isNull(value))
            value = this.props.defaultValue;

        return (
            <select
                className={this.props.className}
                disabled={this.props.readOnly}
                value={value}
                onChange={this._handleChange}
            >
                {this.state.options}
            </select>
        );
    }
}));

export default FormDropDown;