﻿import React from 'react';
import * as mobservableReact from 'mobx-react';
import * as mobservable from 'mobx';
const $ = require('jquery');
import _ from 'lodash';

const Select2Field = mobservableReact.observer(React.createClass({
    displayName: "Select2Field",
    
    propTypes: {
        className: React.PropTypes.string,
        defaultValue: React.PropTypes.string,
        fieldId: React.PropTypes.string.isRequired,
        multiselect: React.PropTypes.bool,
        optional: React.PropTypes.bool,
        properties: React.PropTypes.object.isRequired,
        readOnly: React.PropTypes.bool.isRequired,
        source: React.PropTypes.oneOfType([React.PropTypes.string, React.PropTypes.object]).isRequired,
        storeLocator: React.PropTypes.object.isRequired
    },
    
    getDefaultProps: function () {
        return {
            optional: true,
            defaultValue: "default",
            readOnly: false,
            multiselect: true
        };
    },

    getInitialState: function () {
        this.optionsMap = {};
        return {
            options: this._initFromProperties(this.props),
            readOnly: (this.props.properties.readOnly || this.props.readOnly)
        };
    },
    
    componentDidMount: function () {
        this._initializeSelect2();
        this._registerObservers();
    },
    
    componentWillReceiveProps: function (nextProps) {
        const newState = {};
        if (nextProps.properties.source != this.props.properties.source) {
            this.optionsMap = {};
            newState.options = this._initFromProperties(nextProps);
        }
        this.optionsMap = {};
        newState.options = this._initFromProperties(nextProps);
        newState.readOnly = (nextProps.properties.readOnly || nextProps.readOnly);
        this.setState(newState);
    },
    
    shouldComponentUpdate: function (nextProps, nextState) {
        if ((nextProps.properties != this.props.properties) ||
            (nextProps.properties.source != this.props.properties.source) ||
            (nextState.options != this.state.options)) {
            return true;
        } else {
            this._initializeSelect2State(nextState);
            return false;
        }
    },
    
    componentWillUpdate: function () {
        this._destroyObservers();
        this._destroySelect2();
    },
    
    componentDidUpdate: function () {
        this._initializeSelect2();
        this._registerObservers();
    },
    
    componentWillUnmount: function () {
        this._destroyObservers();
        this._destroySelect2();
    },
    
    optionsMap: {},
    
    _registerObservers: function () {
        this.destroyValueObserver = mobservable.observe(this.props.storeLocator.store, this.props.fieldId, this._onValueChange);
    },
    
    _destroyObservers: function () {
        //this.destroyValueObserver();
    },
    
    //
    _onValueChange: function () {
        this._initializeSelect2State();
    },
    
    _initializeSelect2State: function (state) {
        if (_.isNil(state)) {
            state = this.state;
        }

        if (!this.select2ElementInitialized) return;
        const $sel2 = $(this.select2Element);
        $(this.select2Element).off('change', this._handleChange);
        if (this.props.multiselect === true) {
            const values = (_.isNil(this.props.storeLocator.store[this.props.fieldId]) ? [] : this.props.storeLocator.store[this.props.fieldId]);
            if (this.props.properties.objectAsValue === true) {
                const simpleValues = [];
                const that = this;
                _.forEach(values, function (value) {
                    simpleValues.push(value[that.props.properties.valueField]);
                });
                $sel2.val(simpleValues).trigger('change');
            } else {
                $sel2.val(values).trigger('change');
            }

        } else {
            if (this.props.properties.objectAsValue === true) {
                if (_.isNil(this.props.storeLocator.store[this.props.fieldId])) {
                    $sel2.val(this.props.defaultValue).trigger('change');
                } else {
                    $sel2.val(this.props.storeLocator.store[this.props.fieldId]).trigger('change');
                }
            } else {
                $sel2.val(this.props.storeLocator.store[this.props.fieldId]).trigger('change');
            }
        }
        $(this.select2Element).on('change', this._handleChange);
        if ($sel2.prop("disabled") !== state.readOnly) {
            $sel2.prop("disabled", state.readOnly);
        }
    },
    
    _initializeSelect2: function () {
        if (this.select2ElementInitialized === true) {
            return;
        }
        $(this.select2Element).select2(
            {
                allowClear: (!this.state.readOnly && (!this.props.properties.required || (this.props.multiselect === true))),
                placeholder: (this.state.readOnly ? '' : this.props.properties.placeholder),
                theme: 'bootstrap'
            }
        );
        $(this.select2Element).on('change', this._handleChange);
        this.select2ElementInitialized = true;
        this._initializeSelect2State();
    },
    
    _destroySelect2: function () {

        if (this.select2ElementInitialized !== true) {
            return;
        }
        $(this.select2Element).off('change', this._handleChange);
        $(this.select2Element).select2('destroy');
        this.select2ElementInitialized = false;
    },
    
   _initOptions: function (source) {
        let options = [];

        if (!_.isUndefined(source) && !_.isNull(source)) {
            options = source.map(function (option) {
                return (
                    <option
                        key={option["value"]}
                        value={option["value"]}
                    >
                        {option["text"]}
                    </option>
                )
            });
        }

        if (this.props.optional) {
            const emptyOption = (
                <option
                    key="default"
                    value="default"
                >
                    {'---'}
                </option>
            );
            options.splice(0, 0, emptyOption);
        }
        return options;
    },
    
    _initFromProperties: function (props) {
        let source = props.source;

        if (typeof source === 'string' || source instanceof String) {
            const self = this;
            $.get('/api/form/dropdown?key=' + encodeURIComponent(source), function (data) {
                if (typeof data === 'string' || data instanceof String) {
                    source = JSON.parse(data);
                } else {
                    source = data;
                }

                self.setState({options: self._initOptions(source)});
            }).fail(function () {
                console.log('Error fetching FormDropDown options from "' + source + '"');
            });

            return this._initOptions(undefined);
        }
        else {
            return this._initOptions(source);
        }
    },
    
    _handleChange: function () {
        if (this.props.properties.objectAsValue === true) {
            if (this.props.multiselect === true) {
                const values = [];
                const that = this;
                _.forEach($(this.select2Element).val(), function (value) {
                    if (!_.isNil(that.optionsMap[value])) {
                        values.push(that.optionsMap[value]);
                    }
                });
                this.props.storeLocator.set(this.props.fieldId, values);
            } else {
                const value = $(this.select2Element).val();
                if (_.isNil(this.optionsMap[value])) {
                    this.props.storeLocator.set(this.props.fieldId,  null);
                } else {
                    this.props.storeLocator.set(this.props.fieldId, this.optionsMap[value]);
                }
            }
        } else {
            this.props.storeLocator.set(this.props.fieldId, $(this.select2Element).val());
        }
    },
    
    render: function () {
        return (
            <select
                className={"form-control"}
                disabled={this.state.readOnly}
                multiple={(this.props.multiselect === true ? "multiple" : undefined)}
                ref={r => {this.select2Element = r;}}
                onChange={this._handleChange}
            >
                {this.state.options}
            </select>
        );
    }
}));

export default Select2Field;