﻿import React from 'react';

const CheckButton = React.createClass({
    displayName: "CheckButton",

    propTypes: {
        buttonText: React.PropTypes.string,
        initialState: React.PropTypes.bool,
        onSwitch: React.PropTypes.func
	},
    
    getDefaultProps: function()
    {
        return {
            buttonText: "CHECK",
            initialState: false,
            onSwitch: function(){}
        }
    },
    
    getInitialState: function() {
        return {
            checked: this.props.initialState
        };
    },
    
    _handleClick: function()
    {
        const newState = !this.state.checked;
        this.setState({checked: newState});
        this.props.onSwitch(newState);
    },
    
    render: function()
    {
        return(
            <span
                className={"btn " + (this.state.checked?"btn-info space-left":"btn-default space-left")}
                onClick={this._handleClick}
            >{this.props.buttonText}</span>);
    }
});

export default CheckButton;