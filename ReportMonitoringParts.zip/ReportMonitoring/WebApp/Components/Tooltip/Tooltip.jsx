import React from 'react';
import ReactModal from 'react-modal';
ReactModal.defaultStyles.content.border = 'none';
ReactModal.defaultStyles.content.background = 'none';

const Tooltip = React.createClass({
    displayName: "Tooltip",

    propTypes: {
        children: React.PropTypes.node,
        title: React.PropTypes.string,
        tooltip: React.PropTypes.string
    },

    getInitialState: function () {
        return {modalIsOpen: false};
    },

    _handleOpenModal: function () {
        this.setState({modalIsOpen: true});
    },

    _handleCloseModal: function () {
        this.setState({modalIsOpen: false});
    },

    render: function () {
        return (
            <div className="form-inline">
                {this.props.children}
                <i
                    className="fa fa-question-circle center fa-lg"
                    onClick={this._handleOpenModal}
                />
                <ReactModal
                    contentLabel="Modal"
                    isOpen={this.state.modalIsOpen}
                    onRequestClose={this._handleCloseModal}
                >
                    <div role="dialog">
                        <div className="modal-dialog">
                            <div className="modal-content">
                                <div className="modal-header">
                                    <button aria-label="Close"
                                        className="close"
                                        type="button"
                                        onClick={this._handleCloseModal}
                                    >
                                        <span aria-hidden="true">{"×"}</span></button>
                                    <h4 className="modal-title"><i className="fa fa-question-circle center"/> {this.props.title}</h4>
                                </div>
                                <div className="modal-body">
                                    <p>{this.props.tooltip}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </ReactModal>
            </div>
        );
    }
});
export default Tooltip;