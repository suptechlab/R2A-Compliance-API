﻿//TODO eliminate refs usage
/* eslint-disable react/no-string-refs */

import React from 'react';
import ReactDOM from 'react-dom';
import Pikaday from 'pikaday';
import * as mobservableReact from 'mobx-react';
import moment from 'moment';
import ValidationMixin from '../Mixins/ValidationMixin';
import classNames from '../Helpers/classNames';
import _ from 'lodash';


const PikADay = mobservableReact.observer(React.createClass({
    displayName: "PikADay",
    propTypes: {
        className: React.PropTypes.string,
        fieldId: React.PropTypes.string.isRequired,
        format: React.PropTypes.string,
        placeholder: React.PropTypes.string,
        readOnly: React.PropTypes.bool,
        storeLocator: React.PropTypes.object.isRequired
    },
    mixins: [ValidationMixin],

    getDefaultProps: function () {
        return {
            format: 'DD.MM.YYYY.',
            readOnly: false
        }
    },


    componentDidMount: function () {
        const that = this;
        if (!this.props.readOnly) {
            const picker = new Pikaday({
                field: ReactDOM.findDOMNode(that.refs.pikadayInput),
                firstDay: 1,
                format: that.props.format,
                defaultDate: moment().toDate(),
                onSelect: function () {
                    that._dateSelected(this.getMoment().format('YYYY-MM-DD'));
                }
            });

            if (_.isUndefined(picker))
                console.log('Unable to initialize PikADay component for field ', this.props.fieldId);
        }
    },

    _dateSelected: function (date) {
        if (!this.props.readOnly)
            this.props.storeLocator.store[this.props.fieldId] = date;
    },

    render: function () {
        const dateValue = this.props.storeLocator.store[this.props.fieldId];
        let formattedDate;
        if (!(_.isUndefined(dateValue) || _.isNull(dateValue))) {
            formattedDate = moment(this.props.storeLocator.store[this.props.fieldId]).format(this.props.format);
        }
        const className = classNames(this.props.className, 'form-control', {'error': !this.state.valid});
        return (
            <input
                className={className}
                name="pikadayId"
                placeholder={this.props.placeholder}
                readOnly={this.props.readOnly}
                ref="pikadayInput"
                type="text"
                value={formattedDate}
            />

        );
    }

}));
export default PikADay;