import React from 'react';
import classNames from '../Helpers/classNames';
import FormDropDown from './Form/FormDropDown';
import Input from './Input';
import Select2Field from './Select2';
import RegexInput from './RegexInput';
import PikADay from './PikADay';
import _ from 'lodash';
import Tooltip from './Tooltip/Tooltip';

const InputSwitcher = React.createClass({
    displayName: "InputSwitcher",

    propTypes: {
        className: React.PropTypes.string,
        fieldData: React.PropTypes.object.isRequired,
        fieldId: React.PropTypes.string.isRequired,
        readOnly: React.PropTypes.bool,
        storeLocator: React.PropTypes.object.isRequired
    },

    getDefaultProps: function () {
        return {
            readOnly: false
        }
    },

    render: function () {
        let inputComponent;
        switch (this.props.fieldData.type) {
            case "Combo":
            case "combo":
            case "dropdown_input":
            case "dropdown":
                const dropDownClass = classNames('form-control',this.props.className);
                inputComponent = (
                    <FormDropDown
                        className={dropDownClass}
                        fieldId={this.props.fieldId}
                        properties={this.props.fieldData.properties}
                        readOnly={this.props.readOnly}
                        required={this.props.fieldData.properties.required}
                        source={this.props.fieldData.properties.source}
                        storeLocator={this.props.storeLocator}
                    />
                );
                break;
            case "string":
            case "string_input":
                inputComponent = (
                    <Input
                        className={this.props.className + " form-control"}
                        fieldId={this.props.fieldId}
                        properties={this.props.fieldData.properties}
                        readOnly={this.props.readOnly}
                        required={this.props.fieldData.properties.required}
                        storeLocator={this.props.storeLocator}
                    />)
                ;
                break;
            case "number":
            case "numeric":
            case "numeric_input":
                inputComponent = (
                    <RegexInput
                        className="form-control"
                        fieldId={this.props.fieldId}
                        properties={this.props.fieldData.properties}
                        readOnly={this.props.readOnly}
                        regex='^[0-9]+(\.[0-9]{1,2})?'
                        required={this.props.fieldData.properties.required}
                        storeLocator={this.props.storeLocator}
                    />
                );
                break;
            case "regex":
                inputComponent = (
                    <RegexInput
                        className="form-control"
                        fieldId={this.props.fieldId}
                        properties={this.props.fieldData.properties}
                        readOnly={this.props.readOnly}
                        regex={this.props.fieldData.properties.regexPattern}
                        required={this.props.fieldData.properties.required}
                        storeLocator={this.props.storeLocator}
                    />
                );
                break;
            case "decimal":
            case "decimal_input":
                inputComponent = (
                    <RegexInput
                        className="form-control"
                        fieldId={this.props.fieldId}
                        properties={this.props.fieldData.properties}
                        readOnly={this.props.readOnly}
                        regex='^[0-9]+(\.[0-9]{1,2})?'
                        required={this.props.fieldData.properties.required}
                        storeLocator={this.props.storeLocator}
                    />
                );
                break;
            case "oib":
            case "oib_input":
                inputComponent = (
                    <RegexInput
                        className="form-control"
                        fieldId={this.props.fieldId}
                        properties={this.props.fieldData.properties}
                        readOnly={this.props.readOnly}
                        regex='[0-9]{1,11}'
                        required={this.props.fieldData.properties.required}
                        storeLocator={this.props.storeLocator}
                    />
                );
                break;
            case "dateTime":
                inputComponent = (
                    <PikADay
                        fieldId={this.props.fieldId}
                        properties={this.props.fieldData.properties}
                        readOnly={this.props.readOnly}
                        required={this.props.fieldData.properties.required}
                        storeLocator={this.props.storeLocator}
                    />
                );
                break;
            case "date":
                inputComponent = (
                    <PikADay
                        fieldId={this.props.fieldId}
                        properties={this.props.fieldData.properties}
                        readOnly={this.props.readOnly}
                        required={this.props.fieldData.properties.required}
                        storeLocator={this.props.storeLocator}
                    />
                );
                break;
            case "multiselect":
                inputComponent = (
                    <Select2Field
                        fieldId={this.props.fieldId}
                        properties={this.props.fieldData.properties}
                        readOnly={this.props.readOnly}
                        required={this.props.fieldData.properties.required}
                        source={this.props.fieldData.properties.source}
                        storeLocator={this.props.storeLocator}
                    />
                );
                break;
            default:
                inputComponent = <div  />
        }
        let icon = "";
        if (this.props.fieldData.properties) {
            if (this.props.fieldData.properties.required) {
                icon = <i className="fa fa-asterisk required-icon" />
            }

            const tooltip = this.props.fieldData.properties.tooltip;
            if (!_.isUndefined(tooltip) && !_.isNull(tooltip) && !_.isEmpty(tooltip)) {
                return (
                    <div className="form-inline">
                        <Tooltip title={this.props.fieldData.title}
                            tooltip={tooltip}
                        >{icon}{inputComponent}
                        </Tooltip>
                    </div>
                );
            }
        }
        return (
            <div className="form-inline">{icon}{inputComponent}
            </div>
        );
    }
});
export default InputSwitcher;