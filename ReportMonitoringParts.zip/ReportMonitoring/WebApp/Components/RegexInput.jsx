﻿import React from 'react';
import classNames from '../Helpers/classNames';
import * as mobservableReact from 'mobx-react';
import ValidationMixin from '../Mixins/ValidationMixin';
import _ from 'lodash';

const RegexInput = mobservableReact.observer(React.createClass({

    propTypes: {
        className: React.PropTypes.string,
        errorMessage: React.PropTypes.string,
        fieldId: React.PropTypes.string,
        optional: React.PropTypes.bool,
        placeholder: React.PropTypes.string,
        readOnly: React.PropTypes.bool,
        regex: React.PropTypes.string,
        storeLocator: React.PropTypes.object
    },

    mixins: [ValidationMixin],

    getDefaultProps: function () {
        return {
            optional: true,
            readOnly: false
        }
    },


    getInitialState: function () {
        const value = this.props.storeLocator.store[this.props.fieldId];
        if (_.isUndefined(value) || _.isNull(value)) {
            this.props.storeLocator.set(this.props.fieldId, "");
        }
        return { validated: true, errorMessage: "" };
    },



    _isPasteAction: function (newValue, oldValue) {
        if (_.isUndefined(oldValue) || _.isNull(oldValue)) {
            oldValue = "";
        }

        oldValue = oldValue.toString();
        if (Math.abs(newValue.length - oldValue.length) > 1) {
            return true;
        }
        let cnt = 0;
        let x1, x2 = 0;
        if (oldValue.length > newValue.length) {
            for (x1 = 0; x1 < oldValue.length; x1++) {
                if (newValue.charAt(x1) !== oldValue.charAt(x2)) {
                    if (cnt !== 0) {
                        return true;
                    } else {
                        cnt++;
                        x2 += 2;
                    }
                } else {
                    x2++;
                }
            }
        } else if (oldValue.length < newValue.length) {
            for (x1 = 0; x1 < newValue.length; x1++) {
                if (oldValue.charAt(x1) !== newValue.charAt(x2)) {
                    if (cnt !== 0) {
                        return true;
                    } else {
                        cnt++;
                        x2 += 2;
                    }
                } else {
                    x2++;
                }
            }
        } else {
            for (x1 = 0; x1 < oldValue.length; x1++) {
                if (newValue.charAt(x1) !== oldValue.charAt(x1)) {
                    if (cnt !== 0) {
                        return true;
                    } else {
                        cnt++;
                    }
                }
            }
        }
        return false;
    },

    _handleChange: function (event) {
        let value = event.target.value;

        if (_.isUndefined(value) || _.isNull(value)) {
            value = "";
        }

        let match = null;

        const reg = new RegExp(this.props.regex);

        if ((value === "") || (!_.isNull(match = reg.exec(value)))) {
            if ((!_.isNull(match)) && (value.length !== match[0].length)) {
                if (this._isPasteAction(value, this.props.storeLocator.store[this.props.fieldId])) {
                    value = match[0];
                } else {
                    this.setState({validated: false, errorMessage: this.props.errorMessage});
                    return false;
                }
            }

            this.setState({validated: true, errorMessage: ""});
            this.props.storeLocator.set(this.props.fieldId, value);
            return true;

        } else {
            this.setState({validated: false, errorMessage: this.props.errorMessage});
            return false;
        }
    },

    _handleBlur: function () {

    },

    render: function () {
        let warning = <div/>;
        if (!this.state.validated && !this.props.readOnly) {
            warning = (
                <div
                    className="alert alert-danger"
                    role="alert"
                >
                    <span
                        aria-hidden="true"
                        className="glyphicon glyphicon-exclamation-sign"
                    />
                    <span className="sr-only">{'Error:'}</span>
                    {this.state.errorMessage}
                </div>
            );
        }
        const className = classNames(this.props.className, {'error': !this.state.valid});
 
        return (
            <div>
                {warning}
                <input
                    className={className}
                    disabled={this.props.readOnly}
                    placeholder={this.props.placeholder}
                    type="text"
                    value={this.props.storeLocator.store[this.props.fieldId]}
                    onBlur={this._handleBlur}
                    onChange={this._handleChange}
                />
            </div>
        );
    }
}));

export default RegexInput;