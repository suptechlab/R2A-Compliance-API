/**
 * Created by Alan Fluka on 19.5.2017..
 */
import * as _ from "lodash";

const DEFAULT_STORAGE = "local";
const KEY_PREFIX = "DOQ_BrowserStorage_";


class BrowserStorage {

    storageType;
    data;

    constructor(storageType) {
        if (storageType === "session") {
            this.storageType = "session";
        } else if (storageType === "local") {
            this.storageType = "local";
        }
        else {
            console.log('Cannot recognise storage type "' + storageType + '", trying default storage "' + DEFAULT_STORAGE + '".');
            this.storageType = DEFAULT_STORAGE;
        }
        if (!this._isStorageAvailable() && this.storageType !== DEFAULT_STORAGE) {
            console.log('Cannot find storage "' + storageType + 'Storage", trying default storage "' + DEFAULT_STORAGE + '".');
            this.storageType = DEFAULT_STORAGE;
        }
        if (!this._isStorageAvailable()) {
            console.log('Storage unavailable. Resuming simple observable data store behaviour.');
        } else {
            console.log('Storage set as '+this.storageType);
        }
        this.data = {};
    }

    _getStorage() {
        if (!this._isStorageAvailable) {
            return null;
        }
        if (this.storageType === "session") {
            return sessionStorage;
        }
        if (this.storageType === "local") {
            return localStorage;
        }
        return null;
    }

    _getItemFromStorage(key) {
        if (!this._isStorageAvailable) {
            return null;
        }
        const storage = this._getStorage();
        return storage.getItem(KEY_PREFIX + key);//returns null if key is absent
    }

    _setItemInStorage(key, value) {
        if (this._isStorageAvailable()) {
            const storage = this._getStorage();
            storage.setItem(KEY_PREFIX + key, value);
        }
    }

    _removeItemFromStorage(key) {
        if (this._isStorageAvailable()) {
            const storage = this._getStorage();
            storage.removeItem(KEY_PREFIX + key);
        }
    }

    _isStorageAvailable() {
        return typeof(this.storageType + "Storage") !== "undefined";
    }

    getItem(key) {
        if (!_.isUndefined(this.data[key])) {
            return this.data[key];
        }
        if (this._isStorageAvailable()) {
            const value = this._getItemFromStorage(key);
            this.data[key] = value;
            return value;
        }

        this.data[key] = null;
        return null;
    }

    setItem(key, value) {
        this.data[key] = value;

        if (this._isStorageAvailable()) {
            this._setItemInStorage(key, value);
        }
    }


    setAllItems(items) {
        this.clearStorage();
        _.forEach(items, (item) => this.setItem(item.key,item.value));
    }


    clearStorage() {
        if (this._isStorageAvailable()) {
            _.forOwn(this.data, (value, key) =>  {
                this._removeItemFromStorage(key);
                this.data[key] = null;
            });
        }
    }
}

export default BrowserStorage;