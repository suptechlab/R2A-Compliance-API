﻿import _ from 'lodash';
import * as mobservable from 'mobx';

const DataStore = (function() {

    const data = {};
    
    let currentReportId = 0;

    let formFieldValues = undefined;

    const initOpenTemplateSegment = function(properties) {

        
        const rowSegment = [];
        rowSegment[0] = [];

        const fields = properties.fields;
        const rowObject = {};
        for(let i=0; i< fields.length; i++){
            rowObject[fields[i].xmlNode] = undefined;
        }
        rowSegment[0] = rowObject;
        return rowSegment;
    };
    
    const initTableSegment = function(properties) {
        const inputs = {};
        for(let i=0; i<properties.fields.length; i++)
        {
            const row = properties.fields[i];
            for(let j=0; j<row.length; j++)
            {
                const cell = row[j];
                inputs[cell.xmlNode] = undefined;
            }
        }
        return inputs;
    };
    
    let _initialData = undefined;
    
    const isFormSingleField = function(form)
    {
        return form.fields.length===1 && _.isUndefined(form.fields[0].xmlNode);
    };

    const initFormFieldValues = function(initialData,reportId){

        this.currentReportId = 'report_'+reportId.toString();
        console.log("DataStore  init called "+this.currentReportId);
        if(this.data[this.currentReportId]!==undefined)
        {
            console.log('      - Report already initialized');
            this.formFieldValues = this.data[this.currentReportId];
            return;
        }
        console.log('      - init report');
        _initialData = initialData;
        const forms = initialData.forms;
        const observableFormData = {};
        //header ide prvi
        const headers = initialData.header;
        for(let i = 0; i< headers.length; i++)
        {
            const segment = {};
            for(let j = 0; j <headers[i].fields.length; j++)
            {
                const field = headers[i].fields[j];
                if(field.type === "opentable"){
                    segment[field.xmlNode] = initOpenTemplateSegment(field.properties);
                } else {
                    segment[field.xmlNode] = field.properties.defaultValue;
                }
            }
            observableFormData[headers[i].xmlNode] = segment;
        }
        //nakon toga obrasci i njihova polja (ako ih ima)
        for(let i = 0; i< forms.length; i++)
        {
            const segment = {};
            for(let j = 0; j <forms[i].fields.length; j++){
                const field = forms[i].fields[j];
                let xmlNode = field.xmlNode;
                if(_.isUndefined(xmlNode))
                    xmlNode = "NULL";
                if(field.type === "opentable"){
                    segment[xmlNode] = initOpenTemplateSegment(field.properties);
                } else if(field.type === "table" )  {
                    segment[xmlNode] = initTableSegment(field.properties);
                } else {
                    segment[xmlNode] = field.properties.defaultValue;
                }
            }
            if(isFormSingleField(forms[i]))
                observableFormData[forms[i].xmlNode] = segment["NULL"];
            else
                observableFormData[forms[i].xmlNode] = segment;
        }
        this.data[this.currentReportId] = mobservable.observable(observableFormData);
        this.formFieldValues = this.data[this.currentReportId];
        console.log('    - init done');
    };

    const addToArrayField = function(formId, fieldId, insertionIndex, element)
    {
        if(_.isUndefined(fieldId))
            DataStore.formFieldValues[formId].splice(insertionIndex,0,element);
        else
            DataStore.formFieldValues[formId][fieldId].splice(insertionIndex,0,element);
    };

    const addTableRow = function(formId,fieldId,insertionIndex,fields)
    {
        const rowObject = {};
        for(let i=0; i< fields.length; i++){
            rowObject[fields[i].xmlNode] = undefined;
        }
        addToArrayField(formId,fieldId,insertionIndex,rowObject);
    };

    const removeTableRow = function(formId,fieldId,atIndex)
    {
        if(_.isUndefined(fieldId))
            DataStore.formFieldValues[formId].splice(atIndex,1);
        else
            DataStore.formFieldValues[formId][fieldId].splice(atIndex,1);
    };
    
    const loadDataFromJson = function(json)
    {
        const forms = _initialData.forms;
        const rootNode = json[_initialData.xmlNode];

        for(let i = 0; i< forms.length; i++)
        {
            const formId = forms[i].xmlNode;
            if(_.isUndefined(rootNode[formId]) || _.isNull(rootNode[formId]))
                continue;
            
            if(isFormSingleField(forms[i]))
            {
                const formDef = forms[i].fields[0];
                if(formDef.type === "opentable"){
                        let dataArray = rootNode[formId];
                        if(!$.isArray(dataArray))
                            dataArray = [dataArray];
                        this.formFieldValues[formId].splice(0,this.formFieldValues[formId].length);
                        const cells = formDef.properties.fields;
                        for(let k=0; k<dataArray.length; k++)
                        {
                            const rowObject = {};
                            const newRow = dataArray[k];
                            for(let l=0; l< cells.length; l++){
                                rowObject[cells[l].xmlNode] = newRow[cells[l].xmlNode];
                            }
                            addToArrayField(formId,undefined,k,rowObject);
                        }
                    } else if(formDef.type === "table") {
                        for(let k=0; k<formDef.properties.fields.length; k++)
                        {
                            const row = formDef.properties.fields[k];
                            for(let l=0; l<row.length; l++){
                                const cell = row[l];
                                this.formFieldValues[formId][cell.xmlNode] = rootNode[formId][cell.xmlNode];
                            }
                        }
                    } else {
                        this.formFieldValues[formId]=rootNode[formId];
                    }
                continue;
            }
                
            for(let j = 0; j <forms[i].fields.length; j++){
                const field = forms[i].fields[j];
                const fieldId = field.xmlNode;
                if(!_.isUndefined(rootNode[formId][fieldId]))
                {
                    if(field.type === "opentable"){
                        let dataArray = rootNode[formId][fieldId];
                        if(!$.isArray(dataArray))
                            dataArray = [dataArray];
                        this.formFieldValues[formId][fieldId].splice(0,this.formFieldValues[formId][fieldId].length);
                        const fields = field.properties.fields;
                        for(let k=0; k<dataArray.length; k++)
                        {
                            const rowObject = {};
                            const newRow = dataArray[k];
                            for(let l=0; l< fields.length; l++){
                                rowObject[fields[l].xmlNode] = newRow[fields[l].xmlNode];
                            }
                            addToArrayField(formId,fieldId,k,rowObject);
                        }
                    } else if(field.type === "table") {
                        for(let k=0; k<field.properties.fields; k++)
                        {
                            const row = field.properties.fields[k];
                            for(let l=0; l<row.length; l++){
                                const cell = row[l];
                                this.formFieldValues[formId][fieldId][cell.xmlNode] = rootNode[formId][fieldId][cell.xmlNode];
                            }
                        }
                    } else {
                        this.formFieldValues[formId][fieldId]=rootNode[formId][fieldId];
                    }
                }
            }
        }

        const headers = _initialData.header;
        for(let i = 0; i< headers.length; i++)
        {
            const headerId = headers[i].xmlNode;
            if(_.isUndefined(rootNode[headerId]) || _.isNull(rootNode[headerId]))
                continue;
            for(let j = 0; j <headers[i].fields.length; j++){
                const field = headers[i].fields[j];
                const fieldId = field.xmlNode;
                
                this.formFieldValues[headerId][fieldId]=rootNode[headerId][fieldId];
                
            }

        }
    };

    return {
            initFormFieldValues: initFormFieldValues,
            
             formFieldValues:formFieldValues,
             addTableRow: addTableRow,
             removeTableRow: removeTableRow,
             loadDataFromJson: loadDataFromJson,
             data: data,
             currentReportId: currentReportId}
}());
export default DataStore;


//TODO: makni changeFieldValue, ubaci logiranje u lokator direktno (ili kroz mobservable always)
//ili poopći changeFieldValue da prima samo observable objekt, ključ i novu vrijednost
export const OpenTableRowLocator = function(formId,fieldId,rowNum)  {
    
    const store = (_.isUndefined(fieldId) ? DataStore.formFieldValues[formId][rowNum] : DataStore.formFieldValues[formId][fieldId][rowNum]);
    
    function set(cellId,value)
    {
        store[cellId]=value;
        if(_.isUndefined(fieldId))
            console.log('Set '+formId+'['+rowNum+ '].'+cellId+' to value '+value);
        else
            console.log('Set '+formId+'.'+fieldId+'['+rowNum+ '].'+cellId+' to value '+value);
    }
    
    return {
        store: store,
        set: set
    }
};

export const FormLocator = function(formId)  {
    
    const store = DataStore.formFieldValues[formId];
    
    function set(fieldId,value)
    {
        DataStore.formFieldValues[formId][fieldId] = value;
        console.log('Set '+formId+'.'+fieldId+' to value '+value);
    }
    
    return {
        store: store,
        set: set
    }
};

export const ScrollTableLocator = function(formId,fieldId)
{
    const store = (_.isUndefined(fieldId) ? DataStore.formFieldValues[formId] : DataStore.formFieldValues[formId][fieldId]);
    
    function set(cellId,value)
    {
        store[cellId] = value;
        if(_.isUndefined(fieldId))
            console.log('Set '+formId+'.'+cellId+' to value '+value);
        else
            console.log('Set '+formId+'.'+fieldId+'.'+cellId+' to value '+value);
    }
    
    return {
        store: store,
        set: set
    }
};

export const OpenTableLocator = ScrollTableLocator;
