/**
 * Created by Alan Fluka on 15.3.2017..
 */

import {observable, action, computed} from "mobx";
const $ = require("jquery");
import * as _ from "lodash";
//TODO vrati dekoratore kad prorade s Webpack 2

class ReportListTableStore {
    state;
    data;
    currentDivision;
    reportId;

    constructor(pageConfigData) {
        this.data = observable([]);
        this.state = observable({isLoading: false, isError:false, page: 1, isPageSet: false});
        this.currentDivision = _.isNil(pageConfigData.divisionId) ? -1 : pageConfigData.divisionId;
        this.reportId = pageConfigData.reportId;
        const division = $("#division");
        const store = this;
        division.change((e) => {
            const value = e.target.value;
            store.reloadData(_.isNil(value) || _.isEmpty(value) ? -1 : parseInt(value, 10));
        });
        this.loadData();
    }

    @computed
    get reportsSelect() {
        const reports = _.uniqBy(this.data.slice(), 'ReportId');
        const result = {};
        _.forEach(reports, (report) => { result[report.ReportId.toString()] = report.ReportName; });
        return result;
    }

    reloadData(newDivision) {
        if(this.currentDivision!=newDivision) {
            action(() => {
                this.currentDivision = newDivision;
                this.loadData();
                this.state.page = 1;
            })();

        }
    }

    setPage(table) {
        if(this.state.isPageSet === false && this.reportId != null && this.reportId != undefined && this.reportId > 0) {
            action(() => {
                const page = table.getPageByRowKey(this.reportId);

                if(page > 0) {
                    this.state.page = page;
                } else {
                    this.state.page = 1;
                }
                this.state.isPageSet = true;


            })();

        }
    }

    loadData() {
        action(() => {
            this.state.isLoading = true;
            this.state.isError = false;
            let url = "/api/submittedReports";
            if(this.currentDivision > -1 ) {
                url += "?divisionId="+this.currentDivision;
            }
            $.get(url)
                .done(action((data) => {
                    if(_.isNil(data) || _.isEmpty(data)) {
                        this.data.clear();
                    } else {
                        this.data.replace(data);
                    }
                    this.state.isLoading = false;
                }))
                .fail(action((error) => {
                    console.log(error);
                    this.data.clear();
                    this.state.isLoading = false;
                    this.state.isError = true;
                }));
        })();
    }
}


export default ReportListTableStore;

