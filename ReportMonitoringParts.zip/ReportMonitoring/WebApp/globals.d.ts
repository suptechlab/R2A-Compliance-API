/**
 * Created by Alan Fluka on 15.3.2017..
 */
interface IDetailsPageConfig {
    details: {
        formDefinitionData: any;
        formValueData: any;
        initialStatus: number;
        initialBP2: boolean;
        id: number;
    };
    reportFiles: string;
    divisionId: number;
}


interface IIndexPageConfig {
    reportId: number;
    divisionId: number;
}

declare const detailsPageConfigData: IDetailsPageConfig;

declare const indexPageConfigData: IIndexPageConfig;