﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Odbc;
using System.Data.SqlClient;
using System.IO;
using System.Linq.Expressions;
using System.Text;
using ReportMonitoring.Models;
using Pinecone.ReportDataConverter.Extensions.Misc;
using Pinecone.SqlCommandExtensions;

namespace ReportMonitoring.Repositories
{
    public class ReportRepository : IReportRepository
    {
        private readonly string _connectionString;



        public ReportRepository(string connectionString)
        {
            _connectionString = connectionString;
        }


        public List<dynamic> GetDivisions()
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();

                var command =
                    new SqlCommand("SELECT * FROM dbo.Division", conn);

                command.Prepare();
                var divisions = new List<dynamic>();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        divisions.Add(new { value = (int)reader["Id"], label = reader["Title"] });
                    }
                }

                return divisions;
            }
        }

        public List<ReportListViewModel> GetSubmittedReports(List<int> divisionIds = null)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                using (var command = conn.CreateCommand())
                {
                    var sql = new StringBuilder(
                        "SELECT sr.Id, sr.XmlLocation, sr.ReportId, sr.ReportVersionId, r.Name AS ReportName, sr.SubmissionTime, sr.UserId AS UserId, 'API Endpoint' AS UserName, sr.SubmittedReportStatus AS Status, sr.ReportingPeriod, b.Title AS SubjectName, sr.IsViewable " +
                        "FROM dbo.SubmittedReport AS sr " +
                        "INNER JOIN dbo.Report AS r ON r.Id = sr.ReportId " +
                        "INNER JOIN bsp.Bank AS b ON b.Id = sr.UndertakingId"
                    );

                    if (divisionIds != null && divisionIds.Count > 0)
                    {
                        sql.Append(
                            " WHERE sr.SubmittedReportStatus>=0 AND sr.ReportId IN (SELECT r2d.ReportId FROM dbo.ReportToDivision AS r2d WHERE r2d.DivisionId  IN(");
                        for (var i = 0; i < divisionIds.Count; i++)
                        {
                            if (divisionIds[i] > 0)
                            {
                                var paramName = $"@divisionId_{i}";
                                sql.AppendFormat("{0}, ", paramName);
                                command.Parameters.AddParameter(paramName, divisionIds[i], SqlDbType.Int);
                            }
                        }

                        sql.Remove(sql.Length - 2, 2);
                        sql.Append("))");
                    }

                    command.CommandText = sql.ToString();

                    command.Prepare();
                    var reports = new List<ReportListViewModel>();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var report = new ReportListViewModel()
                            {
                                Id = reader.GetValue<int>("Id"),
                                FilePath = reader.GetObject<string>("XmlLocation"),
                                ReportId = reader.GetValue<int>("ReportId"),
                                ReportVersionId = reader.GetNullable<int>("ReportVersionId"),
                                UserId = reader.GetValue<int>("UserId"),
                                ReportName = reader.GetObject<string>("ReportName"),
                                UserName = reader.GetObject<string>("UserName"),
                                SubmissionTime = reader.GetValue<DateTime>("SubmissionTime"),
                                Status = reader.GetValue<SubmittedReportStatus>("Status"),
                                SubmittedReportId = reader.GetValue<int>("Id"),
                                ReportingPeriod = reader.GetString("ReportingPeriod"),
                                SubjectName = reader.GetString("SubjectName") ?? "Unknown",
                                IsViewable = reader.GetValue<bool>("IsViewable")
                            };
                            reports.Add(report);
                        }
                    }

                    return reports;
                }
            }
        }

        public int? GetReportVersionId(int subId)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                using (var command = conn.CreateCommand())
                {
                    command.CommandText = @"SELECT ReportVersionId FROM dbo.SubmittedReport WHERE Id=@subId";
                    command.Parameters.AddParameter("@subId", subId, SqlDbType.Int);
                    command.Prepare();

                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            reader.Read();
                            return reader.GetValue<int>("ReportVersionId");
                        }
                        return null;
                    }
                }
            }
        }

        public SubmittedReportDetailsViewModel GetSubmittedReport(int id)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                var sql =
                    @"SELECT sr.ReportId, sr.ReportVersionId, sr.UserId, 'API Endpoint' AS UserName, sr.SubmissionTime, sr.ReportingPeriod,
                                sr.XmlLocation, sr.XmlProcessReportLocation, sr.PdfProcessReportLocation, sr.ExcelReportFilePath, sr.SubmittedReportStatus,  
                                r.Name AS ReportName, b.Title AS SubjectName, sr.IsViewable
                            FROM dbo.SubmittedReport AS sr
                            INNER JOIN dbo.ReportVersion AS rv ON rv.Id = sr.ReportVersionId
                            INNER JOIN dbo.Report AS r ON r.Id = rv.ReportId
                            INNER JOIN bsp.Bank AS b ON b.Id = sr.UndertakingId
                            WHERE sr.Id=@id";

                conn.Open();
                var command = new SqlCommand(sql, conn);
                command.Parameters.AddParameter("@id", id, SqlDbType.Int);
                command.Prepare();

                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        var report = new SubmittedReportDetailsViewModel()
                        {
                            SubmittedReport = new ReportListViewModel()
                            {
                                Id = id,
                                ReportId = reader.GetValue<int>("ReportId"),
                                ReportVersionId = reader.GetValue<int>("ReportVersionId"),
                                UserId = reader.GetValue<int>("UserId"),
                                ReportName = reader.GetObject<string>("ReportName"),
                                SubjectName = reader.GetString("SubjectName"),
                                UserName = reader.GetObject<string>("UserName"),
                                SubmissionTime = reader.GetValue<DateTime>("SubmissionTime"),
                                Status = reader.GetValue<SubmittedReportStatus>("SubmittedReportStatus"),
                                ReportingPeriod = reader.GetString("ReportingPeriod"),
                                IsViewable = reader.GetValue<bool>("IsViewable"),
                            },
                            SubmittedReportFilePath = reader.GetObject<string>("XmlLocation"),
                            XmlProcessReportLocation = reader.GetObject<string>("XmlProcessReportLocation"),
                            PdfProcessReportLocation = reader.GetObject<string>("PdfProcessReportLocation"),
                            ExcelProcessReportLocation = reader.GetObject<string>("ExcelReportFilePath"),
                        };
                        report.ReportDefinitionString = null;
                        report.AdditionalReportFiles = new List<AdditionalReportFile>();
                        report.AdditionalReportFiles.Add(new AdditionalReportFile
                        {
                            Id = id,
                            FileName = SubmittedXmlFileName,
                            FileType = FileType.XmlFile,
                            FilePath = report.SubmittedReportFilePath
                        });
                        if (!string.IsNullOrWhiteSpace(report.PdfProcessReportLocation))
                        {
                            report.AdditionalReportFiles.Add(new AdditionalReportFile
                            {
                                Id = id,
                                FileName = PdfProcessReportFileName,
                                FileType = FileType.PdfProcessReportFile,
                                FilePath = report.PdfProcessReportLocation
                            });
                        }
                        if (!string.IsNullOrWhiteSpace(report.XmlProcessReportLocation))
                        {
                            report.AdditionalReportFiles.Add(new AdditionalReportFile
                            {
                                Id = id,
                                FileName = XmlProcessReportFileName,
                                FileType = FileType.XmlProcessReportFile,
                                FilePath = report.XmlProcessReportLocation
                            });
                        }
                        if (!string.IsNullOrWhiteSpace(report.XmlProcessReportLocation) && report.SubmittedReport.IsViewable)
                        {
                            report.AdditionalReportFiles.Add(new AdditionalReportFile
                            {
                                Id = id,
                                FileName = ExcelProcessReportFileName,
                                FileType = FileType.ExcelFile,
                                FilePath = report.ExcelProcessReportLocation
                            });
                        }
                        return report;
                    }
                }

                return null;
            }
        }

        public const string SubmittedXmlFileName = "Submitted XML Report";
        public const string PdfProcessReportFileName = "Processing Report (PDF)";
        public const string XmlProcessReportFileName = "Processing Report (XML)";
        public const string ExcelProcessReportFileName = "Generate Excel report";

        public AdditionalReportFile GetReportFile(int id, FileType fileType)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                var additionalReportFile = new AdditionalReportFile { Id = id, FileType = fileType };
                var sqlField = "";
                switch (fileType)
                {
                    case FileType.XmlFile:
                        sqlField = "XmlLocation";
                        additionalReportFile.FileName = SubmittedXmlFileName;
                        break;
                    case FileType.PdfProcessReportFile:
                        sqlField = "PdfProcessReportLocation";
                        additionalReportFile.FileName = PdfProcessReportFileName;
                        break;
                    case FileType.XmlProcessReportFile:
                        sqlField = "XmlProcessReportLocation";
                        additionalReportFile.FileName = XmlProcessReportFileName;
                        break;
                    case FileType.ExcelFile:
                        sqlField = "ExcelReportFilePath";
                        additionalReportFile.FileName = ExcelProcessReportFileName;
                        break;
                    default:
                        return null;
                }

                var sql =
                    $"SELECT {sqlField} AS filePath FROM dbo.SubmittedReport WHERE Id = @id";

                conn.Open();
                var command = new SqlCommand(sql, conn);
                command.Parameters.AddParameter("@id", id, SqlDbType.Int);
                command.Prepare();

                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        additionalReportFile.FilePath = reader.GetObject<string>("filePath");
                        return string.IsNullOrEmpty(additionalReportFile.FilePath) ? null : additionalReportFile;
                    }

                    return null;
                }
            }
        }

        public string GetReportConfigFile(int reportVersionId)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                var sql =
                    $"SELECT JsonDefinition FROM dbo.ReportVersion WHERE Id = @id";

                conn.Open();
                var command = new SqlCommand(sql, conn);
                command.Parameters.AddParameter("@id", reportVersionId, SqlDbType.Int);
                command.Prepare();

                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        var filePath = reader.GetObject<string>("JsonDefinition");
                        return string.IsNullOrEmpty(filePath) ? null : filePath;
                    }

                    return null;
                }
            }
        }

        public HashSet<int> GetReportsOfDivision(int divisionId)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                using (var command = conn.CreateCommand())
                {
                    command.CommandText = @"SELECT ReportId FROM dbo.ReportToDivision WHERE DivisionId=@divisionId";
                    command.Parameters.AddParameter("@divisionId", divisionId, SqlDbType.Int);
                    command.Prepare();

                    using (var reader = command.ExecuteReader())
                    {
                        var set = new HashSet<int>();
                        while (reader.Read())
                            set.Add(reader.GetValue<int>("ReportId"));
                        return set;
                    }
                }
            }
        }

        /*
        public int CreateReportAnalyticsInstance(int subRepId)
        {
            return _siReportHelper.CreateReportAnalyticsInstance(subRepId);
        }

        public void DeleteReportAnalyticsInstance(int subRepId)
        {
            _siReportHelper.DeleteSiInstance(subRepId);
        }
        */


    }
}