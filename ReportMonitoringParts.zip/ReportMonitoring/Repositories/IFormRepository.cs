﻿using System.Collections.Generic;
using ReportMonitoring.Models;

namespace ReportMonitoring.Repositories
{
    public interface IFormRepository
    {
        ReportDefinitionModel GetReportDefinitionByVersionId(int reportVersionId);
        string GetReportDefinitionById(int definitionId);
        bool CheckIfVersionExists(int reportVersionId);
        bool CheckIfReportExists(int reportId);
        int InsertNewReportDefinition(ReportDefinitionModel reportDefinition);
        int UpdateReportDefinition(ReportDefinitionModel reportDefinition);

        int UpdateReportDefinitionByReportId(ReportDefinitionModel reportDefinition);
        string GetReportSchemaPath(int reportId);
        int? GetAssignedReportDefinition(int verzijaSubjektaNadzoraId, int tipObrascaId);
        List<dynamic> GetDropDownListItems(string dbView);
        List<dynamic> GetReportDigitalItems();
    }
}