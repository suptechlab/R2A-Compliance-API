﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using ReportMonitoring.Models;
//using ReportMonitoring.Utilities;
using Pinecone.SqlCommandExtensions;

namespace ReportMonitoring.Repositories
{
    public class FormRepository : IFormRepository
    {
        private readonly string _connectionString;

        public FormRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public ReportDefinitionModel GetReportDefinitionByVersionId(int reportVersionId)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();

                var command = new SqlCommand("SELECT Id, JsonDefinition, XsdDefinition, XsdNamespace FROM dbo.ReportVersion WHERE Id = @id", conn);
                command.Parameters.AddParameter("@id", reportVersionId, SqlDbType.Int);
                command.Prepare();
                using (var reader = command.ExecuteReader())
                {
                    if (!reader.Read())
                        return null;

                    return new ReportDefinitionModel
                    {
                        Id = reader.GetValue<int>("Id"),
                        JsonDefinition = reader.GetObject<string>("JsonDefinition"),
                        XsdLocation = reader.GetObject<string>("XsdDefinition"),
                        XsdNamespace = reader.GetString("XsdNamespace")
                    };
                }
            }
        }

        public bool CheckIfVersionExists(int reportVersionId)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = @"SELECT CAST(COUNT(1) AS BIT) FROM DefinicijeIzvjesca WHERE IdVerzije=@reportVersionId";
                    command.Parameters.AddParameter("@reportVersionId", reportVersionId, SqlDbType.Int);
                    command.Prepare();

                    return (bool)command.ExecuteScalar();
                }
            }
        }

        public bool CheckIfReportExists(int reportId)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = @"SELECT CAST(COUNT(1) AS BIT) FROM DefinicijeIzvjesca WHERE IdIzvjesca=@reportId";
                    command.Parameters.AddParameter("@reportId", reportId, SqlDbType.Int);
                    command.Prepare();

                    return (bool)command.ExecuteScalar();
                }
            }
        }

        public int InsertNewReportDefinition(ReportDefinitionModel reportDefinition)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {

                    command.CommandText =
                        "INSERT INTO DefinicijeIzvjesca (IdVerzije,JsonDefinicija,XsdLokacija, IdIzvjesca, Naziv, Digitalni) VALUES (@idVerzije,@jsonDefinicija,@xsdLokacija, @reportId, @reportName, @isDigital)";
                    command.Parameters.AddParameter("@idVerzije", reportDefinition.ReportVersionId, SqlDbType.Int);
                    command.Parameters.AddParameter("@jsonDefinicija", reportDefinition.JsonDefinition,
                        SqlDbType.NVarChar);
                    command.Parameters.AddParameter("@xsdLokacija", reportDefinition.XsdLocation, SqlDbType.NVarChar);
                    command.Parameters.AddParameter("@reportId", reportDefinition.ReportId, SqlDbType.Int);
                    command.Parameters.AddParameter("@reportName", reportDefinition.ReportName, SqlDbType.NVarChar);
                    command.Parameters.AddParameter("@isDigital", reportDefinition.IsDigital, SqlDbType.Bit);
                    command.Prepare();

                    return command.ExecuteNonQuery();
                }
            }
        }

        public int UpdateReportDefinition(ReportDefinitionModel reportDefinition)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {

                    command.CommandText =
                        "UPDATE DefinicijeIzvjesca SET JsonDefinicija=@jsonDefinicija, XsdLokacija=@xsdLokacija, IdIzvjesca=@reportId, Naziv=@reportName, Digitalni=@isDigital WHERE IdVerzije=@reportVersionId";
                    command.Parameters.AddParameter("@reportVersionId", reportDefinition.ReportVersionId, SqlDbType.Int);
                    command.Parameters.AddParameter("@jsonDefinicija", reportDefinition.JsonDefinition,
                        SqlDbType.NVarChar);
                    command.Parameters.AddParameter("@xsdLokacija", reportDefinition.XsdLocation, SqlDbType.NVarChar);
                    command.Parameters.AddParameter("@reportId", reportDefinition.ReportId, SqlDbType.Int);
                    command.Parameters.AddParameter("@reportName", reportDefinition.ReportName, SqlDbType.NVarChar);
                    command.Parameters.AddParameter("@isDigital", reportDefinition.IsDigital, SqlDbType.Bit);
                    command.Prepare();

                    return command.ExecuteNonQuery();
                }
            }
        }

        public int UpdateReportDefinitionByReportId(ReportDefinitionModel reportDefinition)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {

                    command.CommandText =
                        "UPDATE DefinicijeIzvjesca SET IdVerzije=@reportVersionId, JsonDefinicija=@jsonDefinicija, XsdLokacija=@xsdLokacija, Naziv=@reportName, Digitalni=@isDigital WHERE IdIzvjesca=@reportId";
                    command.Parameters.AddParameter("@reportVersionId", reportDefinition.ReportVersionId, SqlDbType.Int);
                    command.Parameters.AddParameter("@jsonDefinicija", reportDefinition.JsonDefinition,
                        SqlDbType.NVarChar);
                    command.Parameters.AddParameter("@xsdLokacija", reportDefinition.XsdLocation, SqlDbType.NVarChar);
                    command.Parameters.AddParameter("@reportId", reportDefinition.ReportId, SqlDbType.Int);
                    command.Parameters.AddParameter("@reportName", reportDefinition.ReportName, SqlDbType.NVarChar);
                    command.Parameters.AddParameter("@isDigital", reportDefinition.IsDigital, SqlDbType.Bit);
                    command.Prepare();

                    return command.ExecuteNonQuery();
                }
            }
        }

        public string GetReportDefinitionById(int definitionId)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();

                var command = new SqlCommand("SELECT JsonDefinicija FROM DefinicijeIzvjesca WHERE Id = @Id", conn);
                command.Parameters.AddParameter("@Id", definitionId, SqlDbType.Int);
                command.Prepare();
                using (var reader = command.ExecuteReader())
                {
                    if (!reader.Read())
                        return String.Empty;
                    return reader.GetObject<string>("JsonDefinicija");
                }
            }
        }

        public string GetReportSchemaPath(int reportDefinitionId)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();

                var command =
                    new SqlCommand("SELECT XsdLokacija FROM DefinicijeIzvjesca WHERE Id = @id", conn);
                command.Parameters.AddParameter("@id", reportDefinitionId, SqlDbType.Int);
                command.Prepare();
                using (var reader = command.ExecuteReader())
                {
                    if (!reader.Read())
                        return String.Empty;
                    return reader.GetObject<string>("XsdLokacija");
                }

            }
        }

        public int? GetAssignedReportDefinition(int verzijaSubjektaNadzoraId, int tipObrascaId)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();

                var command =
                    new SqlCommand("SELECT DefinicijeIzvjescaId FROM VrstaTipDefinicija WHERE VrstaSubjektaNadzoraId = @vsnId AND " +
                                   "TipObrascaId = @tipObrascaId", conn);

                command.Parameters.AddParameter("@vsnId", verzijaSubjektaNadzoraId, SqlDbType.Int);
                command.Parameters.AddParameter("@tipObrascaId", tipObrascaId, SqlDbType.Int);
                command.Prepare();
                using (var reader = command.ExecuteReader())
                {
                    if (!reader.Read())
                        return null;
                    return reader["DefinicijeIzvjescaId"] as int?;
                }
            }
        }
        /*
        public List<dynamic> GetTipObrasca()
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();

                var command =
                    new SqlCommand("SELECT tox.Id,tox.Naziv FROM dbo.TipObrasca AS tox WHERE exists (SELECT * FROM dbo.VrstaTipDefinicija AS vtd WHERE vtd.TipObrascaId = tox.Id)", conn);

                command.Prepare();
                var tipObrasca = new List<dynamic>();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        tipObrasca.Add(new { value = (int)reader["Id"], label = (string)reader["Naziv"] });
                    }

                }
                return tipObrasca;
            }
        }

        public List<dynamic> GetVrsteSubjektaNadzora()
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();

                var command =
                    new SqlCommand("SELECT Id,Naziv FROM dbo.VrstaSubjektaNadzora AS vsn WHERE exists (SELECT * FROM dbo.VrstaTipDefinicija AS vtd WHERE vtd.VrstaSubjektaNadzoraId = vsn.Id)", conn);

                command.Prepare();
                var vsnList = new List<dynamic>();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        vsnList.Add(new {value= (int)reader["Id"] , label = (string)reader["Naziv"]});
                    }
                   
                }
                return vsnList;
            }
        }*/

        public List<dynamic> GetDropDownListItems(string dbView)
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                //TODO testirati dbView za sqlijection
                var command =
                    new SqlCommand(String.Format("SELECT * FROM {0}",dbView), conn);

                command.Prepare();
                var selectList = new List<dynamic>();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        selectList.Add(new { value = reader[0].ToString(), text = (string)reader[1]});
                    }

                }
                return selectList;
            }
        }

        public List<dynamic> GetReportDigitalItems()
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();

                var command =
                    new SqlCommand("SELECT IdVerzije, Naziv FROM dbo.DefinicijeIzvjesca WHERE Digitalni = 1 order by RedBr", conn);

                command.Prepare();
                var resultList = new List<dynamic>();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        resultList.Add(new { VersionId = (int)reader["IdVerzije"], Name = (string)reader["Naziv"] });
                    }
                }
                return resultList;
            }
        }
    }
}