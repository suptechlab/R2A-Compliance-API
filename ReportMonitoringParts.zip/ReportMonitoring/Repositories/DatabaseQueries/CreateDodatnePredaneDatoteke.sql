ALTER TABLE PredaniIzvjestaji ADD ZaprimljeniIzvId int null

if not exists (select * from sys.tables t join sys.schemas s on (t.schema_id = s.schema_id) where t.name = 'DodatneDatoteke') 
	create table DodatneDatoteke (
		Id int not null PRIMARY KEY IDENTITY (1,1),
		ZaprimljenaDatotekaId int not null,
		NazivDatoteke nvarchar(255) not null,
		FilePath nvarchar(255) not null,
		ZaprimljeniIzvId int not null
	)
GO
