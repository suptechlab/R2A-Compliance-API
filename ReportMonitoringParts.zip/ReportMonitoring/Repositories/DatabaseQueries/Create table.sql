/****** Object:  Table [dbo].[DefinicijeIzvjesca]    Script Date: 18.1.2016. 14:07:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DefinicijeIzvjesca](
	[IdVerzije] [int] NOT NULL,
	[JsonDefinicija] [nvarchar](max) NOT NULL,
	[XsdLokacija] [nvarchar](300) NULL,
	[Id] [int] IDENTITY(1,1) NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[TipObrasca]    Script Date: 18.1.2016. 14:07:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TipObrasca](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Naziv] [nvarchar](500) NOT NULL
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[VrstaSubjektaNadzora]    Script Date: 18.1.2016. 14:07:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[VrstaSubjektaNadzora](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Naziv] [nvarchar](500) NOT NULL
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[VrstaTipDefinicija]    Script Date: 18.1.2016. 14:07:26 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[VrstaTipDefinicija](
	[VrstaSubjektaNadzoraId] [int] NOT NULL,
	[TipObrascaId] [int] NOT NULL,
	[DefinicijeIzvjescaId] [int] NOT NULL
) ON [PRIMARY]

GO

/****** Object:  Index [PK_DefinicijeIzvjesca]    Script Date: 18.1.2016. 14:07:26 ******/
ALTER TABLE [dbo].[DefinicijeIzvjesca] ADD  CONSTRAINT [PK_DefinicijeIzvjesca] PRIMARY KEY NONCLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [PK_TipObrasca]    Script Date: 18.1.2016. 14:07:26 ******/
ALTER TABLE [dbo].[TipObrasca] ADD  CONSTRAINT [PK_TipObrasca] PRIMARY KEY NONCLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [PK_VrstaSubjektaNadzora]    Script Date: 18.1.2016. 14:07:26 ******/
ALTER TABLE [dbo].[VrstaSubjektaNadzora] ADD  CONSTRAINT [PK_VrstaSubjektaNadzora] PRIMARY KEY NONCLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
/****** Object:  Index [UK_VrstaTipDefinicija]    Script Date: 18.1.2016. 14:07:26 ******/
ALTER TABLE [dbo].[VrstaTipDefinicija] ADD  CONSTRAINT [UK_VrstaTipDefinicija] UNIQUE NONCLUSTERED 
(
	[VrstaSubjektaNadzoraId] ASC,
	[TipObrascaId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE [dbo].[VrstaTipDefinicija]  WITH CHECK ADD  CONSTRAINT [FK_DefinicijeIzvjesca_Id] FOREIGN KEY([DefinicijeIzvjescaId])
REFERENCES [dbo].[DefinicijeIzvjesca] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[VrstaTipDefinicija] CHECK CONSTRAINT [FK_DefinicijeIzvjesca_Id]
GO
ALTER TABLE [dbo].[VrstaTipDefinicija]  WITH CHECK ADD  CONSTRAINT [FK_TipObrasca_Id] FOREIGN KEY([TipObrascaId])
REFERENCES [dbo].[TipObrasca] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[VrstaTipDefinicija] CHECK CONSTRAINT [FK_TipObrasca_Id]
GO
ALTER TABLE [dbo].[VrstaTipDefinicija]  WITH CHECK ADD  CONSTRAINT [FK_VrstaSubjektaNadzora_Id] FOREIGN KEY([VrstaSubjektaNadzoraId])
REFERENCES [dbo].[VrstaSubjektaNadzora] ([Id])
ON UPDATE CASCADE
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[VrstaTipDefinicija] CHECK CONSTRAINT [FK_VrstaSubjektaNadzora_Id]
GO