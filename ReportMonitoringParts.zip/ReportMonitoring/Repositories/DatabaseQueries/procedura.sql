﻿/****** Object:  StoredProcedure [dbo].[zaprimiIzvjestaj]    Script Date: 1.6.2016. 11:30:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


 CREATE PROCEDURE [dbo].[zaprimiIzvjestaj]
	@FilePath nvarchar(255) ,
	@ReportId int ,
	@ReportVersionId int ,
	@ImeIzvjestaja nvarchar(255) ,
	@VrijemePredaje datetime2(0) ,
	@KorisnikId int ,
	@KorisnikNaziv nvarchar(255) ,
	@ZaprimljeniIzvId int
AS	
BEGIN

INSERT INTO [dbo].[PredaniIzvjestaji]
           ([FilePath]
           ,[ReportId]
           ,[ReportVersionId]
           ,[VrstaSubjektaNadzoraId]
           ,[ImeIzvjestaja]
           ,[TipObrascaId]
           ,[VrijemePredaje]
           ,[KorisnikId]
           ,[KorisnikNaziv]
           ,[Status]
           ,[UnesiUBP2]
		   ,[ZaprimljeniIzvId])
     VALUES
           (

		   @FilePath  ,
	@ReportId  ,
	@ReportVersionId  ,
	1,
	@ImeIzvjestaja ,
	1,
	@VrijemePredaje ,
	@KorisnikId ,
	@KorisnikNaziv ,
	1,
	0,
	@ZaprimljeniIzvId
)

END
GO


CREATE PROCEDURE [dbo].[zaprimiDatoteku]
	@FilePath nvarchar(255) ,
	@ZaprimljeniIzvId int,
	@ZaprimljenaDatotekaId int,
	@NazivDatoteke nvarchar(255)			
AS	
BEGIN

INSERT INTO [dbo].DodatneDatoteke
           (
				[ZaprimljenaDatotekaId]
			   ,[NazivDatoteke]
			   ,[FilePath]			
			   ,[ZaprimljeniIzvId]
		   )
     VALUES
           (
		   	@ZaprimljenaDatotekaId,
			@NazivDatoteke,
			@FilePath,
			@ZaprimljeniIzvId
	)
END
GO