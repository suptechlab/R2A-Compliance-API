﻿using System.Collections.Generic;
using ReportMonitoring.Models;

namespace ReportMonitoring.Repositories
{
    public interface IReportRepository
    {
        List<dynamic> GetDivisions();

        List<ReportListViewModel> GetSubmittedReports(List<int> divisionIds );
        SubmittedReportDetailsViewModel GetSubmittedReport(int id);

        HashSet<int> GetReportsOfDivision(int divisionId);

        //Dictionary<int,string> GetSubjectNamesOfReports(IEnumerable<int> submittedReportIds);

        //int CreateReportAnalyticsInstance(int s1aSubmittedReportId);

        //void DeleteReportAnalyticsInstance(int s1aSubmittedReportId);

        int? GetReportVersionId(int subId);

        AdditionalReportFile GetReportFile(int value, FileType fileType);
        string GetReportConfigFile(int reportVersionId);
    }
}
