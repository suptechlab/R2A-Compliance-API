﻿using System;
using System.Web.Mvc;
using System.Web.Security;
using ReportMonitoring.Models;
//using ReportMonitoring.Utilities;

namespace ReportMonitoring.Controllers
{
    public class AuthenticationController : Controller
    {

        /// <summary>
        /// NE KORISTI SE VIŠE
        /// </summary>
        /// <returns></returns>
        // GET: Authentication
        [Authorize]
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Login()
        {
            var model = new LogOnModel();
            return this.View(model);
        }

        [HttpPost]
        public ActionResult Login(LogOnModel model, string ReturnUrl = null)
        {
            try
            {
                

                if (FormsAuthentication.
                    Authenticate(model.UserName, model.Password))
                {
                    //store login info
                    FormsAuthentication.SetAuthCookie(model.UserName, model.RememberMe);
                    //store group info
                    //ActiveDomainGroups.SetUserGroups(HttpContext);
                    //redirect to protected url
                    return RedirectOrDefault(ReturnUrl);
                }

                this.ModelState.AddModelError("Password", "The user name or password provided is incorrect.");

                return this.View(model);
            }
            catch (Exception)
            {
                //TODO handle exceptions
                throw;
            }

        }

        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            Session.Clear();

            return this.RedirectToAction("Index", "Administration");
        }

        /// <summary>
        /// Redirects to the redirect url, or to home page if no valid url is provided.
        /// </summary>
        /// <param name="returnUrl"></param>
        /// <returns></returns>
        private ActionResult RedirectOrDefault(string returnUrl = null)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }

            return RedirectToAction("Index", "Administration");
        }
    }
}