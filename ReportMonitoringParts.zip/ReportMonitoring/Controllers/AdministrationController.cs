﻿using System.Linq;
using System.Web.Mvc;
using ReportMonitoring.Services;
//using ReportMonitoring.Utilities;
using log4net;
using System.Configuration;

namespace ReportMonitoring.Controllers
{
    [Authorize]
    public class AdministrationController : Controller
    {

        private static readonly ILog Logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private readonly ISubmittedReportService _submittedReportService;
        private readonly IReportService _reportService;

        public AdministrationController(ISubmittedReportService submittedReportService, IReportService reportService)
        {
            _submittedReportService = submittedReportService;
            _reportService = reportService;
        }

        public AdministrationController()
        {
            _reportService = new ReportService();

            _submittedReportService = new SubmittedReportService();
        }
        
        
        // GET: Administration
        public ActionResult Index(int? reportId = null, int? divisionId = null)
        {
            ViewBag.ReportId = reportId ?? -1;
            ViewBag.DivisionId = divisionId ?? -1;

            var divisions = _reportService.GetDivisions();
            //var userGroups = ActiveDomainGroups.GetUserGroups(ActiveUser.Username);

            //if (userGroups.Contains(ActiveDomainGroups.Groups.Admin))
                return View(new SelectList(divisions, "value", "label", divisionId));

            //return View(new SelectList(divisions.Where(d => userGroups.Contains((ActiveDomainGroups.Groups)d.value)),"value","label", divisionId));
        }

        public ActionResult Details(int id, int? divisionId = null)
        {
            ViewBag.DivisionId = divisionId ?? -1;

            var report = _submittedReportService.GetSubmittedReport(id);


            if (report == null)
            {
                Logger.ErrorFormat("AdministrationController.Details: Report is null for id {0} and divisionId {1}", id, divisionId);
                return View("Error");
            }

            ViewData["optionsResolverUrl"] = (ConfigurationManager.AppSettings["optionsResolverUrl"]).ToString();

            return View(report);
        }
    }
}