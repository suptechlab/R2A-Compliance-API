﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Web;
using System.Web.Http;
using ReportMonitoring.Models;
using ReportMonitoring.Services;
//using ReportMonitoring.Utilities;
using log4net;

namespace ReportMonitoring.Controllers
{
    [System.Web.Http.Authorize]
    [System.Web.Http.RoutePrefix("api/submittedReports")]
    public class SubmittedReportController : ApiController
    {
        private readonly ISubmittedReportService _service;


        private static readonly ILog Logger= LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);


        public SubmittedReportController()
        {
            _service = new SubmittedReportService();
          
        }

        public SubmittedReportController(ISubmittedReportService service)
        {
            _service = service;
        }
   

        [System.Web.Http.HttpGet]
        [System.Web.Http.Route("")]
        public List<ReportListViewModel> GetSubmittedReports([FromUri]int? divisionId = null)
        {
            try
            {
                return _service.GetSubmittedReports(divisionId,null/*ActiveDomainGroups.GetUserGroups(ActiveUser.Username)*/);
            }
            catch (Exception e)
            {
                Logger.Error("Error in GetSubmittedReports", e);
                throw new HttpResponseException(HttpStatusCode.BadRequest);
            }
        }
    }
}
