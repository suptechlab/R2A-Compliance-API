﻿using System.IO;
using System.Web.Http;
using System.Web.Mvc;
using ReportMonitoring.Models;
using ReportMonitoring.Services;

namespace ReportMonitoring.Controllers
{
    [System.Web.Http.RoutePrefix("export")]
    public class ExportController : Controller
    {
        private readonly ISubmittedReportService _service = new SubmittedReportService();
        private readonly IReportService _reportService = new ReportService();

        [System.Web.Http.Route("exportFile")]
        public ActionResult ExportFile([FromUri] int sId, [FromUri] int fType)
        {
            var file = _service.GetReportFile(sId, fType);

            if (file == null || string.IsNullOrWhiteSpace(file.FilePath) || !System.IO.File.Exists(file.FilePath))
            {
                if ((FileType)fType == FileType.ExcelFile)
                {
                    var excel = _reportService.GetExcel(sId);

                    if (excel != null)
                    {
                        return File(excel.Item2, System.Net.Mime.MediaTypeNames.Application.Octet, excel.Item1);
                    }
                }

                return HttpNotFound();
            }

            try
            {
                using (var stream = System.IO.File.Open(file.FilePath, FileMode.Open, FileAccess.Read))
                {
                }
            }
            catch (IOException)
            {
                return HttpNotFound();
            }

            return File(file.FilePath, System.Net.Mime.MediaTypeNames.Application.Octet, Path.GetFileName(file.FilePath));
        }
    }
}