﻿
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.SessionState;
using ProjectOne.Web.Helpers;

namespace ReportMonitoring.Utilities
{
    public static class ActiveDomainGroups
    {

        public enum Groups
        {
            CRT_VSI=3, SRPA = 1, SN = 2, Admin = 0
        }

        //Group constants for use with the AuthorizeADAttribute (just to make them strongly typed)
        public static Dictionary<string, Groups> GroupToDivision = new Dictionary<string, Groups>()
        {
            {"SSZ-IT", Groups.Admin},
            {"SRPA",Groups.Admin},
            {"SN",Groups.Admin},
            {"CRT_VSI",Groups.Admin}
        };

        public static HashSet<Groups> GetUserGroups(string userName)
        {
            HashSet<Groups> groups = new HashSet<Groups>();

            string[] groupSet = GroupToDivision.Keys.ToArray();
            bool[] results = LDAPHelper.UserIsMemberOfGroups(userName, groupSet);
            for (int i = 0; i < results.Length; i++)
                if (results[i])
                    groups.Add(GroupToDivision[groupSet[i]]);

            return groups;
        }
    }

}