﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ReportMonitoring.Utilities
{
    public class ActiveUser
    {
        public static string Username
        {
            get
            {
                var user = HttpContext.Current.User.Identity.Name;

                if (user.Contains("\\"))
                {
                    user = user.Substring(user.IndexOf(@"\") + 1);
                }

                return user;
            }
        }

        /// <summary>
        /// Domain\Username
        /// </summary>
        public static string FullUsername
        {
            get
            {
                return HttpContext.Current.User.Identity.Name;
            }
        }

        public static bool IsAuthenticated
        {
            get
            {
                return HttpContext.Current.User.Identity.IsAuthenticated;
            }
        }
    }
}