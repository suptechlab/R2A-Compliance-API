﻿using System;
using System.Configuration;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Web;
using System.Web.Configuration;

namespace ProjectOne.Web.Helpers
{
    public static class LDAPHelper
    {
        
        public static string GetLDAPHost()
        {
            Uri ldapUri = ParseLDAPConnectionString();

            return ldapUri.Host;
        }
        public static string GetLDAPContainer()
        {
            Uri ldapUri = ParseLDAPConnectionString();
            return HttpUtility.UrlDecode(ldapUri.PathAndQuery.TrimStart('/'));
             
        }
        public static Uri ParseLDAPConnectionString()
        {
            string connString = ConfigurationManager.ConnectionStrings["ADConnectionString"].ConnectionString;

            return new Uri(connString);
        }
        public static PrincipalContext BuildPrincipalContext()
        {
            var mem = ConfigurationManager.GetSection("system.web/membership") as MembershipSection;
            string username = mem.Providers[0].Parameters["connectionUsername"];
            string password = mem.Providers[0].Parameters["connectionPassword"];
            string domain = GetLDAPHost();
            string container = GetLDAPContainer();
            if (String.IsNullOrEmpty(username))
            {
                if(String.IsNullOrEmpty(container))
                    return new PrincipalContext(ContextType.Domain,domain);
                return new PrincipalContext(ContextType.Domain, domain, container);
            }
            if(String.IsNullOrEmpty(container))
                return new PrincipalContext(ContextType.Domain,domain,username,password);
            return new PrincipalContext(ContextType.Domain, domain, container,
                ContextOptions.Negotiate,username,password);
        }


        public static bool[] UserIsMemberOfGroups(string username, string[] groups)
        {
            
            /* Return true immediately if the authorization is not locked down to any particular AD group */
            if (groups == null || groups.Length == 0)
            {
                return null;
            }
            bool[] results = new bool[groups.Length];
            // Verify that the user is in the given AD group (if any)
            using (var context = BuildPrincipalContext())
            {
                using (var userPrincipal = UserPrincipal.FindByIdentity(context, IdentityType.SamAccountName, username))
                {
                    for(int i=0; i<groups.Length; i++)
                    {
                        results[i] = CheckGroup(groups[i], userPrincipal, context);

                    }
                }
            }
            return results;
        }

        private static bool CheckGroup(string group, UserPrincipal user, PrincipalContext context)
        {
            try
            {
                using (var groupPrincipal = GroupPrincipal.FindByIdentity(context, IdentityType.Name, group))
                {
                    if (groupPrincipal == null)
                        throw new ArgumentException(
                            String.Format("AuthorizeAD attribute contains invalid group: {0}", group));
                    if (!user.IsMemberOf(groupPrincipal))
                        return false;
                }
            }
            catch (PrincipalOperationException)
            {
                return false;
            }
            return true;
        }

        public static bool UserIsMemberOfGroup(string username, string group)
        {
            using (var context = BuildPrincipalContext())
            {
                using (var userPrincipal = UserPrincipal.FindByIdentity(context, IdentityType.SamAccountName, username))
                {
                    return CheckGroup(group, userPrincipal, context);
                }
            }
        }
    }

}