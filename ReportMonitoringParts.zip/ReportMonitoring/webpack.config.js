const path = require('path');
const fs = require('fs');
const _ = require('lodash');
const merge = require('webpack-merge');
const webpack = require('webpack');

const pkg = require('./package.json');
const parts = require('./webpack_parts/parts');


const PATHS = {
    app: path.join(__dirname, 'WebApp'),
    build: path.join(__dirname, 'Scripts/build')
};

function loadEntries(folderPrefix = "", devServerEnabled = false) {
    let entries = {};

    const files = fs.readdirSync(PATHS.app);
    files.reduce((accEntry, fileName) => {
        "use strict";
        const position = fileName.indexOf('.index');
        if (position !== -1) {
            const entryName = folderPrefix + fileName.substring(0, fileName.indexOf('.'));
            if (devServerEnabled === true) {
                let entryArray = [
                    'react-hot-loader/patch', 'webpack-dev-server/client?http://localhost:8080'
                ];
                entryArray.push(path.join(PATHS.app, fileName));
                accEntry[entryName] = entryArray;
            } else {
                let entryArray = ["babel-polyfill"];
                entryArray.push(path.join(PATHS.app, fileName));
                accEntry[entryName] = entryArray;
            }
            //      console.log("Added entry: {" + entryName + ":" + path.join(PATHS.app, fileName) + "}");
        }
        return accEntry;
    }, entries);
    return entries;
}

const common = {


        output: {
            path: PATHS.build,
            filename: '[name].js',
            publicPath: '/Scripts/build/'
        },
        module: {
            rules: [
                {
                    enforce: 'pre',
                    test: /\.(js|jsx)$/,
                    loader: 'eslint-loader?{fix:true}',
                    include: PATHS.app
                },
                {
                    enforce: 'pre',
                    test: /\.(ts|tsx)$/,
                    loader: 'tslint-loader',
                    include: PATHS.app,
                    options: {
                        tslint: {
                            // tslint errors are displayed by default as warnings
                            // set emitErrors to true to display them as errors
                            emitErrors: true,

                            // tslint does not interrupt the compilation by default
                            // if you want any file with tslint errors to fail
                            // set failOnHint to true
                            failOnHint: true
                        }
                    }
                },
                {
                    enforce: 'pre',
                    test: /\.(js|jsx)$/,
                    loader: "source-map-loader"
                },
                {
                    enforce: 'pre',
                    test: /\.(ts|tsx)$/,
                    use: "source-map-loader"
                }
            ]
        },

        //hack za "Can't resolve 'fs'
        node: {
            fs: "empty"
        },
        externals: {
            jquery: "jQuery"
        },
        resolve: {
            // Allow require('./blah') to require blah.jsx
            extensions: ['.js', '.jsx', '.ts', '.tsx']
        }
    }
    ;

function isVendor(module, count) {
    const context = module.context;
    // You can perform other similar checks here too.
    // Now we check just node_modules.
    return context && context.indexOf('node_modules') >= 0;
}


function production() {
    return merge([
        common,
        {entry: loadEntries()},
        parts.generateSourceMaps({type: 'source-map'}),
        parts.lintJavaScript({include: PATHS.app}),
        parts.loadJavaScript({include: PATHS.app}),
        parts.loadTypeScript({include: PATHS.app}),
        parts.extractBundles({
            bundles: [
                {
                    name: 'vendor',
                    //izbaci typscript definicije iz popisa entry-a
                    entries: Object.keys(pkg.dependencies).filter(function (key) {
                        return key.indexOf("@types") === -1 && key !== "font-awesome"
                    })
                }
            ],
            options: {
                minChunks: isVendor
            }
        }),
        parts.extractBundles({
            bundles: [
                {
                    name: 'manifest'
                }
            ],
            options: {
                minChunks: Infinity
            }
        }),
        parts.clean(PATHS.build),
        parts.setFreeVariable(
            'process.env.NODE_ENV',
            'production'
        ),
        parts.minify(),
        parts.gzipScripts(),
        {
            plugins: [
                new webpack.LoaderOptionsPlugin({
                    debug: true
                })
            ]
        }
    ]);
}


function development({devserverEnabled}) {
    return merge([
        common,
        {
            output: {
                devtoolModuleFilenameTemplate: 'webpack:///[absolute-resource-path]',
                publicPath: devserverEnabled ? 'http://localhost:3000/resources/' : '/Scripts/build/'
            },
            plugins: [
                new webpack.NamedModulesPlugin()
            ]
        },
        (devserverEnabled ?
                {
                    entry: loadEntries("", true)
                }
                :
                {
                    entry: loadEntries()
                }
        ),
        parts.generateSourceMaps({type: 'eval-source-map'}),
        parts.clean(PATHS.build),
        (devserverEnabled ? parts.devServer({
                    // Customize host/port here if needed
                    host: process.env.HOST,
                    port: 3000
                })
                : null
        )
        ,
        parts.lintJavaScript({
            include: PATHS.app,
            options: {
                // Emit warnings over errors to avoid crashing
                // HMR on error.
                emitWarning: true
            }
        }),
        parts.lintTypeScript({
            include: PATHS.app,
            options: {
                tslint: {
                    // tslint errors are displayed by default as warnings
                    // set emitErrors to true to display them as errors
                    emitErrors: true,

                    // tslint does not interrupt the compilation by default
                    // if you want any file with tslint errors to fail
                    // set failOnHint to true
                    failOnHint: true
                }
            }
        }),
        parts.loadJavaScript({include: PATHS.app}),
        parts.loadTypeScript({include: PATHS.app}),
        parts.extractBundles({
            bundles: [
                {
                    name: 'vendor',
                    //izbaci typscript definicije iz popisa entry-a
                    entries: Object.keys(pkg.dependencies).filter(function (key) {
                        return key.indexOf("@types") === -1 && key !== "font-awesome"
                    })
                }
            ],
            options: {
                minChunks: isVendor
            }
        }),
        parts.extractBundles({
            bundles: [
                {
                    name: 'manifest'
                }
            ],
            options: {
                minChunks: Infinity
            }
        }),
        parts.shimmModules({
            $: 'jquery',
            jQuery: 'jquery'
        }),
        parts.setFreeVariable(
            'process.env.NODE_ENV',
            'development'
        )
    ]);
}

module.exports = function (env) {
    if (env === "production") {
        return production();
    } else if (env === "devserver") {
        console.log("Running " + env + " build.");
        return development({devserverEnabled: true});
    }
    console.log("Running " + env + " build.");
    return development({devserverEnabled: false});


};

//
// // ---------------------
// var config;
//
// // Detect how npm is run and branch based on that
// switch (process.env.npm_lifecycle_event) {
//     case 'build':
//         config = merge(common,
//             {
//                 devtool: 'source-map',
//                 output: {
//                     path: PATHS.build,
//                     filename: '[name].js'
//                     // filename: '[name].[chunkhash].js',
//                     // // This is used for require.ensure. The setup
//                     // // will work without but this is useful to set.
//                     // chunkFilename: '[chunkhash].js'
//                 }
//             },
//             parts.clean(PATHS.build),
//
//             parts.setFreeVariable(
//                 'process.env.NODE_ENV',
//                 'production'
//             ),
//             parts.extractBundle({
//                 name: 'vendor',
//                 entries: Object.keys(pkg.dependencies).filter(function (key) {
//                     return key.indexOf("@types") === -1
//                 })
//             }),
//             parts.minify()
//         );
//         break;
//     case 'devbuild':
//         config = merge(common,
//             {
//                 devtool: 'eval-source-map',
//                 output: {
//                     path: PATHS.build,
//                     filename: '[name].js'
//                 }
//             },
//             parts.clean(PATHS.build),
//
//             parts.setFreeVariable(
//                 'process.env.NODE_ENV',
//                 'development'
//             ),
//             parts.extractBundle({
//                 name: 'vendor',
//                 entries: Object.keys(pkg.dependencies).filter(function (key) {
//                     return key.indexOf("@types") === -1
//                 })
//             })
//         );
//         break;
//     default:
//         config = merge(
//             common,
//             {
//                 devtool: 'eval-source-map'
//             },
//
//             parts.setFreeVariable(
//                 'process.env.NODE_ENV',
//                 'development'
//             ),
//
//             parts.devServer({
//                 host: process.env.HOST,
//                 port: process.env.PORT
//             })
//         );
// }
//
// module.exports = config;
