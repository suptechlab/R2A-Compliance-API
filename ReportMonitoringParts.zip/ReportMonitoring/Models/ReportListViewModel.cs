﻿using System;

namespace ReportMonitoring.Models
{
    public class ReportListViewModel
    {
        public int Id { get; set; }
        public int ReportId { get; set; }
        public int? ReportVersionId { get; set; }
        public int SubmittedReportId { get; set; }
        public int UserId { get; set; }
        public string ReportName { get; set; }
        public string UserName { get; set; }
        public DateTime SubmissionTime { get; set; }
        public SubmittedReportStatus Status { get; set; }
        public string SubjectName { get; set; }
        public string FilePath { get; set; }
        public string ReportingPeriod { get; internal set; }
        public bool IsViewable { get; set; }
    }

    public enum SubmittedReportStatus
    {
        Rejected = 0,
        Accepted = 1,
        Resubmitted = 2
    }
}