﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ReportMonitoring.Models
{
    public class ReportDefinitionModel
    {
        public int Id { get; set; }
        public int ReportVersionId { get; set; }
        public string JsonDefinition { get; set; }
        public string XsdLocation { get; set; }
        public bool IsDigital { get; set; }
        public int ReportId { get; set; }
        public string ReportName { get; set; }
        public string XsdNamespace { get; set; }
    }
}