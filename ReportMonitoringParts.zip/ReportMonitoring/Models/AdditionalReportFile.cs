﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;

namespace ReportMonitoring.Models
{
    public class AdditionalReportFile
    {
        public int Id { get; set; }
        public FileType FileType { get; set; }
        public string FileName { get; set; }
        [ScriptIgnore]
        public string FilePath { get; set; }
    }

    public enum FileType
    {
        XmlFile = 0,
        PdfProcessReportFile = 1,
        XmlProcessReportFile = 2,
        ExcelFile=3,
    }
}