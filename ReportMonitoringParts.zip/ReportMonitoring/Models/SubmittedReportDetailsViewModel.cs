﻿using System.Collections.Generic;

namespace ReportMonitoring.Models
{
    public class SubmittedReportDetailsViewModel
    {
        public int Id { get; set; }
        public ReportListViewModel SubmittedReport { get; set; }
        public string SubmittedReportFilePath { get; set; }
        public string ReportDefinitionString { get; set; }
        public string ReportValuesString { get; set; }
        public string StatusDescription
        {
            get
            {
                switch (SubmittedReport.Status)
                {
                    case SubmittedReportStatus.Accepted:
                        return "Accepted";
                    case SubmittedReportStatus.Rejected:
                        return "Rejected";
                    case SubmittedReportStatus.Resubmitted:
                        return "Re-submitted";
                    default:
                        return "";
                }
            }
        }

        public string XmlProcessReportLocation { get; set; }
        public string PdfProcessReportLocation { get; set; }
        public string ExcelProcessReportLocation { get; set; }
        public List<AdditionalReportFile> AdditionalReportFiles { get; set; }
    }
}