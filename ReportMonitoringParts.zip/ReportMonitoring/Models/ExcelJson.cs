﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ReportMonitoring.Models
{
    public class ExcelJson
    {
        public string Json { get; set; }
    }
}