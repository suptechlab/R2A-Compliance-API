﻿using System.Web.Optimization;


namespace ReportMonitoring
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                "~/Scripts/jquery-{version}.js"));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                "~/Scripts/modernizr-*"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                "~/Scripts/bootstrap.js",
                "~/Scripts/respond.js"));

            bundles.Add(new StyleBundle("~/Content/bootstrap-table").Include(
                "~/Content/bootstrap-table.css"));

            bundles.Add(new StyleBundle("~/Content/react-bootstrap-table").Include(
    "~/Content/react-bootstrap-table-all.min.css"));


            bundles.Add(new ScriptBundle("~/bundles/utils").Include(
                "~/Scripts/moment.min.js",
                "~/Scripts/placeholders.min.js",
                "~/Scripts/pikaday.js",
                "~/Scripts/classNames.js",
                "~/Scripts/select2.full.js"
                ));

        /*    bundles.Add(new BabelBundle("~/bundles/jsx")
                .IncludeDirectory("~/Scripts/React/Stores", "*.jsx", true)
                .IncludeDirectory("~/Scripts/React/Mixins", "*.jsx", true)
                .IncludeDirectory("~/Scripts/React/Components", "*.jsx", true)
                .IncludeDirectory("~/Scripts/React/Container", "*.jsx", true));*/

            bundles.Add(new StyleBundle("~/Content/css").Include(
                //                 "~/Content/bootstrap.css",
                "~/Content/simplex.css",
                "~/Content/site.css",
                "~/Content/ScrollTable.css",
                "~/Content/pikaday.css",
                "~/Content/select2.css",
                "~/Content/select2custom.css",
                "~/Content/font-awesome-4.5.0/css/font-awesome.css",
                "~/Content/loader.css"

                )
                );

            bundles.Add(new StyleBundle("~/Content/login")
                .Include("~/Content/login.css")
                );

            bundles.Add(new Bundle("~/bundles/vendor").Include(
    "~/Scripts/build/vendor.js"
    ));
            bundles.Add(new Bundle("~/bundles/manifest").Include(
                "~/Scripts/build/manifest.js"
                ));
            bundles.Add(new Bundle("~/bundles/details").Include(
                "~/Scripts/build/detailsPage.js"
                ));
            bundles.Add(new Bundle("~/bundles/index").Include(
    "~/Scripts/build/indexPage.js"
    ));
        }
    }
}