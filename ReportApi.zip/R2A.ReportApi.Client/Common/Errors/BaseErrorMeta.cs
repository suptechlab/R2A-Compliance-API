namespace R2A.ReportApi.Client.Common.Errors
{
    public class BaseErrorMeta
    {
        public string Message { get; set; }
    }
}