ALTER TABLE dbo.ReportStatus ADD ExcelReportFilePath NVARCHAR(256) NULL;
ALTER TABLE dbo.SubmittedReport ADD ExcelReportFilePath NVARCHAR(256) NULL;
