﻿namespace Tester.Model
{
    public enum SubmittedReportStatus
    {
        Accepted = 1,
        Rejected = 0,
        Resubmitted = 2
    }
}