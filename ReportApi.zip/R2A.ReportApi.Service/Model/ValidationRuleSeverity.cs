﻿namespace Tester.Model
{
    public enum ValidationRuleSeverity
    {
        Error = 1,
        Warning = 2
    }
}