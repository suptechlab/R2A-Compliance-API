﻿using MediatR;

namespace R2A.ReportApi.Service.Infrastructure
{
    public class ServiceStartNotification : INotification
    {
    }
}
