﻿namespace R2A.ReportApi.Models
{
    public class ReportSubmissionDto
    {
        public ReportSubmissionInfo ReportInfo { get; set; }

        public string ReportFile { get; set; }

    }
}
