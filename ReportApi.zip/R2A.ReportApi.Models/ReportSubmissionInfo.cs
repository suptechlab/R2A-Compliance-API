﻿namespace R2A.ReportApi.Models
{
    public class ReportSubmissionInfo
    {
        public string ReportCode { get; set; }
        public string UndertakingId { get; set; }
        public string PeriodInfo { get; set; }
    }
}
