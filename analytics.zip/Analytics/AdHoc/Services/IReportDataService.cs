﻿using System.Collections.Generic;
using Analytics.AdHocReports.DTOs;
using Analytics.AdHocReports.Models;
using Analytics.Utilities.AdHocQuery.Entity;

namespace Analytics.AdHocReports.Services
{
    public interface IReportDataService
    {
        List<DropdownItemDTO<int>> GetWarehousesList();
        List<DropdownItemDTO<int>> GetSubjectsList();

        List<Undertaker> GetUndertakerList();
        List<UndertakerGroup> GetUndertakerGroupList();
        List<UndertakersGrouped> GetUndertakersGroupedAll();
        List<UndertakersGrouped> GetUndertakersGroupedOnlyPosrednici();
        List<UndertakersGrouped> GetUndertakersGroupedWithoutPosrednici();
        ReportGroup GetReports(ReportType type, char? periodCode = null);
        List<Indicator> GetIndicators();
        /// <summary>
        /// 
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns>DataEngine service URL and Field specification</returns>
        AdHocWijmoResult InitializeDataEngine(AdHocQueryParam parameters);
    }
}
