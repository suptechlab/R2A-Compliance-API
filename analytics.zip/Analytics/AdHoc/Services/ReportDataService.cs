﻿using System.Collections.Generic;
using System.Linq;
using Analytics.AdHocReports.Models;
using Analytics.Utilities;
using Analytics.Utilities.AdHocQuery.Entity;
using Analytics.AdHocReports.DTOs;
using Analytics.AdHoc.Repositories;
using System;

namespace Analytics.AdHocReports.Services
{
    public class ReportDataService : IReportDataService
    {
        private readonly IUndertakerRepository _undertakerRepository;
        private readonly IReportRepository _reportRepository;
        private readonly IReportDataRepository _reportDataRepository;
        private readonly IDataEngineManager _dataEngineManager;
        private readonly IWarehouseRepository _warehouseRepository;
        private readonly ISubjectRepository _subjectRepository;

        public ReportDataService(IUndertakerRepository undertakerRepository,
            IReportRepository reportRepository,
            IReportDataRepository reportDataRepository,
            IDataEngineManager dataEngineManager,
            IWarehouseRepository warehouseRepository,
            ISubjectRepository subjectRepository)
        {
            _undertakerRepository = undertakerRepository;
            _reportRepository = reportRepository;
            _reportDataRepository = reportDataRepository;
            _dataEngineManager = dataEngineManager;
            _warehouseRepository = warehouseRepository;
            _subjectRepository = subjectRepository;
        }

        public List<Undertaker> GetUndertakerList()
        {
            return _undertakerRepository.GetUndertakers();
        }


        public List<UndertakersGrouped> GetUndertakersGroupedAll()
        {
            List<UndertakersGrouped> list = new List<UndertakersGrouped>();

            var groups = _undertakerRepository.GetUdertakerGroups();

            foreach (var group in groups)
            {
                list.Add(new UndertakersGrouped()
                {
                    Id = group.Id,
                    Name = group.Name,
                    Undertakers = _undertakerRepository.GetUndertakersByGroupId(group.Id)
                });
            }

            return list;
        }

        public List<UndertakersGrouped> GetUndertakersGroupedOnlyPosrednici()
        {
            List<UndertakersGrouped> list = new List<UndertakersGrouped>();

            var groups = _undertakerRepository.GetUdertakerGroups().Where(item => item.Id == 5).ToList();

            foreach (var group in groups)
            {
                list.Add(new UndertakersGrouped()
                {
                    Id = group.Id,
                    Name = group.Name,
                    Undertakers = _undertakerRepository.GetUndertakersByGroupId(group.Id)
                });
            }

            return list;
        }

        public List<UndertakersGrouped> GetUndertakersGroupedWithoutPosrednici()
        {
            List<UndertakersGrouped> list = new List<UndertakersGrouped>();

            var groups = _undertakerRepository.GetUdertakerGroups().Where(item => item.Id != 5).ToList();

            foreach (var group in groups)
            {
                list.Add(new UndertakersGrouped()
                {
                    Id = group.Id,
                    Name = group.Name,
                    Undertakers = _undertakerRepository.GetUndertakersByGroupId(group.Id)
                });
            }

            return list;
        }

        public List<UndertakerGroup> GetUndertakerGroupList()
        {
            return _undertakerRepository.GetUdertakerGroups();
        }

        public ReportGroup GetReports(ReportType type, char? periodCode = null)
        {
            switch (type)
            {
                case ReportType.SI: return _reportRepository.GetSIReports(periodCode);
                case ReportType.SII: return _reportRepository.GetSIIReports(periodCode);
                default: return null;
            }
        }

        public List<Indicator> GetIndicators()
        {
            return _reportRepository.GetIndicators();
        }

        public AdHocWijmoResult InitializeDataEngine(AdHocQueryParam parameters)
        {
            using (var adHocResult = _reportDataRepository.GetData(parameters))
            {
                string name = Guid.NewGuid().ToString("n").Substring(0, 8);
                _dataEngineManager.AddDataEngine(name, adHocResult.DataTable);

                return new AdHocWijmoResult
                {
                    DataUrl = _dataEngineManager.GetOlapUrl(name),
                    Fields = adHocResult.Fields.OrderBy(f => f.IsMeasure).ThenBy(f => f.FieldName).ToList()
                };
            }
        }

        public List<DropdownItemDTO<int>> GetWarehousesList()
        {
            return _warehouseRepository.GetWarehousesList();
        }

        public List<DropdownItemDTO<int>> GetSubjectsList()
        {
            return _subjectRepository.GetSubjectsList();
        }
    }
}