﻿using System.Collections.Generic;
using Analytics.AdHocReports.DTOs;
using Analytics.AdHocReports.Models;
using Analytics.AdHocReports.Services;
using Analytics.Utilities.AdHocQuery.Entity;
using Microsoft.AspNetCore.Mvc;

namespace Analytics.AdHocReports.Controllers
{
    [Route("api")]
    public class ReportDataController : Controller
    {
        private readonly IReportDataService _service;

        public ReportDataController(IReportDataService service)
        {
            _service = service;
        }

        [HttpGet]
        [Route("subjects")]
        public List<DropdownItemDTO<int>> GetSubjectsList()
        {
            return _service.GetSubjectsList();
        }

        [HttpGet]
        [Route("warehouses")]
        public List<DropdownItemDTO<int>> GetWarehousesList()
        {
            return _service.GetWarehousesList();
        }

        [HttpGet]
        [Route("reports/si")]
        public ReportGroup GetSiReports([FromQuery] char? periodCode = null)
        {
            return _service.GetReports(ReportType.SI, periodCode);
        }

        [HttpGet]
        [Route("reports/sii")]
        public ReportGroup GetSiiReports([FromQuery] char? periodCode = null)
        {
            return _service.GetReports(ReportType.SII, periodCode);
        }

        [HttpGet]
        [Route("indicators")]
        public List<Indicator> GetIndicators()
        {
            return _service.GetIndicators();
        }

        [HttpPost]
        [Route("reports/data")]
        public AdHocWijmoResult GetDataEngineServiceURL([FromBody] AdHocQueryParam parameters)
        {
            var adHocWijmoResult = _service.InitializeDataEngine(parameters);
            adHocWijmoResult.DataUrl = Url.Content(adHocWijmoResult.DataUrl);

            return adHocWijmoResult;
        }
    }
}