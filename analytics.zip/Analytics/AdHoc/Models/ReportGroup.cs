﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Analytics.AdHocReports.Models
{
    public class ReportGroup
    {
        public string Type { get; set; }
        public List<string> HierarchyLevels { get; set; }
        public List<ReportHierarchy> Reports { get; set; }
    }
}
