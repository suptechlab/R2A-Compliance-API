﻿using System.Collections.Generic;
using Analytics.Utilities.AdHocQuery.Entity;

namespace Analytics.AdHocReports.Models
{
    public class AdHocWijmoResult
    {
        public string DataUrl { get; set; }
        public List<AdHocResult.WijmoField> Fields { get; set; }
    }
}