﻿using System.Collections.Generic;

namespace Analytics.AdHocReports.Models
{
    public abstract class HierarchyNode
    {
        public abstract bool HasChildren();
    }

    public abstract class HierarchyLeaf : HierarchyNode
    {
        public override bool HasChildren()
        {
            return false;
        }
    }

    public abstract class HierarchyBranch : HierarchyNode
    {
        public List<HierarchyNode> ChildNodes { get; set; }

        public override bool HasChildren()
        {
            return true;
        }
    }
}
