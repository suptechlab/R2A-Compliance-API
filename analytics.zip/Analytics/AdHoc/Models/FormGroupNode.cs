﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Analytics.AdHocReports.Models
{
    public class FormGroupNode : HierarchyBranch
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
