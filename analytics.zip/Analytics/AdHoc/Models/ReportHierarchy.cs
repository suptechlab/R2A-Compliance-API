﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Analytics.AdHocReports.Models
{
    public class ReportHierarchy
    {
        public int ReportId { get; set; }
        public string ReportVersion { get; set; }
        public string ReportName { get; set; }
        public string ReportCode { get; set; }
        public List<HierarchyNode> Hierarchy { get; set; }
    }
}
