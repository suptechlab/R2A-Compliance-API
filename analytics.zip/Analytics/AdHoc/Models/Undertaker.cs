﻿namespace Analytics.AdHocReports.Models
{
    public class Undertaker
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
