﻿using System.Collections.Generic;

namespace Analytics.AdHocReports.Models
{
    public class UndertakerGroup
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    public class UndertakersGrouped : UndertakerGroup
    {
        public List<Undertaker> Undertakers { get; set; }
    }
}
