﻿using System;
using System.Collections.Generic;

namespace Analytics.AdHocReports.DTOs
{
    public class DropdownItemDTO<T>
    {
        public T Id { get; }
        public string Name { get; }

        public DropdownItemDTO(T id, string name)
        {
            Id = id;
            Name = name;
        }

        public static List<DropdownItemDTO<T>> ToDropdownList<TIn>(IEnumerable<TIn> list, Func<TIn, T> keySelector,
            Func<TIn,string> labelSelector)
        {
            var dropdowns = new List<DropdownItemDTO<T>>();
            foreach (var element in list)
            {
                dropdowns.Add(new DropdownItemDTO<T>(keySelector(element),labelSelector(element)));
            }
            return dropdowns;
        }
    }
}
