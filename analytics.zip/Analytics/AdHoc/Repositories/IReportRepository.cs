﻿using System.Collections.Generic;
using Analytics.AdHocReports.Models;

namespace Analytics.AdHoc.Repositories
{
    public interface IReportRepository
    {
        ReportGroup GetSIReports(char? periodCode = null);
        ReportGroup GetSIIReports(char? periodCode = null);

        List<Indicator> GetIndicators();
    }
}
