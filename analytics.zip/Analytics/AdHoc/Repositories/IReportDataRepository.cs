﻿using Analytics.Utilities.AdHocQuery.Entity;

namespace Analytics.AdHoc.Repositories
{
    public interface IReportDataRepository
    {
        AdHocResult GetData(AdHocQueryParam parameters);
    }
}
