﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Analytics.AdHocReports.Models;
using Analytics.Models.Settings;
using Microsoft.Extensions.Options;
using Pinecone.SqlCommandExtensions;

namespace Analytics.AdHoc.Repositories
{
    public class ReportRepository : IReportRepository
    {
        private readonly DatabaseSettings _dbSettings;

        public ReportRepository(IOptions<DatabaseSettings> dbSettings)
        {
            _dbSettings = dbSettings.Value;
        }

        public ReportGroup GetSIReports(char? periodCode = null)
        {
            var group = new ReportGroup()
            {
                Type = "SI",
                HierarchyLevels = new List<string>() { "Report", "Form" }
            };
            using (var connection = new SqlConnection(_dbSettings.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT r.id AS r_id, r.name AS r_name, r.code AS r_code, rv.MajorVersion AS rv_major, rv.MinorVersion AS rv_minor, " +
                                            "f.XmlNode AS f_code, f.ShortName AS f_name " +
                                          "FROM data_whs.report AS r " +
                                          (periodCode.HasValue ? "JOIN data_whs.report_period_type AS pt ON pt.id = r.report_period_type_id " : "") +
                                          $"JOIN [{_dbSettings.RtmDatabaseName}].dbo.ReportVersion AS rv ON r.id = rv.ReportId " +
                                          $"JOIN [{_dbSettings.RtmDatabaseName}].dbo.ReportVersion_FormVersion AS rvfv ON rv.Id = rvfv.ReportVersionId " +
                                          $"JOIN [{_dbSettings.RtmDatabaseName}].dbo.FormVersion AS fv ON rvfv.FormVersionId = fv.Id " +
                                          $"JOIN [{_dbSettings.RtmDatabaseName}].dbo.Form AS f ON fv.FormId = f.Id " +
                                          $"WHERE rv.Id = (SELECT TOP 1 Id FROM [{_dbSettings.RtmDatabaseName}].dbo.ReportVersion WHERE ReportId = r.id ORDER BY ValidSince DESC) " +
                                          "AND processing_type = 'SI' " +
                                          (periodCode.HasValue ? " AND pt.period_code = @periodCode " : "") +
                                          " ORDER BY r.code, r.name, r.id, f.XmlNode, f.ShortName";
                    if (periodCode.HasValue)
                        command.Parameters.AddParameter("@periodCode", periodCode.Value, SqlDbType.Char);
                    command.Prepare();

                    using (var reader = command.ExecuteReader())
                    {
                        var reports = new Dictionary<int, ReportHierarchy>();
                        while (reader.Read())
                        {
                            int reportId = reader.GetInt("r_id");
                            if (!reports.ContainsKey(reportId))
                            {
                                reports.Add(reportId, new ReportHierarchy()
                                {
                                    ReportId = reportId,
                                    ReportVersion = $"{reader.GetString("rv_major").Trim()}.{reader.GetString("rv_minor").Trim()}",
                                    ReportName = reader.GetString("r_name"),
                                    ReportCode = reader.GetString("r_code"),
                                    Hierarchy = new List<HierarchyNode>()
                                });
                            }
                            var report = reports[reportId];
                            report.Hierarchy.Add(new FormNode()
                            {
                                Id = reader.GetString("f_code"),
                                Name = reader.GetString("f_name")
                            });
                        }
                        group.Reports = reports.Values.ToList();
                    }
                }
            }
            return group;
        }

        public ReportGroup GetSIIReports(char? periodCode = null)
        {
            var reportGroup = new ReportGroup()
            {
                Type = "SII",
                HierarchyLevels = new List<string>() { "Report", "Group", "Form" }
            };
            /*
            using (var connection = new SqlConnection(_dbSettings.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT mr.id AS r_id, mr.name AS r_name, mr.code AS r_code, tv.versionCode, " +
                                          "mrt.id AS mrt_id, mrt.code AS mrt_code, mrt.name AS mrt_name, " +
                                          "mrtp.code AS mrtp_code, mrtp.name AS mrtp_name " +
                                          "FROM data_whs_dpm.model_report AS mr " +
                                          "JOIN data_whs_dpm.taxonomy_version AS tv ON mr.taxonomyVersionId = tv.id " +
                                          "JOIN data_whs_dpm.model_report_template AS mrt ON mr.id = mrt.modelReportId " +
                                          "JOIN data_whs_dpm.model_report_template_part AS mrtp ON mrt.id = mrtp.modelReportTemplateId " +
                                          "WHERE mr.id IN " +
                                          "(SELECT mrx.id FROM data_whs_dpm.model_report AS mrx WHERE mrx.taxonomyVersionId = " +
                                          "(SELECT tvx.id FROM data_whs_dpm.taxonomy_version AS tvx WHERE tvx.versionCode = " +
                                          "(SELECT MAX(tvx2.versionCode)  FROM data_whs_dpm.model_report AS mrx2 " +
                                          "INNER JOIN data_whs_dpm.taxonomy_version AS tvx2 ON tvx2.id = mrx2.taxonomyVersionId AND tvx2.taxonomyId = tv.taxonomyId " +
                                          "WHERE mrx2.code = mrx.code))) " +
                                          (periodCode.HasValue ?
                                          " AND EXISTS (SELECT r.id " +
                                                "FROM data_whs.report AS r " +
                                                "JOIN data_whs.period_type AS pt ON r.period_type_id = pt.Id " +
                                                "WHERE r.code = mr.code AND pt.period_code = @periodCode)" : "") +
                                          " ORDER BY mr.code, mr.id, mrt.code, mrt.id, mrtp.code, mrtp.id";
                    if (periodCode.HasValue)
                        command.Parameters.AddParameter("@periodCode", periodCode.Value, SqlDbType.Char);
                    command.Prepare();
                    using (var reader = command.ExecuteReader())
                    {
                        var reports = new Dictionary<int, ReportHierarchy>();
                        var formGroups = new Dictionary<int, FormGroupNode>();
                        while (reader.Read())
                        {
                            int reportId = reader.GetInt("r_id");
                            if (!reports.ContainsKey(reportId))
                            {
                                reports.Add(reportId, new ReportHierarchy()
                                {
                                    ReportId = reportId,
                                    ReportVersion = reader.GetString("versionCode"),
                                    ReportName = reader.GetString("r_name"),
                                    ReportCode = reader.GetString("r_code"),
                                    Hierarchy = new List<HierarchyNode>()
                                });
                            }
                            var report = reports[reportId];
                            int formGroupId = reader.GetInt("mrt_id");
                            if (!formGroups.ContainsKey(formGroupId))
                            {
                                var newFormGroup = new FormGroupNode()
                                var newFormGroup = new FormGroupNode()
                                {
                                    Id = formGroupId,
                                    Name = $"{reader.GetString("mrt_code")} {reader.GetString("mrt_name")}",
                                    ChildNodes = new List<HierarchyNode>()
                                };
                                report.Hierarchy.Add(newFormGroup);
                                formGroups[formGroupId] = newFormGroup;
                            }
                            var formGroup = formGroups[formGroupId];
                            formGroup.ChildNodes.Add(new FormNode()
                            {
                                Id = reader.GetString("mrtp_code"),
                                Name = reader.GetString("mrtp_name")
                            });
                        }
                        reportGroup.Reports = reports.Values.ToList();
                    }
                }
            }
            */
            return reportGroup;
        }

        public List<Indicator> GetIndicators()
        {
            using (var connection = new SqlConnection(_dbSettings.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT id, name, reports FROM data_whs_dpm.indicator";
                    command.Prepare();
                    using (var reader = command.ExecuteReader())
                    {
                        var indicators = new List<Indicator>();
                        while (reader.Read())
                        {

                            indicators.Add(new Indicator()
                            {
                                Id = reader.GetInt("id"),
                                Name = reader.GetString("name"),
                                Reports = reader.GetString("reports").Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(r => r.Trim()).ToList()
                            });

                        }
                        return indicators;
                    }
                }

            }
        }
    }
}