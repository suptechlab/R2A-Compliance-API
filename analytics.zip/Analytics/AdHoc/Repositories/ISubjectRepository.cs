﻿using System.Collections.Generic;
using Analytics.AdHocReports.DTOs;

namespace Analytics.AdHoc.Repositories
{
    public interface ISubjectRepository
    {
        List<DropdownItemDTO<int>> GetSubjectsList();
    }
}