﻿using Analytics.AdHocReports.DTOs;
using Analytics.Models.Settings;
using Microsoft.Extensions.Options;
using Pinecone.SqlCommandExtensions;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Analytics.AdHoc.Repositories
{
    public class WarehouseRepository : IWarehouseRepository
    {
        DatabaseSettings _settings;

        public WarehouseRepository(IOptions<DatabaseSettings> settings)
        {
            _settings = settings.Value;
        }
        public List<DropdownItemDTO<int>> GetWarehousesList()
        {
            using (var connection = new SqlConnection(_settings.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT Id, Name FROM data_whs.Warehouse ORDER BY Name";
                    command.Prepare();
                    using (var reader = command.ExecuteReader())
                    {
                        var warehouses = new List<DropdownItemDTO<int>>();
                        while (reader.Read())
                        {
                            warehouses.Add(new DropdownItemDTO<int>(reader.GetInt("Id"), reader.GetString("Name")));
                        }
                        return warehouses;
                    }
                }
            }
        }
    }
}
