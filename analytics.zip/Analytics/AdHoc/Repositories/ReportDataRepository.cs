using System.Data.SqlClient;
using Analytics.Models.Settings;
using Analytics.Utilities.AdHocQuery;
using Analytics.Utilities.AdHocQuery.Entity;
using BSP.ReportDataConverter.Implementations.Warehouse.Model;
using Microsoft.Extensions.Options;
using Pinecone.ReportDataConverter.Config.Interfaces;

namespace Analytics.AdHoc.Repositories
{
    public class ReportDataRepository : IReportDataRepository
    {
        private readonly DatabaseSettings _settings;
        private readonly IDynamicDropdownDataResolver _dropdownDataResolver;


        public ReportDataRepository(IOptions<DatabaseSettings> settings,
            IDynamicDropdownDataResolver dropdownDataResolver)
        {
            _settings = settings.Value;
            _dropdownDataResolver = dropdownDataResolver;
        }

        public AdHocResult GetData(AdHocQueryParam parameters)
        {
            using (var connection = new SqlConnection(_settings.ConnectionString))
            {
                connection.Open();
                var warehouseInfo = parameters.Warehouse == 0 
                    ? PredefinedWarehouses.GetIndicatorWarehouse()
                    : ConfigurationLoader.LoadWarehouseInfo(parameters.Warehouse, connection);
                
                var result = new AdHocResultSet(warehouseInfo);
                AdHocQuery.Query(parameters, result, connection);
                return result.GenerateResult();
            }
        }
    }
}