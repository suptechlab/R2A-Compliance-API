﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Analytics.AdHocReports.Models;
using Analytics.Models.Settings;
using Microsoft.Extensions.Options;
using Pinecone.SqlCommandExtensions;

namespace Analytics.AdHoc.Repositories
{
    public class UndertakerRepository : IUndertakerRepository
    {
        private readonly DatabaseSettings _settings;

        public UndertakerRepository(IOptions<DatabaseSettings> settings)
        {
            _settings = settings.Value;
        }

        public List<Undertaker> GetUndertakers()
        {
            using (var connection = new SqlConnection(_settings.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT id, name FROM data_whs.subject ORDER BY name";
                    command.Prepare();
                    using (var reader = command.ExecuteReader())
                    {
                        var undertakers = new List<Undertaker>();
                        while (reader.Read())
                        {
                            undertakers.Add(new Undertaker(){Id = reader.GetInt("id"), Name = reader.GetString("name")});
                        }
                        return undertakers;
                    }
                }
            }
        }

        public List<Undertaker> GetUndertakersByGroupId(int groupId)
        {
            using (var connection = new SqlConnection(_settings.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT s.id, s.name FROM data_whs.subject s " +
                        "JOIN data_whs.subject_to_subject_group sg ON sg.subject_id = s.id " +
                        "WHERE sg.subject_group_id = @id " +
                        "ORDER BY name;";
                    command.Parameters.AddParameter("@id", groupId, SqlDbType.Int);
                    command.Prepare();
                    using (var reader = command.ExecuteReader())
                    {
                        var undertakers = new List<Undertaker>();
                        while (reader.Read())
                        {
                            undertakers.Add(new Undertaker() { Id = reader.GetInt("id"), Name = reader.GetString("name") });
                        }
                        return undertakers;
                    }
                }
            }
        }

        public List<UndertakerGroup> GetUdertakerGroups()
        {
            using (var connection = new SqlConnection(_settings.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT id, name FROM data_whs.subject_group ORDER BY name";
                    command.Prepare();
                    using (var reader = command.ExecuteReader())
                    {
                        var groups = new List<UndertakerGroup>();
                        while (reader.Read())
                        {
                            groups.Add(new UndertakerGroup() { Id = reader.GetInt("id"), Name = reader.GetString("name") });
                        }
                        return groups;
                    }
                }
            }
        }
    }
}
