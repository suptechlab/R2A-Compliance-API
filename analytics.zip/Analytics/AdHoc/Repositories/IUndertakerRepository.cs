﻿using System.Collections.Generic;
using Analytics.AdHocReports.Models;

namespace Analytics.AdHoc.Repositories
{
    public interface IUndertakerRepository
    {
        List<UndertakerGroup> GetUdertakerGroups();
        List<Undertaker> GetUndertakers();
        List<Undertaker> GetUndertakersByGroupId(int groupId);
    }
}