﻿using Analytics.AdHocReports.DTOs;
using Analytics.Models.Settings;
using Microsoft.Extensions.Options;
using Pinecone.SqlCommandExtensions;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Analytics.AdHoc.Repositories
{
    public class SubjectRepository : ISubjectRepository
    {
        DatabaseSettings _settings;

        public SubjectRepository(IOptions<DatabaseSettings> settings)
        {
            _settings = settings.Value;
        }

        public List<DropdownItemDTO<int>> GetSubjectsList()
        {
            using (var connection = new SqlConnection(_settings.ConnectionString))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT Id, Text FROM data_whs.vSubject ORDER BY Text";
                    command.Prepare();
                    using (var reader = command.ExecuteReader())
                    {
                        var subjects = new List<DropdownItemDTO<int>>();
                        while (reader.Read())
                        {
                            subjects.Add(new DropdownItemDTO<int>(reader.GetInt("Id"), reader.GetString("Text")));
                        }
                        return subjects;
                    }
                }
            }
        }
    }
}
