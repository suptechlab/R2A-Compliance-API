﻿using System.Collections.Generic;
using Analytics.AdHocReports.DTOs;

namespace Analytics.AdHoc.Repositories
{
    public interface IWarehouseRepository
    {
        List<DropdownItemDTO<int>> GetWarehousesList();
    }
}