using Analytics.Indicators.Services;
using Analytics.Utilities.Indicators.Entities;
using Microsoft.AspNetCore.Mvc;
using static Analytics.Utilities.Indicators.Entities.IndicatorQueryResult;

namespace Analytics.Indicators
{
    [Produces("application/json")]
    [Route("api/indicators")]
    public class IndicatorsController : Controller
    {
        private readonly IIndicatorsService _service;

        public IndicatorsController(IIndicatorsService service)
        {
            _service = service;
        }

        [HttpPost]
        [Route("get")]
        public ResultIndicator[] GetUndertakerListByType([FromQuery] string type, [FromBody] IndicatorQueryParams queryParams)
        {
            queryParams.SubCode = type;
            return _service.GetIndicators(queryParams);
        }
        

        //[HttpPost]
        //[Route("indicators")]
        //public IndicatorQueryResult GetUndertakerList([FromBody] IndicatorQueryParams queryParams)
        //{
        //    return _service.GetIndicators(queryParams);
        //}

    }
}