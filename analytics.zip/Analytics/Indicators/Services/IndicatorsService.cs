﻿using Analytics.Indicators.Repositories;
using Analytics.Utilities.Indicators.Entities;
using System.Linq;
using static Analytics.Utilities.Indicators.Entities.IndicatorQueryResult;

namespace Analytics.Indicators.Services
{
    public class IndicatorsService : IIndicatorsService
    {
        private readonly IIndicatorsRepository _indicatorsRepository;


        public IndicatorsService(IIndicatorsRepository indicatorsRepository)
        {
            _indicatorsRepository = indicatorsRepository;
        }

        public ResultIndicator[] GetIndicators(IndicatorQueryParams queryParams)
        {
            return _indicatorsRepository.GetIndicators(queryParams).Groups.SelectMany(x => x.Indicators).ToArray();
        }

        public IndicatorQueryResult GetIndicators(int instanceId)
        {
            return _indicatorsRepository.GetIndicators(instanceId);
        }

    }
}
