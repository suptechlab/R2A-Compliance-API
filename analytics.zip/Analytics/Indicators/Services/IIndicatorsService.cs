﻿using Analytics.Utilities.Indicators.Entities;
using static Analytics.Utilities.Indicators.Entities.IndicatorQueryResult;

namespace Analytics.Indicators.Services
{
    public interface IIndicatorsService
    {
        ResultIndicator[] GetIndicators(IndicatorQueryParams queryParams);
        IndicatorQueryResult GetIndicators(int instanceId);
    }
}