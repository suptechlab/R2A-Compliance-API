﻿using Analytics.Indicators.Models;
using Analytics.Utilities.Indicators.Entities;

namespace Analytics.Indicators.Repositories
{
    public interface IIndicatorsRepository
    {
        IndicatorQueryResult GetIndicators(IndicatorQueryParams queryParams);
        IndicatorQueryResult GetIndicators(int instanceId);
        InstanceInfo GetInstanceInfo(int instanceId);
    }
}