﻿using System;
using Analytics.Utilities.Indicators;
using Analytics.Utilities.Indicators.Entities;
using System.Data.SqlClient;
using Analytics.Indicators.Models;
using Pinecone.SqlCommandExtensions;
using Analytics.Models.Settings;
using Microsoft.Extensions.Options;
using System.Linq;

namespace Analytics.Indicators.Repositories
{
    public class IndicatorsRepository : IIndicatorsRepository
    {
        private readonly DatabaseSettings _dbSettings;

        public IndicatorsRepository(IOptions<DatabaseSettings> dbSettings)
        {
            _dbSettings = dbSettings.Value;
        }

        public IndicatorQueryResult GetIndicators(IndicatorQueryParams queryParams)
        {
            using (var connection = new SqlConnection(_dbSettings.ConnectionString))
            {
                connection.Open();
                return IndicatorQuery.Query(queryParams, connection);
            }
        }

        public IndicatorQueryResult GetIndicators(int instanceId)
        {
            var instanceInfo = GetInstanceInfo(instanceId);
            using (var connection = new SqlConnection(_dbSettings.ConnectionString))
            {
                connection.Open();
                return IndicatorQuery.Query(instanceInfo, connection);
            }
        }
        
        public InstanceInfo GetInstanceInfo(int instanceId)
        {
            const string sql =
                "SELECT i.id AS instanceId, i.report_year AS reportYear, i.report_period AS reportPeriod, i.report_date AS reportDate, i.period_string AS reportPeriodString, i.submitted_report_id AS submittedReportId, i.final AS isFinal, i.submission_time AS submissionTime, " +
                "s.id AS subjectId, s.name AS subjectName, s.short_name AS subjectShortName, " +
                "r.id AS reportId, r.code AS reportCode, r.name AS reportName, r.processing_type AS processingType, " +
                "rpt.id AS reportPeriodTypeId, rpt.name AS reportPeriodTypeName, rpt.short_name AS reportPeriodTypeShortName, rpt.period_code AS reportPeriodTypeCode " +
                "FROM data_whs.instance AS i " +
                "INNER JOIN data_whs.subject AS s ON s.id = i.subject_id " +
                "INNER JOIN data_whs.report AS r ON r.id = i.report_id " +
                "INNER JOIN data_whs.report_period_type AS rpt ON rpt.id = r.report_period_type_id " +
                "WHERE i.id = @instanceId";
            
            using (var connection = new SqlConnection(_dbSettings.ConnectionString))
            {
                connection.Open();
                using (var stmt = new SqlCommand(sql, connection))
                {
                    stmt.Parameters.AddWithValue("@instanceId", instanceId);
                    using (var reader = stmt.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new InstanceInfo
                            {
                                Id = reader.GetInt("instanceId"),
                                IsFinal = reader.GetValue<bool>("isFinal"),
                                ReportYear = reader.GetInt("reportYear"),
                                ReportPeriod = reader.GetNullable<int>("reportPeriod"),
                                Period = reader.GetString("reportPeriodString"),
                                ReportDate = reader.GetNullable<DateTime>("reportDate"),
                                SubmittedReportId = reader.GetInt("submittedReportId"),
                                SubmittionTime = reader.GetValue<DateTime>("submissionTime"),
                                Subject = new SubjectInfo
                                {
                                    Id = reader.GetInt("subjectId"),
                                    Name = reader.GetString("subjectName"),
                                    ShortName = reader.GetString("subjectShortName")
                                },
                                Report = new ReportInfo
                                {
                                    Id = reader.GetInt("reportId"),
                                    Name = reader.GetString("reportName"),
                                    Code = reader.GetString("reportCode"),
                                    ProcessingType = reader.GetString("processingType"),
                                    ReportPeriodType = new ReportPeriodTypeInfo
                                    {
                                        Id = reader.GetInt("reportPeriodTypeId"),
                                        Name = reader.GetString("reportPeriodTypeName"),
                                        Code = reader.GetString("reportPeriodTypeCode"),
                                        ShortName = reader.GetString("reportPeriodTypeShortName")
                                    }
                                }
                            };
                        }
                    }
                }
                return null;
            }
        }
    }
}
