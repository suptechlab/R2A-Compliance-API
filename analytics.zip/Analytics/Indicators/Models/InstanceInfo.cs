﻿using System;

namespace Analytics.Indicators.Models
{
    public class InstanceInfo
    {
        public int Id { get; set; }
        public int ReportYear { get; set; }
        public int? ReportPeriod { get; set; }
        public DateTime? ReportDate { get; set; }
        public string Period { get; set; }
        public int SubmittedReportId { get; set; }
        public bool IsFinal { get; set; }
        public DateTime SubmittionTime { get; set; }
        public ReportInfo Report { get; set; }
        public SubjectInfo Subject { get; set; }
    }
}