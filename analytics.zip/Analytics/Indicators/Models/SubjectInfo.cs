namespace Analytics.Indicators.Models
{
    public class SubjectInfo
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ShortName { get; set; }        
    }
}