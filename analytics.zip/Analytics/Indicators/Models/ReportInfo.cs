﻿namespace Analytics.Indicators.Models
{
    public class ReportInfo
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public string ProcessingType { get; set; }
        public ReportPeriodTypeInfo ReportPeriodType { get; set; }
        
    }
}