const publicPath = 'public';
const os = require('os');
const merge = require('webpack-merge');
const parts = require('./webpack.parts');
const fs = require('fs');
const path = require('path');
const webpack = require('webpack');

const PATHS = {
    app: `${__dirname}/Webpack`,
    build: `${__dirname}/wwwroot/js`,
    devserv: `${__dirname}/devserv`,
    fixedPath: '/'
};

const commonConfig = merge([
    parts.loadResolver(),
    parts.loadSvgs({ exclude: /node_modules/ }),
    parts.loadMds({ exclude: /node_modules/ }),
    parts.loadIcos({ exclude: /node_modules/ })
]);

function loadEntriesProd(folderPrefix = "") {
    let entries = {};
    const appFilenameWithSubfolder = `${PATHS.app}/pages`;
    const files = fs.readdirSync(appFilenameWithSubfolder);
    files.reduce((accEntry, fileName) => {
        "use strict";
        const position = fileName.indexOf('Page');
        if (position !== -1) {
            const entryName = folderPrefix + fileName.substring(0, fileName.indexOf('Page'));
            let entryArray = [];
            entryArray.push(path.join(appFilenameWithSubfolder, "polyfill.ts"));
            entryArray.push(path.join(appFilenameWithSubfolder, fileName));
            accEntry[entryName] = entryArray;
            // console.log("Added entry: {" + entryName + ":" + path.join(PATHS.app, fileName) + "}");
        }
        return accEntry;
    }, entries);

    // console.log(entries)
    return entries;
}

function loadEntriesDev(folderPrefix = "", devServerEnabled = false) {
    let entries = {};
    const appFilenameWithSubfolder = `${PATHS.app}/pages`;
    const files = fs.readdirSync(devServerEnabled === true ? PATHS.devserv : appFilenameWithSubfolder);
    files.reduce((accEntry, fileName) => {
        "use strict";
        const position = fileName.indexOf(devServerEnabled === true ? 'demo' : 'Page');
        if (position !== -1) {
            const entryName = folderPrefix + fileName.substring(0, fileName.indexOf('Page'));
            if (devServerEnabled === true) {
                let entryArray = [
                    'webpack-dev-server/client?http://localhost:8080'
                ];
                entryArray.push(path.join(devServerEnabled ? PATHS.devserv : appFilenameWithSubfolder, fileName));
                accEntry[entryName] = entryArray;
            } else {
                let entryArray = [];
                entryArray.push(path.join(appFilenameWithSubfolder, "polyfill.ts"));
                entryArray.push(path.join(appFilenameWithSubfolder, fileName));
                accEntry[entryName] = entryArray;
            }
            //      console.log("Added entry: {" + entryName + ":" + path.join(PATHS.app, fileName) + "}");
        }
        return accEntry;
    }, entries);

    // console.log(entries)
    return entries;
}

const productionConfig = merge([
    {
        bail: false,
        devtool: 'source-map',
        entry: loadEntriesProd(),
        output: {
            filename: '[name].[chunkhash:4].js',
            path: PATHS.build,
            pathinfo: true,
            publicPath: PATHS.fixedPath
        },
    },
    parts.setNoErrors(),
    parts.loadJavaScript({ include: __dirname + '/', exclude: /node_modules/ }),
    parts.loadTypeScript({ include: __dirname + '/', exclude: /node_modules/ }),
    parts.minifyJavaScript(),
    parts.clean(PATHS.build),
    parts.loadPostCSS(),
    parts.loadLess(),
    parts.minifyCSS({
        options: {
            discardComments: {
                removeAll: true
            },
            safe: true,
        }
    }),
    parts.loadProdCss({ include: __dirname + '/', exclude: /node_modules/ }),
    parts.loadImages({
        options: {
            limit: 1024,
            name: '[name].[hash:4].[ext]'
        }
    }),
    parts.setCompression(),
    {
        optimization: {
            splitChunks: {
                cacheGroups: {
                    commons: {
                        test: /[\\/]node_modules[\\/]/,
                        name: "vendor",
                        chunks: "initial",
                    },
                },
            },
        },
    },
]);

const developmentConfig = merge([
    {
        bail: true,
        watch: true,
        entry: loadEntriesDev("", true),
        output: {
            devtoolModuleFilenameTemplate: 'webpack:///[absolute-resource-path]',
            filename: '[name].js',
            path: PATHS.build,
            pathinfo: true,
            publicPath: PATHS.fixedPath
        },
        devtool: 'source-map',
        plugins: [
            new webpack.NamedModulesPlugin()
        ]
    },
    parts.setEnvVariables({
        'process.env': {
            NODE_ENV: '"development"',
            styleguideEnabled: true
        }
    }),
    parts.setFreeVariable('process.env.DEV', 'true'),
    parts.clean(PATHS.build),
    parts.devServer({
        host: process.env.HOST,
        port: process.env.PORT
    }),
    parts.lintTypeScript(
        {
            include: PATHS.app,
            options: {
                tslint: {
                    emitErrors: true,
                    failOnHint: true
                }
            }
        }),
    parts.loadJavaScript({ include: __dirname + '/', exclude: /node_modules/ }),
    parts.loadTypeScript({ include: [PATHS.devserv, PATHS.app], exclude: /node_modules/ }),
    parts.loadPostCSS(),
    parts.loadLess(),
    parts.loadDevCss({
        options: {
            sourceMap: true,
            minimize: true
        }
    }),
    parts.loadImages(),
    parts.generateSourceMaps("source-map"),
    parts.generateIndexHtml({ template: './devserv/my-index.ejs' }),
    {
        optimization: {
            splitChunks: {
                cacheGroups: {
                    commons: {
                        test: /[\\/]node_modules[\\/]/,
                        name: "vendor",
                        chunks: "initial",
                    },
                },
            },
        },
    },
]);

module.exports = mode => {
    console.log('============= mode => ' + mode + ' =============');
    let modeConfig = mode === 'production' ? productionConfig : developmentConfig;
    return merge(commonConfig, modeConfig, { mode });
};