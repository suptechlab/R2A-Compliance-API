﻿using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json.Linq;

namespace Analytics.DynamicFields
{
    public class DynamicOptionsQuery
    {
        public string Source { get; }
        public string SourceParam { get; }
        public Dictionary<string, object> HeaderFields { get; }
        public Dictionary<string, object> ZFields { get; }
        public Dictionary<string, object> FormFields { get; }

        public DynamicOptionsQuery(string source, string sourceParam, Dictionary<string, object> headerFields = null,
            Dictionary<string, object> zFields = null, Dictionary<string, object> formFields = null)
        {
            Source = source;
            SourceParam = sourceParam;
            HeaderFields = headerFields;
            ZFields = zFields;
            FormFields = formFields;
        }

        public DynamicOptionsQuery(JObject query)
        {
            Source = (string) query["sourceType"];
            SourceParam = (string) query["sourceParam"];
            IDictionary<string, JToken> headers = (JObject) query["headerFields"];
            HeaderFields = headers?.ToDictionary(pair => pair.Key, pair => pair.Value.ToObject<object>());
            IDictionary<string, JToken> zJObject = (JObject) query["zFields"];
            ZFields = zJObject?.ToDictionary(pair => pair.Key, pair => pair.Value.ToObject<object>());
            IDictionary<string, JToken> fields = (JObject) query["formFields"];
            FormFields = fields?.ToDictionary(pair => pair.Key, pair => pair.Value.ToObject<object>());
        }
    }
}