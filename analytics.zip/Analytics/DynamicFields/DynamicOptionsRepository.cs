using System.Collections.Generic;
using System.Data.SqlClient;
using Analytics.Models.Settings;
using Dapper;
using Microsoft.Extensions.Options;

namespace Analytics.DynamicFields
{
    public class DynamicOptionsRepository : IDynamicOptionsRepository
    {
        private readonly DatabaseSettings _dbSettings;

        public DynamicOptionsRepository(IOptions<DatabaseSettings> dbSettings)
        {
            _dbSettings = dbSettings.Value;
        }

        public IEnumerable<SelectOptionDTO> GetAllSubsidiaries()
        {
            using (var connection = new SqlConnection(_dbSettings.ConnectionString))
            {
                connection.Open();
                return connection.Query<SelectOptionDTO>(
                    "SELECT b.Code AS Value, b.Title AS Text, 'SUBSIDIARY' AS [Group] " +
                    "FROM bsp.Bank AS b " +
                    "WHERE ParentBankId IS NOT NULL");
            }
        }

        public IEnumerable<SelectOptionDTO> GetSubsidiaries(string bankCode)
        {
            using (var connection = new SqlConnection(_dbSettings.ConnectionString))
            {
                connection.Open();
                return connection.Query<SelectOptionDTO>(
                    "SELECT b.Code AS Value, b.Title AS Text, 'SUBSIDIARY' AS [Group] " +
                    "FROM bsp.Bank AS b " +
                    "INNER JOIN bsp.Bank AS pb ON pb.Id = b.ParentBankId " +
                    "WHERE pb.Code = @bankCode",
                    new {bankCode});
            }
        }

        private const string GetBanksSql =
            "SELECT b.Code AS Value, b.Title AS Text, 'Undertaking' AS [Group] FROM bsp.Bank AS b";
        public IEnumerable<SelectOptionDTO> GetAllBanks()
        {
            using (var connection = new SqlConnection(_dbSettings.ConnectionString))
            {
                connection.Open();
                return connection.Query<SelectOptionDTO>(GetBanksSql);
            }
        }

        private const string GetBorrowersSql = "SELECT dl.Value, dl.Text, 'BORROWER' AS [Group] FROM lists.DynamicLists AS dl WHERE dl.SubType = 'BORROWER_G_MEMBER'";
        public IEnumerable<SelectOptionDTO> GetAllBorrowers()
        {
            using (var connection = new SqlConnection(_dbSettings.ConnectionString))
            {
                connection.Open();
                return connection.Query<SelectOptionDTO>(GetBorrowersSql);
            }
        }

        public IEnumerable<SelectOptionDTO> GetBorrowers(int borrowerGroupCodeId)
        {
            using (var connection = new SqlConnection(_dbSettings.ConnectionString))
            {
                connection.Open();
                return connection.Query<SelectOptionDTO>(GetBorrowersSql + " AND dl.GroupId = @borrowerGroupCodeId",
                    new {borrowerGroupCodeId});
            }
        }


        private const string GetBranchesSql =
            "SELECT br.Code AS Value, br.Title AS Text, 'BRANCH' AS [Group]  FROM bsp.Branch AS br";

        private const string DomesticSql = " JOIN bsp.Region AS r ON br.RegionId = r.Id AND r.IsDomestic = 1";
        public IEnumerable<SelectOptionDTO> GetAllBranches(bool domestic = false)
        {
            using (var connection = new SqlConnection(_dbSettings.ConnectionString))
            {
                connection.Open();
                return connection.Query<SelectOptionDTO>(GetBranchesSql+(domestic?DomesticSql:""));
            }
        }

        public IEnumerable<SelectOptionDTO> GetBranches(string bankCode, bool domestic = false)
        {
            using (var connection = new SqlConnection(_dbSettings.ConnectionString))
            {
                connection.Open();
                return connection.Query<SelectOptionDTO>(GetBranchesSql + (domestic ? DomesticSql : "") + " INNER JOIN bsp.Bank AS b ON b.Id = br.BankId WHERE b.Code = @bankCode", new {bankCode});
            }

        }
    }
}