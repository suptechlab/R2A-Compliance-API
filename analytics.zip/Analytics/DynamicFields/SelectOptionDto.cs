﻿namespace Analytics.DynamicFields
{
    public class SelectOptionDTO
    {
        public string Value { get;  }
        public string Text { get;  }
        public string Group { get;  }
        public bool Disabled { get; }

        public SelectOptionDTO(string value, string text) : this(value,text,null, false) { }
        public SelectOptionDTO(string value, string text, string group) : this(value, text, group, false) { }
        public SelectOptionDTO(string value, string text,  bool disabled) : this(value, text, null, disabled) { }

        public SelectOptionDTO(string value, string text, string group, bool disabled)
        {
            Value = value;
            Text = text;
            Group = group;
            Disabled = disabled;
        }
    }
}
