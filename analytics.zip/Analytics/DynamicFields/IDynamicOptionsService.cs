using System.Collections.Generic;

namespace Analytics.DynamicFields
{
    public interface IDynamicOptionsService
    {
        IEnumerable<SelectOptionDTO> GetOptions(DynamicOptionsQuery queryParams, bool all = false);
    }
}