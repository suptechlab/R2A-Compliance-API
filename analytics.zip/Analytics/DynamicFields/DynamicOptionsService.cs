using System.Collections.Generic;

namespace Analytics.DynamicFields
{

    public class DynamicOptionsService : IDynamicOptionsService
    {
        private readonly IDynamicOptionsRepository _repository;

        public DynamicOptionsService(IDynamicOptionsRepository repository)
        {
            _repository = repository;
        }

        public IEnumerable<SelectOptionDTO> GetOptions(DynamicOptionsQuery queryParams, bool all = false)
        {
            switch (queryParams.Source)
            {
                case "SUBSIDIARY":
                    return all
                        ? _repository.GetAllSubsidiaries()
                        : _repository.GetSubsidiaries((string)GetOrNull(queryParams.HeaderFields,"Undertaking"));
                case "Undertaking":
                    return _repository.GetAllBanks();
                case "BORROWER":
                    if(all)
                        return _repository.GetAllBorrowers();
                    var bankGroupObj = GetOrNull(queryParams.FormFields, "R1C1");
                    if(bankGroupObj == null)
                        return new List<SelectOptionDTO>();
                    int bankGroupId;
                    if(bankGroupObj is string)
                    {
                        bankGroupId = int.Parse((string) bankGroupObj);
                    }
                    else
                    {
                        bankGroupId = (int) bankGroupObj;
                    }
                    return _repository.GetBorrowers(bankGroupId);
                case "BRANCH":
                    return all
                        ? _repository.GetAllBranches()
                        : _repository.GetBranches((string)GetOrNull(queryParams.HeaderFields, "Undertaking"));
                case "BRANCH_DOM":
                    return all
                        ? _repository.GetAllBranches(domestic: true)
                        : _repository.GetBranches((string)GetOrNull(queryParams.HeaderFields, "Undertaking"), domestic: true);
                default: 
                   return new List<SelectOptionDTO>();
            }
        }

        private static object GetOrNull(Dictionary<string, object> dict, string key)
        {
            return dict.ContainsKey(key) ? dict[key] : null;
        }

        
    }
}