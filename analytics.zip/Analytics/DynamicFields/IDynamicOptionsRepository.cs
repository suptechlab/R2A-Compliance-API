using System.Collections.Generic;

namespace Analytics.DynamicFields
{
    public interface IDynamicOptionsRepository
    {
        IEnumerable<SelectOptionDTO> GetAllSubsidiaries();
        IEnumerable<SelectOptionDTO> GetSubsidiaries(string bankCode);
        IEnumerable<SelectOptionDTO> GetAllBorrowers();
        IEnumerable<SelectOptionDTO> GetBorrowers(int borrowerGroupCodeId);
        IEnumerable<SelectOptionDTO> GetAllBranches(bool domestic = false);
        IEnumerable<SelectOptionDTO> GetBranches(string bankCode, bool domestic = false);
        IEnumerable<SelectOptionDTO> GetAllBanks();
    }
}