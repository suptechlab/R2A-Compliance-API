﻿using System.Collections.Generic;
using System.Linq;
using Pinecone.ReportDataConverter.Config;
using Pinecone.ReportDataConverter.Config.Interfaces;

namespace Analytics.DynamicFields
{
    public class ServiceDynamicDataResolver : IDynamicDropdownDataResolver
    {
        private readonly IDynamicOptionsService _dynamicOptionsService;

        public ServiceDynamicDataResolver(IDynamicOptionsService dynamicOptionsService)
        {
            _dynamicOptionsService = dynamicOptionsService;
        }

        public List<DropDownValue> GetDropDownValues(DynamicDropdownSource.Value sourceValue)
        {
            var headerDict = sourceValue.HeaderValues.ToDictionary(key => key.Item1, value => value.Item2);
            var zDict = sourceValue.ZValues.ToDictionary(key => key.Item1, value => value.Item2);
            var fieldDictionary = sourceValue.DataValues.ToDictionary(key => key.Item1, value => value.Item2);

            var optionsQuery = new DynamicOptionsQuery(sourceValue.SourceType, sourceValue.SourceParam, headerDict, zDict, fieldDictionary);
            var selectOptions = _dynamicOptionsService.GetOptions(optionsQuery);
            return selectOptions.Select((option, i) => new DropDownValue(option.Value, option.Text)).ToList();
        }

        public List<DropDownValue> GetAllDropDownValuesForSource(string sourceType, string sourceParam)
        {
            var selectOptions =
                _dynamicOptionsService.GetOptions(new DynamicOptionsQuery(sourceType, sourceParam), all: true);
            return selectOptions.Select((option, i) => new DropDownValue(option.Value, option.Text)).ToList();
        }
    }
}