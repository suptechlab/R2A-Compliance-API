﻿using Analytics.AdHoc.Repositories;
using Analytics.AdHocReports.Services;
using Analytics.DynamicFields;
using Analytics.Indicators.Repositories;
using Analytics.Indicators.Services;
using Analytics.Models.Settings;
using Analytics.Utilities;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Pinecone.ReportDataConverter.Config.Interfaces;
using System;
using System.Threading.Tasks;
using NLog.Extensions.Logging;
using NLog.Web;
using Microsoft.Extensions.Logging;

namespace Analytics
{
    public class Startup
    {
        public Startup(IHostingEnvironment env)
        {
            var builder = new ConfigurationBuilder()
               .SetBasePath(env.ContentRootPath)
               .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
               .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
               .AddEnvironmentVariables();
            Configuration = builder.Build();
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            
            services.AddMvc();
            services.AddOptions();
            services.AddSession();
            services.AddCors(options =>
            {
                options.AddPolicy("AllowAllOrigins",
                    builder => builder.AllowAnyOrigin()
                        .AllowAnyMethod()
                        .AllowAnyHeader()
                        .AllowCredentials());
            });

            C1.Web.Mvc.LicenseManager.Key = License.Key;
            C1.Web.Mvc.Olap.LicenseManager.Key = License.Key;
            C1.Web.Api.LicenseManager.Key = License.Key;
            C1.Web.Api.DataEngine.LicenseManager.Key = License.Key;

            services.Configure<DatabaseSettings>(Configuration.GetSection("DatabaseSettings"));
            services.Configure<WijmoLicense>(Configuration.GetSection("WijmoLicense"));

            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddTransient<IUndertakerRepository, UndertakerRepository>();
            services.AddTransient<IReportRepository, ReportRepository>();
            services.AddTransient<IReportDataRepository, ReportDataRepository>();
            services.AddTransient<IIndicatorsRepository, IndicatorsRepository>();
            services.AddSingleton<IWarehouseRepository, WarehouseRepository>();
            services.AddSingleton<ISubjectRepository, SubjectRepository>();

            services.AddTransient<IReportDataService, ReportDataService>();
            services.AddTransient<IIndicatorsService, IndicatorsService>();

            services.AddSingleton<IDataEngineManager, DataEngineManager>();
            services.AddScoped<IDynamicOptionsService, DynamicOptionsService>();
            services.AddScoped<IDynamicOptionsRepository, DynamicOptionsRepository>();
            services.AddScoped<IDynamicDropdownDataResolver, ServiceDynamicDataResolver>();

            services.AddSingleton<GlobalExceptionsLogger>(new GlobalExceptionsLogger());
            
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env, IDataEngineManager dataEngine, ILoggerFactory loggerFactory, IServiceProvider serviceProvider)
        {
            //NLog config
            loggerFactory.AddNLog();
            loggerFactory.ConfigureNLog("nlog.config");
            app.AddNLogWeb();

            dataEngine.Setup(app, Configuration.GetSection("DataEngineWorkspaceFolderRoot").Get<string>());

            app.Use((c, next) => serviceProvider.GetService<GlobalExceptionsLogger>().Invoke(c, next));

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseStaticFiles();
            app.UseMvcWithDefaultRoute();

            app.MapWhen(x => x.Request.Path.Value.StartsWith("/adhoc") || x.Request.Path.Value.StartsWith("/indicators/rest") || x.Request.Path.Value.StartsWith("/indicators/bank"), builder =>
            {
                builder.UseMvc(routes =>
                {
                    routes.MapRoute(
                        name: "default",
                        template: "{controller=Home}/{action=Index}/{id?}");

                    routes.MapRoute(
                        name: "catch-all",
                        template: "{*url}",
                        defaults: new { controller = "Home", action = "Index" }
                    );
                });
            });

            app.Run(ctx =>
            {
                ctx.Response.StatusCode = StatusCodes.Status404NotFound;
                return Task.CompletedTask;
            });
        }
    }
}
