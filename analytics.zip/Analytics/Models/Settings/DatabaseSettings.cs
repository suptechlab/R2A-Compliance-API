﻿namespace Analytics.Models.Settings
{
    public class DatabaseSettings
    {
        public string ConnectionString { get; set; }
        public string RtmDatabaseName { get; set; }
        public string S1ADatabaseName { get; set; }
    }
}
