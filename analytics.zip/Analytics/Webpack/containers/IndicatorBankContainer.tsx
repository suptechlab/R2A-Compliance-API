import "./container.pcss";

import { Layout } from "antd";
import React, { Component } from "react";
import Header from "../components/header/Header";
import IndicatorConfigPanel from "../components/indicators/IndicatorConfigPanel";
import IndicatorList from "../components/indicators/IndicatorList";
import { IndicatorStore } from "../store/IndicatorStore";

const { Content } = Layout;

export default class IndicatorBankContainer extends Component<{ match }> {
    private store: IndicatorStore;

    constructor(props) {
        super(props);

        this.store = new IndicatorStore("BANK");
    }

    public render() {
        return (
            <Content className={"layout__content"}>
                <IndicatorConfigPanel store={this.store} />
                <IndicatorList store={this.store} />
            </Content>
        );
    }
}
