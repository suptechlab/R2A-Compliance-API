import "./container.pcss";

import { Layout } from "antd";
import { observer } from "mobx-react";
import React, { Component } from "react";
import AdHocConfigPanel from "../components/adhoc/AdHocConfigPanel";
import WijmoWrapper from "../components/adhoc/WijmoWrapper";
import AdHocStore, { IAdHocStore } from "../store/AdHocStore";

const { Content } = Layout;

@observer
class AdHocContainer extends Component {
    private store: IAdHocStore;

    constructor(props) {
        super(props);
        this.store = new AdHocStore();
    }

    public render() {
        return (
            <Content className={"layout__content"}>
                <AdHocConfigPanel store={this.store} />
                {this.store.wijmoActive && <WijmoWrapper store={this.store} />}
            </Content>
        );
    }
}

export default AdHocContainer;
