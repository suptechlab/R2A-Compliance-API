import "./container.pcss";


import { Layout } from "antd";
import React, { SFC } from "react";
import { Redirect, RouteComponentProps } from "react-router";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import { setLicenseKey } from "wijmo/wijmo";
import Error from "../components/error/Error";
import Header from "../components/header/Header";
import AdHocContainer from "./AdHocContainer";
import IndicatorBankContainer from "./IndicatorBankContainer";
import IndicatorRestContainer from "./IndicatorRestContainer";

const { Content } = Layout;

const Err = () => {
    return (
        <Error code={404} message={"Page not found"} />
    );
};

declare const wijmoLicenseKey: any;

const MainContainer: SFC = () => {
    setLicenseKey(wijmoLicenseKey);

    return (
        <Router>
            <Layout className={"layout"}>
                <Header />
                <Switch>
                    <Route
                        exact
                        path={"/adhoc"}
                        component={AdHocContainer}
                    />
                    <Route
                        exact
                        path={"/indicators/bank"}
                        component={IndicatorBankContainer}
                    />
                    <Route
                        exact
                        path={"/indicators/rest"}
                        component={IndicatorRestContainer}
                    />
                    <Redirect from={"/"} to={"/adhoc"} />
                    <Route render={Err} />
                </Switch>
            </Layout>
        </Router>
    );
};

export default MainContainer;
