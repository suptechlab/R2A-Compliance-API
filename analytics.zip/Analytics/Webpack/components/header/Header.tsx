import "./header.pcss";

import { Icon, Layout, Menu } from "antd";
import countBy from "lodash/countBy";
import isNil from "lodash/isNil";
import React, { SFC } from "react";
import { Route, RouteComponentProps, Switch } from "react-router";
import { NavLink } from "react-router-dom";

const AntHeader = Layout.Header;
const { Item } = Menu;

const Header: SFC<{}> = () => {

    return (
        <AntHeader
            className={"header"}
        >
            <div className="header--logo" />
            <Menu
                className={"header--menu"}
                theme="dark"
                mode="horizontal"
            >
                <Item
                    key={"adhoc"}
                >
                    <NavLink to={"/adhoc"}>
                        <span>
                            <Icon type="line-chart" />
                            {"AdHoc"}
                        </span>
                    </NavLink>
                </Item>
                <Item
                    key={"indicators/rd"}
                >
                    <NavLink to={"/indicators/bank"}>
                        <span>
                            <Icon type="bank" />
                            {"BANK Indicators"}
                        </span>
                    </NavLink>
                </Item>
                <Item
                    key={"indicators/td"}
                >
                    <NavLink to={"/indicators/rest"}>
                        <span>
                            <Icon type="home" />
                            {"REST Indicators"}
                        </span>
                    </NavLink>
                </Item>
            </Menu>
        </AntHeader>
    );
};

export default Header;
