import "./error.pcss";

import { Button, Layout } from "antd";
import React, { SFC } from "react";
import { Link } from "react-router-dom";

const { Content } = Layout;

export interface IErrorProps {
    code: number | string | undefined;
    message: string | undefined;
}

const Error: SFC<IErrorProps> = ({ code, message }) => {
    const redirect = () => {
        window.location.href = window.location.protocol + "//" + window.location.host;
    };

    return (
        <Layout className={"layout"}>
            <Content className={"content"}>
                <div className={"exception"}>
                    <div className={"img"}>
                        <div className={"background"} />
                    </div>
                    <div className={"message"}>
                        <h1>{code}</h1>
                        <div className={"description"}>{message}</div>
                        <div className={"actions"}>
                            <Button
                                onClick={redirect}
                                type={"primary"}
                            >
                                {"Return"}
                            </Button>
                        </div>
                    </div>
                </div>
            </Content>
        </Layout>
    );
};

export default Error;
