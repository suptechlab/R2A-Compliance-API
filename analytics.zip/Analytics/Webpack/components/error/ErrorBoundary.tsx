import { observer } from "mobx-react";
import React, { Component } from "react";

import Error from "./Error";

export interface IErrorProps {
    children: any;
    code?: string;
    message?: string;
}

export interface IErrorState {
    hasError: boolean;
}

export default class ErrorBoundary extends Component<IErrorProps, IErrorState> {
    constructor(props: IErrorProps) {
        super(props);

        this.state = {
            hasError: false,
        };
    }

    public componentDidCatch(error: any, info: any) {
        this.setState({ hasError: true });
    }

    public render() {
        if (this.state.hasError) {
            return <Error code={"400"} message={"Something went wrong on client."} />;
        }

        return this.props.children;
    }
}
