import "./adhoc.pcss";

import { Card, Col, Form, Icon, Row } from "antd";
import { observer } from "mobx-react";
import React from "react";
import { IAdHocStore } from "../../store/AdHocStore";
import Cascader from "../../util/components/Cascader";
import Checkbox from "../../util/components/Checkbox";
import Select from "../../util/components/Select";

const { Item } = Form;

const formItemLayout = {
    labelCol: {
        xs: { span: 24 },
        sm: { span: 8 },
    },
    wrapperCol: {
        xs: { span: 24 },
        sm: { span: 16 },
    },
};

export interface IAdHocChartConfigPanelProps {
    store: IAdHocStore;
}

const AdHocChartConfigPanel = observer(({ store }) => {

    const handleFetchIndicators = () => {
        store.loadIndicators();
    };

    return (
        <Form
        >
            <Row>
                <Col span={5}>
                    <Item
                        {...formItemLayout}
                        label={"Chart type"}
                    >
                        <Select
                            data={store}
                            key={"chart"}
                            options={store.chartTypeList}
                            propertyName={"chartType"}
                        />
                    </Item>
                </Col>
                <Col span={5}>
                    <Item
                        {...formItemLayout}
                        label={"Show Legend"}
                    >
                        <Select
                            data={store}
                            key={"legend"}
                            options={store.showLegendList}
                            propertyName={"showLegend"}
                        />
                    </Item>
                </Col>
                <Col span={5}>
                    <Item
                        {...formItemLayout}
                        label={"Show title"}
                    >
                        <Checkbox
                            data={store}
                            key={"legend"}
                            propertyName={"showTitle"}
                        />
                    </Item>
                </Col>
            </Row>
        </Form>
    );

});

export default AdHocChartConfigPanel;
