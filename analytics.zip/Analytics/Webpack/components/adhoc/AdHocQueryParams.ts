import { IYearPeriod } from "../../models/Types";

export class AdHocQueryParams {
    public periods: IYearPeriod[];
    public subjects: number[];
    public warehouse: number;
}
