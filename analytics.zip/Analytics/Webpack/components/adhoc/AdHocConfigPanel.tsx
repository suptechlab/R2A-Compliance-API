import "./adhoc.pcss";

import { Button, Card, Col, Form, Icon, Row } from "antd";
import { observer } from "mobx-react";
import React from "react";
import Cascader from "../../util/components/Cascader";
import MonthSelect from "../../util/components/MonthSelect";
import Select from "../../util/components/Select";

const { Item } = Form;

const formItemLayout = {
    labelCol: {
        xs: { span: 24 },
        sm: { span: 8 },
    },
    wrapperCol: {
        xs: { span: 24 },
        sm: { span: 16 },
    },
};

export interface IAdHocConfigPanelProps {
    store: any;
}

const AdHocConfigPanel = observer(({ store }) => {

    const handleFetchData = () => {
        store.fetchData();
    };

    return (
        <Card
            bordered={false}
            className={"adhoc-config-panel"}
            loading={store.loading}
        >
            <Form
            >
                <Row>
                    <Col span={5}>
                        <Item
                            {...formItemLayout}
                            label={"Period"}
                        >
                            <MonthSelect
                                data={store}
                                propertyName={"months"}
                            />
                        </Item>
                    </Col>
                    <Col span={5}>
                        <Item
                            {...formItemLayout}
                            label={"Subjects"}
                        >
                            <Select
                                allowClear
                                data={store}
                                key={"type"}
                                mode={"multiple"}
                                options={store.subjectsList}
                                propertyName={"subjects"}
                            />
                        </Item>
                    </Col>
                    <Col span={5}>
                        <Item
                            {...formItemLayout}
                            label={"Warehouse"}
                        >
                            <Select
                                allowClear
                                data={store}
                                key={"type"}
                                options={store.warehousesList}
                                propertyName={"warehouse"}
                            />
                        </Item>
                    </Col>
                    <Col span={5}>
                        <Item
                            {...formItemLayout}
                        >
                            <Button
                                className={"adhoc-config-panel__button"}
                                disabled={!store.isValid || store.loading}
                                onClick={handleFetchData}
                                type={"primary"}
                            >
                                <Icon type="dot-chart" />
                                {"Fetch data"}
                            </Button>
                        </Item>
                    </Col>
                </Row>
            </Form>
        </Card>
    );

});

export default AdHocConfigPanel;
