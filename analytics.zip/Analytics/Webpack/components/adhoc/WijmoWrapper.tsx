import "./adhoc.pcss";

import { Button, Card, Col, Row } from "antd";
import JSZip from "jszip/dist/jszip.min.js";
import { observer } from "mobx-react";
import React, { Component, Fragment } from "react";
import { FlexGridXlsxConverter } from "wijmo/wijmo.grid.xlsx";
import { LegendVisibility, PivotEngine } from "wijmo/wijmo.olap";
import { PivotChart, PivotGrid, PivotPanel } from "wijmo/wijmo.react.olap";
import { IAdHocStore } from "../../store/AdHocStore";
import AdHocChartConfigPanel from "./AdHocChartConfigPanel";


export interface IWijmoWrapperProps {
    store: IAdHocStore;
}

@observer
class WijmoWrapper extends Component<IWijmoWrapperProps> {
    private engine: PivotEngine;
    private pivotGrid: any;
    private pivotChart: any;

    constructor(props) {
        super(props);

        this.engine =
            new PivotEngine({
                autoGenerateFields: false,
                itemsSource: props.store.serviceUrl,
                showZeros: true,
            });

        this.props.store.initWijmoFields(this.engine);
    }

    public componentWillMount() {
        this.engine.viewDefinitionChanged.addHandler(() => {
            this.forceUpdate();
        });
    }


    public render() {
        return (
            <Fragment>
                <Card
                    bordered={false}
                    className={"adhoc-wijmo-panel"}
                    loading={this.props.store.loading}
                >
                    <Row>
                        <Col
                            span={7}
                            className={"adhoc-wijmo-panel__pivot-panel"}
                        >
                            <PivotPanel engine={this.engine} />
                            <Button
                                onClick={this.handleExport}
                                icon="file-excel"
                                type="primary"
                            >
                                {"Export xlsx"}
                            </Button>
                        </Col>
                        <Col span={16}>
                            <PivotGrid
                                itemsSource={this.engine}
                                initialized={this.initPivotGrid}
                            />
                        </Col>
                    </Row>
                </Card>
                <Card
                    bordered={false}
                    className={"adhoc-wijmo-panel-config__chart"}
                    loading={this.props.store.loading}
                >
                    <AdHocChartConfigPanel store={this.props.store} />
                </Card>
                <Card
                    bordered={false}
                    className={"adhoc-wijmo-panel__chart"}
                    loading={this.props.store.loading}
                >

                    <PivotChart
                        chartType={this.props.store.chartType}
                        showTitle={this.props.store.showTitle}
                        showLegend={LegendVisibility[this.props.store.showLegend]}
                        itemsSource={this.engine}
                        initialized={this.initPivotChart}
                    />
                </Card>
            </Fragment>
        );
    }

    private initPivotGrid = (s: any, e: any) => {
        this.pivotGrid = s;
    }

    private initPivotChart = (s: any, e: any) => {
        this.pivotChart = s;
    }

    private handleExport = (event: any) => {
        const name = this.pivotChart.flexChart.header ? this.pivotChart.flexChart.header : "Excel";
        FlexGridXlsxConverter.saveAsync(this.pivotGrid, {
            includeColumnHeaders: true,
            includeRowHeaders: true,
            includeCellStyles: false,
            sheetIndex: 0,
            sheetName: name,
        }, name);
    }
}

export default WijmoWrapper;
