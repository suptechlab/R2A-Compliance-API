import { List } from "antd";
import { observer } from "mobx-react";
import React, { Fragment, SFC } from "react";
import { IndicatorStore } from "../../store/IndicatorStore";
import Indicator from "./Indicator";

export interface IndicatorGroupListProps {
    store: IndicatorStore;
}

const IndicatorList = observer(({ store }) => {
    return (
        <div className={"indicator-list"}>
            {store.Indicators.map((indicator) => <Indicator key={indicator.id} indicator={indicator} />)}
        </div>
    );
});

export default IndicatorList;
