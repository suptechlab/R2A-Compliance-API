import "./indicator.pcss";

import { Alert, Card, List } from "antd";
import React, { SFC } from "react";
import IndicatorValue from "./IndicatorValue";


export interface IIndicatorProps {
    indicator: any;
}

const Indicator: SFC<IIndicatorProps> = ({ indicator }) => {

    const groups = (item) => <IndicatorValue value={item} />;

    return (
        <Card
            className={"indicator-group__card"}
            title={indicator.name}
        >
            <div>
                {indicator.isApplicable && <List
                    dataSource={indicator.values}
                    renderItem={groups}
                />}
                {!indicator.isApplicable && <span className={"indicator-group__card__NA"}>{"-- N/A --"}</span>}
            </div>
        </Card>
    );
};

export default Indicator;
