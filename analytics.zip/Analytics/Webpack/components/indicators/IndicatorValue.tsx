import { Card, List } from "antd";
import React, { SFC } from "react";


export interface IIndicatorValueProps {
    value: any;
}

const { Item } = List;
const { Meta } = Item;

const IndicatorValue: SFC<IIndicatorValueProps> = ({ value }) => {
    return (
        <Item>
            <Meta
                title={value.code}
            />
            <div>
                {value.formattedValue}
            </div>
        </Item>
    );
};

export default IndicatorValue;
