import "./indicator.pcss";

import { Button, Card, Col, Form, Icon, Row } from "antd";
import { observer } from "mobx-react";
import React from "react";
import { IndicatorStore } from "../../store/IndicatorStore";
import Cascader from "../../util/components/Cascader";
import Select from "../../util/components/Select";

const { Item } = Form;

const formItemLayout = {
    labelCol: {
        xs: { span: 24 },
        sm: { span: 8 },
    },
    wrapperCol: {
        xs: { span: 24 },
        sm: { span: 16 },
    },
};

export interface IndicatorConfigPanelProps {
    store: IndicatorStore;
}

const IndicatorConfigPanel = observer(({ store }) => {

    const handleFetchIndicators = () => {
        store.loadIndicators();
    };

    return (
        <Card
            bordered={false}
            className={"indicator-config-panel"}
        >
            <Form
            >
                <Row>
                    <Col span={5}>
                        <Item
                            {...formItemLayout}
                            label={"Period"}
                        >
                            <Cascader
                                allowClear
                                changeOnSelect
                                key={"year"}
                                data={store}
                                options={store.quarters}
                                propertyName={"yearQuarter"}
                            />
                        </Item>
                    </Col>
                    <Col span={5}>
                        <Item
                            {...formItemLayout}
                            label={"Subjects"}
                        >
                            <Select
                                allowClear
                                data={store}
                                key={"type"}
                                options={store.subjectsList}
                                propertyName={"subjects"}
                            />
                        </Item>
                    </Col>
                    <Col span={5}>
                        <Item
                            {...formItemLayout}
                        >
                            <Button
                                className={"indicator-config-panel__button"}
                                disabled={!store.isValid || store.loading}
                                onClick={handleFetchIndicators}
                                type={"primary"}
                            >
                                <Icon type="dot-chart" />
                                {"Fetch indicators"}
                            </Button>
                        </Item>
                    </Col>
                </Row>
            </Form>
        </Card>
    );

});

export default IndicatorConfigPanel;
