import { Select as AntSelect } from "antd";
import isArray from "lodash-es/isArray";
import isNil from "lodash-es/isNil";
import { action } from "mobx";
import { observer } from "mobx-react";
import React, { ReactNode } from "react";
import { Option } from "../dataTypes/Option";
import { OptionTree } from "../dataTypes/OptionTree";

const AntOption = AntSelect.Option;
const OptGroup = AntSelect.OptGroup;

interface ISelect {
    allowClear?: boolean;
    className?: string;
    data: any;
    defaultValue?: any;
    disabled?: boolean;
    filterOption?: ((value: any, option: any) => void) | boolean;
    grouped?: boolean;
    mode?: "multiple" | "tags" | "combobox" | "default";
    onBlur?: () => void;
    onChange?: (value: any) => void;
    options: Array<OptionTree<any, string>> | Array<Option<any, string>>;
    placeholder?: string;
    propertyName: string;
    showSearch?: boolean;
    tokenSeparators?: string[];
    labelInValue?: boolean;
}

@observer
class Select extends React.Component<ISelect, {}> {

    public static defaultProps: Partial<ISelect> = {
        allowClear: false,
        grouped: false,
        mode: "default",
        showSearch: false,
        labelInValue: false,
    };

    constructor(props: ISelect) {
        super(props);
    }

    public render() {
        let value;
        if (this.props.mode === "multiple") {
            value = isNil(this.props.data[this.props.propertyName]) ? null : this.props.data[this.props.propertyName].slice();
            if (value && this.props.labelInValue) {
                value = value.map((v: string) => ({ key: v }));
            }
        } else {
            value = isNil(this.props.data[this.props.propertyName]) ? null : this.props.data[this.props.propertyName];
            if (value && this.props.labelInValue) {
                value = { key: value };
            }
        }

        const selectOptions = this.initOptions(this.props.options, this.props.grouped);

        return (
            <AntSelect
                allowClear={this.props.allowClear}
                className={this.props.className}
                defaultValue={this.props.labelInValue ? { key: this.props.defaultValue } : this.props.defaultValue}
                disabled={this.props.disabled}
                filterOption={this.props.filterOption || this.filter}
                mode={this.props.mode}
                placeholder={this.props.placeholder}
                onBlur={this.props.onBlur}
                onChange={this.handleChange}
                showSearch={this.props.showSearch}
                labelInValue={this.props.labelInValue}
                value={value}
            >
                {selectOptions}
            </AntSelect>
        );
    }

    @action("handleChange")
    private handleChange = (newValue: any) => {
        if (this.props.onChange) {
            this.props.onChange(newValue);
        } else {
            if (isArray(newValue)) {
                this.props.data[this.props.propertyName].replace(newValue);
            } else {
                this.props.data[this.props.propertyName] = newValue;
            }
        }
    }


    private filter = (input: string, option: any) => {
        return option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0;
    }


    private initOptions(options: Array<OptionTree<any, string>> | Array<Option<any, string>>, grouped: boolean = false) {
        const children: ReactNode[] = [];

        if (!isNil(options)) {
            if (!grouped) {
                const op = options as Array<Option<any, string>>;
                if (op.length > 0) {
                    op.forEach((o: Option<string | number, string>) => {
                        children.push(
                            <AntOption key={o.id} value={o.id}>{o.text}</AntOption>,
                        );
                    });
                }
            } else {
                const opg = options as Array<OptionTree<any, string>>;
                opg.forEach((pg: OptionTree<string, string>) => {
                    const inner = pg.children as Array<OptionTree<string, string>>;
                    const ops: any = [];
                    if (inner) {
                        inner.forEach((u: Option<string, string> | OptionTree<string, string>) => {
                            ops.push(
                                <AntOption key={u.id + u.text} value={u.id}>{u.text}</AntOption>,
                            );
                        });
                    }

                    children.push(
                        <OptGroup key={pg.id + pg.text} label={pg.text}>
                            {ops}
                        </OptGroup>,
                    );
                });
            }
        }

        return children;
    }
}


export default Select;
