import "./monthSelect.pcss";

import { Button, DatePicker, Tag, Tooltip } from "antd";
import { action, observable } from "mobx";
import { observer } from "mobx-react";
import moment from "moment";
import React, { Fragment } from "react";
import ReactDOM from "react-dom";

interface IMonthSelect {
    data: any;
    propertyName: string;
}

@observer
export default class MonthSelect extends React.Component<IMonthSelect, any> {
    @observable private inputVisible: boolean;

    constructor(props: IMonthSelect) {
        super(props);
        this.inputVisible = false;
    }

    public render() {
        const monthPicker = (
            <DatePicker.MonthPicker
                onChange={this.handleOnChange}
                open
                style={{ marginTop: "6px" }}
            />
        );

        const transformedItems = this.transform(this.props.data[this.props.propertyName]);

        const tags = transformedItems.map((tag: any, index: number) => {
            const isLongTag = tag.text.length > 20;
            const tagElem = (
                // tslint:disable-next-line:jsx-no-lambda
                <Tag key={tag.value} className={"tag"} closable afterClose={() => this.handleOnCloseTag(tag.value)}>
                    {isLongTag ? `${tag.text.slice(0, 20)}...` : tag.text}
                </Tag>
            );
            return isLongTag ? <Tooltip title={tag.text}>{tagElem}</Tooltip> : tagElem;
        });


        return (
            <Fragment>
                <div className={"picker"} onClick={this.handleVisible} >
                    {tags}
                </div>
                {this.inputVisible && <div className={"overlay"} onClick={this.handleVisible} />}
                {this.inputVisible && monthPicker}
            </Fragment>
        );
    }

    @action
    private handleOnChange = (value: any) => {
        this.props.data.add(value);
    }

    @action
    private handleOnCloseTag = (value: any) => {
        this.props.data.remove(value);
    }

    @action
    private handleVisible = () => {
        this.inputVisible = !this.inputVisible;
    }

    @action
    private handleOnBlur = () => {
        this.inputVisible = false;
    }

    private transform = (value: any): Array<{ value: any, text: string }> => {
        if (value.length > 0) {
            return value.map((val: any) => {
                return { value: val, text: val.format("YYYY-MM") };
            });
        }
        return [];
    }
}
