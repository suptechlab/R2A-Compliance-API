import { Checkbox as AntCheckbox } from "antd";
import { action } from "mobx";
import { observer } from "mobx-react";
import React from "react";
import ReactDOM from "react-dom";


interface ICheckbox {
    data: any;
    defaultValue?: any;
    disabled?: boolean;
    propertyName: string;
}

const Checkbox = observer((props) => {

    const handleChange = action("handleCheckboxChange", (newValue: any) => {
        props.data[props.propertyName] = newValue.target.checked;
    });

    const value = props.data[props.propertyName];

    return (
        <AntCheckbox
            checked={value}
            defaultChecked={props.defaultValue}
            disabled={props.disabled}
            onChange={handleChange}
        />
    );
});

export default Checkbox;
