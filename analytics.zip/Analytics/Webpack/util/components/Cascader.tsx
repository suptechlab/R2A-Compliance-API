import {Cascader as AntCascader} from "antd";
import {CascaderOptionType} from "antd/lib/cascader";
import {action} from "mobx";
import {observer} from "mobx-react";
import React from "react";

interface ICascader {
    allowClear?: boolean | undefined;
    changeOnSelect?: boolean;
    className?: string;
    data: any;
    defaultValue?: any;
    disabled?: boolean;
    displayRender?: ((label: string[], selectedOptions?: CascaderOptionType[] | undefined)
        => React.ReactNode) | undefined;
    expandTrigger?: "click" | "hover" | undefined;
    options: CascaderOptionType[];
    placeholder?: string;
    propertyName: string;
    showSearch?: boolean;
    size?: "large" | "default" | "small";

}

const Cascader = observer<React.StatelessComponent<ICascader>>((props) => {

    const handleChange = action("handleCascaderChange", (newValue: any) => {
        props.data[props.propertyName] = newValue;
    });

    const value = props.data[props.propertyName].peek();

    return (
        <AntCascader
            allowClear={props.allowClear}
            changeOnSelect={props.changeOnSelect}
            className={props.className}
            defaultValue={props.defaultValue}
            disabled={props.disabled}
            displayRender={props.displayRender}
            expandTrigger={props.expandTrigger}
            options={props.options}
            onChange={handleChange}
            placeholder={props.placeholder}
            showSearch={props.showSearch}
            size={props.size}
            value={value}
        />
    );
});

Cascader.defaultProps = {
    allowClear: false,
    changeOnSelect: false,
    expandTrigger: "click",
    showSearch: false,
    size: "default",
};

export default Cascader;
