import isEmpty from "lodash-es/isEmpty";
import isNil from "lodash-es/isNil";
import {Option} from "./Option";

export class OptionTree<T, U> extends Option<T, U> {
    public children?: Array<Option<T, U>> | Array<OptionTree<T, U>>;

    constructor(key: T, value: U,
                children?: Array<Option<T, U>> | Array<OptionTree<T, U>>, disabled?: boolean) {
        super(key, value, disabled);
        this.children = children;
    }

    public get hasChildren(): boolean {
        return isNil(this.children) || isEmpty(this.children) ? false : true;
    }

}
