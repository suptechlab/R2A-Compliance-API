export class Option<T, U> {
    private k: T;
    private val: U;
    private disable: boolean;

    constructor(key: T, value: U, disabled: boolean = false) {
        this.k = key;
        this.val = value;
        this.disable = disabled;
    }

    public get label(): U {
        return this.val;
    }

    public get text(): U {
        return this.val;
    }

    public get title(): U {
        return this.val;
    }

    public get value(): T {
        return this.k;
    }

    public get id(): T {
        return this.k;
    }

    public get key(): T {
        return this.k;
    }

    public get disabled(): boolean {
        return this.disable;
    }

}
