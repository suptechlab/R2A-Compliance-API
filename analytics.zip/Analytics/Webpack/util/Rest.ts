import "jquery";

import isNil from "lodash-es/isNil";

export class Rest {

    public static delete(url: string, urlParams: object | undefined) {
        return new Promise((resolve, reject) => {
            const that = this;
            $.ajax({
                async: true,
                crossDomain: true,
                dataType: "json",
                method: "DELETE",
                headers: {
                    "X-Ajax": "true",
                },
                url: this.buildUrl(url, urlParams),
            })
                .done((response, textStatus, jqXHR) => {
                    resolve(response);
                })
                .fail((jqXHR) => {
                    reject(jqXHR);
                });
        });
    }

    public static async put(url: string, data: any, urlParams?: object | undefined) {
        return new Promise((resolve, reject) => {
            $.ajax({
                async: true,
                contentType: "application/json; charset=utf-8",
                crossDomain: true,
                data: JSON.stringify(data),
                dataType: "json",
                method: "PUT",
                headers: {
                    "X-Ajax": "true",
                },
                url: this.buildUrl(url, urlParams),
            })
                .done((response, textStatus, jqXHR) => {
                    resolve(response);
                })
                .fail((jqXHR) => {
                    reject(jqXHR);
                });
        });
    }

    public static async post(
        url: string, data: any,
        dataType?: "xml" | "json" | "script" | "text" | "html",
        urlParams?: object | undefined) {
        return new Promise((resolve, reject) => {
            $.ajax({
                async: true,
                contentType: "application/json; charset=utf-8",
                crossDomain: true,
                data: JSON.stringify(data),
                dataType: isNil(dataType) ? "json" : dataType,
                method: "POST",
                headers: {
                    "X-Ajax": "true",
                },
                url: this.buildUrl(url, urlParams),
            })
                .done((response, textStatus, jqXHR) => {
                    resolve(response);
                })
                .fail((jqXHR) => {
                    reject(jqXHR);
                });
        });
    }

    public static async postMultiPart(url: string, data: any, urlParams?: object) {
        return new Promise((resolve, reject) => {
            $.ajax({
                async: true,
                cache: false,
                contentType: false,
                crossDomain: false,
                data,
                method: "POST",
                headers: {
                    "X-Ajax": "true",
                },
                processData: false,
                url: this.buildUrl(url, urlParams),
            })
                .done((response, textStatus, jqXHR) => {
                    resolve(response);
                })
                .fail((jqXHR) => {
                    reject(jqXHR);
                });
        });
    }

    public static async get(url: string, data?: any, urlParams?: object | undefined, traditional: boolean = true) {
        return new Promise((resolve, reject) => {
            $.ajax({
                async: true,
                crossDomain: true,
                data,
                dataType: "json",
                method: "GET",
                headers: {
                    "X-Ajax": "true",
                },
                traditional: traditional === true,
                url: this.buildUrl(url, urlParams),
            })
                .done((response, textStatus, jqXHR) => {
                    resolve(response);
                })
                .fail((jqXHR) => {
                    reject(jqXHR);
                });
        });
    }

    private static buildUrl(url: string, urlParams: object | undefined) {
        if (isNil(urlParams)) {
            return url;
        } else {
            let params = "";
            for (const prop in urlParams) {
                if (urlParams.hasOwnProperty(prop)) {
                    params = params + "&" +
                        encodeURIComponent(prop) + "=" + encodeURIComponent((urlParams as any)[prop]);
                }
            }

            if (params.length > 0) {
                if (url.indexOf("?") < 0) {
                    params = "?" + params.substring(1);
                }
            }
            return url + params;

        }
    }
}
