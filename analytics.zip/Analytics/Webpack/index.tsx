import MainContainer from "./containers/MainContainer";

export {
    MainContainer,
};
