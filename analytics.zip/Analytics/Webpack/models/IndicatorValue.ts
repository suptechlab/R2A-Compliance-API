import isNil from "lodash-es/isNil";
import isNumber from "lodash-es/isNumber";
import numeral from "numeral";
import { IIndicatorValue } from "./Types";


class IndicatorValue implements IIndicatorValue {
    public code: string;
    public value: any;

    private formattingType: number;
    private decimalPlaces: number;
    private currency: string;
    private type: string;

    private format: string;

    constructor(code, value, formattingType, decimalPlaces, currency?, type = "number") {
        this.code = code;
        this.value = value;

        this.formattingType = formattingType ? formattingType : 0;
        this.decimalPlaces = decimalPlaces ? decimalPlaces : 0;
        this.currency = currency ? currency : "$";
        this.type = type ? type : "number";

        this.setFormat();
    }

    get formattedValue() {
        if (!isNil(this.value) && isNumber(this.value)) {
            return numeral(this.value).format(this.format);
        }

        return "N/A";
    }

    private setFormat = () => {
        this.format = "0,0";

        if (this.decimalPlaces > 0) {
            this.format = `${this.format}.${"0".repeat(this.decimalPlaces)}`;
        }

        switch (this.formattingType) {
            case 1:
                this.format = `${this.format}%`;
                break;
            case 2:
                this.format = `${this.currency}${this.format}`;
                break;
        }
    }
}

export default IndicatorValue;
