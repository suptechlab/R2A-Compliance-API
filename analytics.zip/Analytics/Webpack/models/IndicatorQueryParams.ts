import { IIndicatorQueryParams } from "./Types";


export class IndicatorQueryParams implements IIndicatorQueryParams {
    public year: number;
    public quarter?: number;
    public subjectId?: number;
}
