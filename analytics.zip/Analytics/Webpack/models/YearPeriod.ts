import { IYearPeriod } from "./Types";

export class YearPeriod implements IYearPeriod {
    public year: number;
    public period?: number | undefined;

    constructor(year, period?) {
        this.year = year;
        this.period = period ? period : undefined;
    }
}
