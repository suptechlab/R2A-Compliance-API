import { Indicator } from "./Indicator";
import { IIndicator, IIndicatorGroup } from "./Types";

export class IndicatorGroup implements IIndicatorGroup {
    public id: number;
    public code: string;
    public name: string;
    public ordinal: number;
    public isApplicable: boolean;
    public indicators: IIndicator[];

    constructor(data) {
        this.id = data.id;
        this.code = data.code;
        this.name = data.name;
        this.ordinal = data.ordinal;
        this.isApplicable = data.isApplicable ? data.isApplicable : true;
        this.indicators = [];

        this.parseIndicators(data.indicators);
    }

    private parseIndicators = (indicators) => {
        if (indicators) {
            this.indicators = indicators.map((value) => new Indicator(value));
        } else {
            this.isApplicable = false;
        }
    }
}
