export interface IIndicatorGroup {
    id: number;
    code: string;
    name: string;
    ordinal: number;
    isApplicable: boolean;
    indicators: IIndicator[];
}

export interface IIndicator {
    id: number;
    code: string;
    name: string;
    isApplicable: boolean;
    ordinal: number;
    decimalPlaces: number;
    formatingType: number;
    aggregationType: number;
    currencySign?: string;
    description?: string;
    values: IIndicatorValue[];
}

export interface IIndicatorValue {
    code: string;
    value: number | string | boolean;
}

export interface IIndicatorQueryParams {
    year: number;
    quarter?: number;
    subjectId?: number;
}

export interface IYearPeriod {
    year: number;
    period?: number;
}
