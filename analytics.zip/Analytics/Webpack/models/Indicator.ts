import IndicatorValue from "./IndicatorValue";
import { IIndicator, IIndicatorValue } from "./Types";

export class Indicator implements IIndicator {
    public id: number;
    public code: string;
    public name: string;
    public isApplicable: boolean;
    public ordinal: number;
    public decimalPlaces: number;
    public formatingType: number;
    public aggregationType: number;
    public currencySign?: string | undefined;
    public description?: string | undefined;
    public values: IIndicatorValue[];

    constructor(data) {
        this.id = data.id;
        this.code = data.code;
        this.name = data.name;
        this.isApplicable = data.isApplicable ? data.isApplicable : false;
        this.ordinal = data.ordinal;
        this.description = data.description;
        this.values = [];

        this.parseIndicatorValues(data.values, data.decimalPlaces, data.formattingType, data.currencySign);
    }

    private parseIndicatorValues = (values, decimalPlaces, formattingType, currencySign) => {
        if (values) {
            this.values = values.map((value) => new IndicatorValue(value.reportCode, value.value, formattingType, decimalPlaces, currencySign));
        } else {
            this.isApplicable = false;
        }
    }
}
