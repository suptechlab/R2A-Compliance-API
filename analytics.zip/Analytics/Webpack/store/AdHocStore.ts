import { message } from "antd";
import includes from "lodash-es/includes";
import isEmpty from "lodash-es/isEmpty";
import isNil from "lodash-es/isNil";
import { action, computed, IObservableArray, observable } from "mobx";
import moment from "moment";
import { PivotEngine, PivotField } from "wijmo/wijmo.olap";
import { AdHocQueryParams } from "../components/adhoc/AdHocQueryParams";
import { YearPeriod } from "../models/YearPeriod";
import { Option } from "../util/dataTypes/Option";
import { Rest } from "../util/Rest";

export interface IAdHocStore {
    subjectsList: Array<Option<string, string>>;
    warehousesList: Array<Option<string, string>>;
    chartTypeList: Array<Option<number, string>>;
    showLegendList: Array<Option<number, string>>;

    months: IObservableArray<moment.Moment>;
    subjects: string[];
    warehouse: string | null;

    wijmoActive: boolean;
    loading: boolean;
    serviceUrl: string;
    isValid: boolean;
    chartType: number;
    showTitle: boolean;
    showLegend: number;

    fetchData: () => void;
    initWijmoFields: (engine: PivotEngine) => void;
}

class AdHocStore implements IAdHocStore {
    public chartTypeList: Array<Option<number, string>>;
    public showLegendList: Array<Option<number, string>>;
    @observable public chartType: number;
    @observable public showTitle: boolean;
    @observable public showLegend: number;
    public serviceUrl: string;

    @observable public loading: boolean;
    @observable public wijmoActive: boolean;

    @observable public subjectsList: Array<Option<string, string>>;
    @observable public warehousesList: Array<Option<string, string>>;

    @observable public subjects: string[];
    @observable public warehouse: string | null;

    @observable public months: IObservableArray<moment.Moment>;

    private wijmoFields: any;


    constructor() {
        this.wijmoFields = "";
        this.serviceUrl = "";
        this.wijmoActive = false;

        this.chartType = 0;
        this.showLegend = 0;
        this.showTitle = true;

        this.subjectsList = [];
        this.warehousesList = [];
        this.months = observable.array<moment.Moment>();
        this.subjects = [];
        this.warehouse = null;

        this.fetchSubjects();
        this.fetchWarehouses();

        this.initChartTypeList();
        this.initLegendType();
    }

    @action
    public add(value: moment.Moment): void {
        if (!this.months.some((x) => x.isSame(value, "date"))) {
            this.months.push(value);
        }
    }

    @action
    public remove(value: moment.Moment): void {
        this.months.remove(value);
    }

    @computed public get isValid() {
        return !(isNil(this.months) || this.months.length < 1) &&
            !(isNil(this.warehouse));
    }

    @action
    public fetchData(): void {
        this.loading = true;
        this.wijmoActive = false;
        Rest.post("/api/reports/data", this.exportData(), "text")
            .then(action((data: string) => {
                const d = JSON.parse(data);
                this.setServiceUrl(d.dataUrl);
                this.wijmoFields = d.fields;
                this.loading = false;
                this.wijmoActive = true;
            }))
            .catch((error) => {
                this.wijmoActive = false;
                this.error(`Fetching data: ${error.status} - ${error.statusText}`);
            });
    }

    @action
    public initWijmoFields(engine: PivotEngine): void {
        this.loading = true;

        if (!isNil(this.wijmoFields)) {
            engine.fields.beginUpdate();
            this.wijmoFields.forEach((field: any, index: number) => {
                const f = new PivotField(engine, field.fieldBinding, field.fieldName);
                f.aggregate = field.aggregateType;
                f.dataType = field.dataType;
                f.showAs = 0;
                if (!isNil(field.fieldFormat)) {
                    f.format = field.fieldFormat;
                }

                if (!isNil(field.uniqueValues) && field.uniqueValues.length > 0) {
                    f.filter.filterType = 3;
                    f.filter.valueFilter.uniqueValues = field.uniqueValues;
                    if (f.filter.valueFilter.maxValues < f.filter.valueFilter.uniqueValues.length) {
                        f.filter.valueFilter.maxValues = f.filter.valueFilter.uniqueValues.length;
                    }
                }

                engine.fields.insert(index, f);
            });

            this.wijmoFields.forEach((field: any, index: number) => {
                if (!isNil(field.weightField)) {
                    const found = engine.fields.getField(field.fieldBinding);
                    const weightField = engine.fields.getField(field.weightField);

                    if (!isNil(found) && !isNil(weightField)) {
                        found.weightField = weightField;
                    }
                }
            });

            engine.fields.endUpdate();
        }

        this.loading = false;
    }

    @action
    private error(error: any): void {
        this.loading = false;
        message.error(error);
    }

    private setServiceUrl(serviceUrl: string) {
        this.serviceUrl = serviceUrl;
    }

    private exportData = () => {
        const data = new AdHocQueryParams();
        if (this.isValid) {
            data.periods = this.months.map((x) => new YearPeriod(x.year(), (x.month() + 1)));
            data.subjects = this.subjects.map((x) => Number(x));
            data.warehouse = Number(this.warehouse);
        }

        return data;
    }

    @action
    private fetchSubjects = () => {
        this.loading = true;
        Rest.get("/api/subjects")
            .then((data: any) => {
                this.subjectsList = data.map((item) => new Option(item.id, item.name));
                this.loading = false;
            })
            .catch((error) => {
                this.error(`Fetching subjects: ${error.status} - ${error.statusText}`);
            });
    }

    @action
    private fetchWarehouses = () => {
        this.loading = true;
        this.warehousesList = [];
        Rest.get("/api/warehouses")
            .then((data: any) => {
                this.warehousesList = data.map((item) => new Option(item.id, item.name));
                this.warehousesList.push(new Option("0", "Indicators"));
                this.loading = false;
            })
            .catch((error) => {
                this.error(`Fetching warehouses: ${error.status} - ${error.statusText}`);
            });
    }

    @action
    private initLegendType = () => {
        this.showLegendList = [];

        this.showLegendList.push(new Option(0, "Always"), new Option(1, "Never"), new Option(2, "Auto"));
    }

    @action
    private initChartTypeList = () => {
        this.chartTypeList = [];

        this.chartTypeList.push(
            new Option(0, "Column"),
            new Option(1, "Bar"),
            new Option(2, "Scatter"),
            new Option(3, "Line"),
            new Option(4, "Area"),
            new Option(5, "Pie"),
        );
    }
}

export default AdHocStore;
