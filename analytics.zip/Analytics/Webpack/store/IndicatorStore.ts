import { message } from "antd";
import { isEmpty, isNil } from "lodash-es";
import { action, computed, observable } from "mobx";
import { Indicator } from "../models/Indicator";
import { IndicatorGroup } from "../models/IndicatorGroup";
import { IndicatorQueryParams } from "../models/IndicatorQueryParams";
import { IIndicator, IIndicatorGroup, IIndicatorQueryParams } from "../models/Types";
import { Option } from "../util/dataTypes/Option";
import { OptionTree } from "../util/dataTypes/OptionTree";
import { Rest } from "../util/Rest";


const quartersArray: Array<Option<string, string>> = [
    new Option<string, string>("1", "Q1"),
    new Option<string, string>("2", "Q2"),
    new Option<string, string>("3", "Q3"),
    new Option<string, string>("4", "Q4"),
];


export class IndicatorStore {
    @observable public loading: boolean;
    @observable public quarters: Array<OptionTree<string, string>>;
    @observable public subjectsList: Array<Option<string, string>>;

    @observable public yearQuarter: [string, string];
    @observable public subjects: string;

    @observable private indicators: IIndicator[];
    private indicatorType: string;

    constructor(type) {
        this.indicators = [];
        this.loading = false;

        this.yearQuarter = ["", ""];
        this.subjects = "";
        this.indicatorType = type ? type : "BANK";

        this.quarters = [];
        this.subjectsList = [];

        this.initQuarters();
        this.fetchSubjects();
    }

    @computed get Indicators() {
        return this.indicators;
    }

    @computed public get isValid() {
        return !(isNil(this.yearQuarter) || this.yearQuarter.length < 1) &&
            !(isNil(this.subjects) || this.subjects.length < 1);
    }

    public loadIndicators() {
        if (this.isValid) {
            this.loading = true;
            Rest.post("/api/indicators/get?type=" + this.indicatorType, this.exportData(), "json")
                .then(action((data: IIndicator[] ) => {
                    this.parseIndicators(data);
                    this.loading = false;
                }))
                .catch((error) => {
                    this.error(error);
                });
        } else {
            message.error("Couldn't fetch indicators. Data is not valid");
        }
    }

    @action
    private parseIndicators(data: IIndicator[]): void {
        if (!isNil(data) && !isEmpty(data)) {
            this.indicators = data.map((d) => new Indicator(d));
        }
    }

    @action
    private initQuarters() {
        this.loading = true;

        for (let i = 2012; i < 2100; i++) {
            this.quarters.push(new OptionTree(i.toString(), i.toString(), quartersArray));
        }
        this.loading = false;
    }

    @action
    private fetchSubjects = () => {
        this.loading = true;
        Rest.get("/api/subjects")
            .then((data: any) => {
                this.subjectsList = data.map((item) => new Option(item.id, item.name));
                this.loading = false;
            })
            .catch((error) => {
                this.error(`Fetching subjects: ${error.status} - ${error.statusText}`);
            });
    }

    private exportData = () => {
        const data = new IndicatorQueryParams();
        if (this.isValid) {
            data.year = Number(this.yearQuarter[0]);

            if (!isNil(this.subjects)) {
                data.subjectId = Number(this.subjects);
            }

            if (!isNil(this.yearQuarter[1]) && !isEmpty(this.yearQuarter[1])) {
                data.quarter = Number(this.yearQuarter[1]);
            }
        }

        return data;
    }

    @action
    private error(error: any): void {
        message.error(error);
        this.loading = false;
    }
}
