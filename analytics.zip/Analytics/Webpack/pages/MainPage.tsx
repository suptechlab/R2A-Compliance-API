import { Layout } from "antd";
import React from "react";
import ReactDOM from "react-dom";


import ErrorBoundary from "../components/error/ErrorBoundary";
import MainContainer from "../containers/MainContainer";

ReactDOM.render(
    <ErrorBoundary>
        <MainContainer />
    </ErrorBoundary>,
    document.getElementById("react"),
);

