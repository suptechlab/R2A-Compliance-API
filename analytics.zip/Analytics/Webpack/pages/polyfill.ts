import "babel-polyfill";
import "script-loader!../../node_modules/jszip/dist/jszip.min.js";
