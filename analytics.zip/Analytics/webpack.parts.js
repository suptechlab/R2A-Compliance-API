const path = require('path');
const fs = require('fs');

exports.loadResolver = () => ({
    resolve: {
        extensions: ['.js', '.ts', '.tsx']
    },
    plugins: [
        new webpack.ProvidePlugin({
            $: "jquery",
            jQuery: "jquery",
            jszip: "jszip/dist/jszip.min.js",
            JSZip: "jszip/dist/jszip.min.js",
            "node-zip": "jszip/dist/jszip.min.js",
        })
    ]
});

exports.lintJavaScript = ({ include, exclude, options } = {}) => {
    return {
        module: {
            rules: [
                {
                    enforce: 'pre',
                    test: /\.(js|jsx)$/,
                    include,
                    exclude,

                    loader: 'eslint-loader?{fix:true}',
                    options
                }
            ]
        }
    }
};

exports.loadJavaScript = ({ include, exclude } = {}) => ({
    module: {
        rules: [
            {
                test: /\.(js|jsx)$/,
                include,
                exclude,
                use: 'babel-loader'
            }
        ]
    }
});

exports.lintTypeScript = ({ include, exclude, options } = {}) => {
    return {
        module: {
            rules: [
                {
                    enforce: 'pre',
                    test: /\.(ts|tsx)$/,
                    include,
                    exclude,

                    loader: 'tslint-loader',
                    options
                }
            ]
        }
    }
};

exports.loadTypeScript = ({ include, exclude } = {}) => {
    return {
        module: {
            rules: [
                {
                    test: /\.(ts|tsx)$/,
                    include,
                    exclude,

                    use: [
                        {
                            loader: 'babel-loader',
                            options: {
                                cacheDirectory: true
                            }
                        },
                        {
                            loader: 'ts-loader'
                        }
                    ]
                }
            ]
        }
    };
};

const HtmlWebPackPlugin = require('html-webpack-plugin');
exports.loadHtml = ({ include, exclude } = {}) => ({
    module: {
        rules: [
            {
                test: /\.html$/,
                include,
                exclude,
                use: [
                    {
                        loader: 'html-loader',
                        options: { minimize: true }
                    }
                ]
            }
        ]
    },
    plugins: [
        new HtmlWebPackPlugin({
            template: './Webpack/index.html',
            filename: './index.html'
        })
    ]
});

exports.devServer = ({ host, port } = {}) => ({
    devServer: {
        stats: 'errors-only',
        host, // Defaults to `localhost`
        port, // Defaults to 8080
        open: true,
        overlay: false,
        historyApiFallback: true,
        inline: true,
        publicPath: "/"
    },
    plugins: [
        new webpack.HotModuleReplacementPlugin(),
    ]
});

const MiniCssExtractPlugin = require('mini-css-extract-plugin');
exports.loadProdCss = ({ include, exclude } = {}) => ({
    module: {
        rules: [
            {
                test: /\.(css|scss)$/,
                include,
                exclude,
                use: [
                    'style-loader',
                    MiniCssExtractPlugin.loader,
                    {
                        loader: 'css-loader',
                        options: {
                            minimize: true
                        }
                    },
                    'sass-loader'
                ]
            }
        ]
    },
    plugins: [
        new MiniCssExtractPlugin({
            filename: '[name].[contenthash:4].css',
            chunkFilename: '[id].css'
        })
    ]
});

exports.loadDevCss = ({ include, exclude, options } = {}) => ({
    module: {
        rules: [
            {
                test: /\.scss$/,
                include,
                exclude,
                use: [
                    'style-loader',
                    {
                        loader: 'css-loader',
                        options
                    },
                    'sass-loader'
                ]
            }
        ]
    }
});

// const lessToJs = require('less-vars-to-js');
// const themeVariables = lessToJs(fs.readFileSync(path.join(__dirname, './ant-theme-vars.less'), 'utf8'));
// exports.loadAntD = ({ include, exclude } = {}) => ({
//     module: {
//         rules: [
//             {
//                 test: /\.less$/,
//                 include,
//                 exclude,
//                 use: [
//                     'style-loader',
//                     'css-loader',
//                     {
//                         loader: 'less-loader',
//                         options: {
//                             modifyVars: themeVariables,
//                             javascriptEnabled: true
//                         }
//                     }

//                 ]
//             }
//         ]
//     }
// });

exports.loadLess = ({ include, exclude } = {}) => {
    return {
        module: {
            rules: [
                {
                    test: /\.less$/,
                    include,
                    exclude,
                    use: ['style-loader', 'css-loader',
                        {
                            loader: 'less-loader',
                            options: {
                                javascriptEnabled: true
                            }
                        }]
                }
            ]
        }
    };
};

exports.loadPostCSS = ({ include, exclude } = {}) => {
    return {
        module: {
            rules: [
                {
                    test: /\.(pcss|css)$/,
                    include,
                    exclude,
                    use: [
                        "style-loader",
                        "css-loader",
                        {
                            loader: "postcss-loader",
                            options: {
                                plugins: () => ([
                                    require("autoprefixer"),
                                    require("precss"),
                                ]),
                            },
                        },
                    ],
                }
            ]
        }
    };
};

const PurifyCSSPlugin = require('purifycss-webpack');

exports.purifyCSS = ({ paths }) => ({
    plugins: [new PurifyCSSPlugin({ paths })]
});

// url-loader is a good starting point and it's the perfect option for development purposes, as you don't have to care about the size of the resulting bundle. It comes with a limit option that can be used to defer image generation to file-loader after an absolute limit is reached. This way you can inline small files to your JavaScript bundles while generating sarate files for the bigger ones.
exports.loadImages = ({ include, exclude, options } = {}) => ({
    module: {
        rules: [
            {
                test: /\.(png|jpg|jpeg|gif|eot|ttf|woff2)$/,
                include,
                exclude,
                use: {
                    loader: 'url-loader',
                    options
                }
            }
        ]
    }
});


exports.loadIcos = ({ include, exclude } = {}) => ({
    module: {
        rules: [
            {
                test: /\.ico$/,
                include,
                exclude,
                use: {
                    loader: 'file-loader?name=[name].[ext]'
                }
            }
        ]
    }
});

exports.loadMds = ({ include, exclude } = {}) => ({
    module: {
        rules: [
            {
                test: /\.md$/,
                include,
                exclude,
                use: 'raw-loader'
            }
        ]
    }
});

exports.loadSvgs = ({ include, exclude } = {}) => ({
    module: {
        rules: [
            {
                test: /\.svg$/,
                include,
                exclude,
                use: [
                    'babel-loader',
                    {
                        loader: 'react-svg-loader',
                        options: {
                            svgo: {
                                plugins: [{ cleanupIDs: false }],
                                floatPrecision: 2
                            }
                        }
                    }
                ]
            }
        ]
    }
});

exports.generateSourceMaps = type => ({
    devtool: type,
});


const CleanWebpackPlugin = require('clean-webpack-plugin');
exports.clean = path => ({
    plugins: [new CleanWebpackPlugin([path])]
});

const UglifyWebpackPlugin = require('uglifyjs-webpack-plugin');
exports.minifyJavaScript = () => ({
    optimization: {
        minimizer: [new UglifyWebpackPlugin({ sourceMap: true, extractComments: true })]
    }
});


const OptimizeCSSAssetsPlugin = require('optimize-css-assets-webpack-plugin');
const cssnano = require('cssnano');
exports.minifyCSS = ({ options }) => ({
    plugins: [
        new OptimizeCSSAssetsPlugin({
            cssProcessor: cssnano,
            cssProcessorOptions: options,
            canPrint: false
        })
    ]
});


const webpack = require('webpack');

exports.setFreeVariable = (key, value) => {
    const env = {};
    env[key] = JSON.stringify(value);

    return {
        plugins: [new webpack.DefinePlugin(env)]
    };
};

exports.setEnvVariables = obj => {
    return {
        plugins: [new webpack.DefinePlugin(obj)]
    };
};


exports.setNoErrors = () => {
    return new webpack.NoEmitOnErrorsPlugin();
};

const CompressionPlugin = require('compression-webpack-plugin');
exports.setCompression = () => {
    return {
        plugins: [new CompressionPlugin()]
    };
};

const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;
exports.setAnalyzer = () => {
    return {
        plugins: [new BundleAnalyzerPlugin()]
    };
};


exports.setHashModuleIds = () => {
    return {
        plugins: [new webpack.HashedModuleIdsPlugin({
            hashFunction: 'sha256',
            hashDigest: 'hex',
            hashDigestLength: 20
        })]
    };
};

exports.generateIndexHtml = options => {
    return {
        plugins: [
            new HtmlWebPackPlugin(options)
        ]
    }
};