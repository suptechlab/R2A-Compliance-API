import * as React from "react";
import * as  ReactDOM from "react-dom";
import App from "./app";


const rootEl = document.getElementById("app");

ReactDOM.render(
    <App />,
    rootEl,
);


interface IRequireImport {
    default: any;
}

if ((module as any).hot) {
    (module as any).hot.accept("./app", () => ReactDOM.render(
        <App />,
        rootEl,
    ));
}
