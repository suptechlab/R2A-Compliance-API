import * as React from "react";
import * as  ReactDOM from "react-dom";
import * as testData from "./test.json";

import MainContainer from "../Webpack/containers/MainContainer";

export default class App extends React.Component<any, any> {

    constructor(props) {
        super(props);
    }

    public render() {
        return (
            <div>
                <MainContainer testData={testData}/>
            </div>
        );
    }
}
if (process.env.DEV === "true") {
    ReactDOM.render(<App />, document.getElementById("app"));
}

