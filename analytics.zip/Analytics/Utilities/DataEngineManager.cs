﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using C1.DataEngine;
using C1.Web.Api.DataEngine.Data;
using Microsoft.AspNetCore.Builder;

namespace Analytics.Utilities
{
    public class DataEngineManager : IDataEngineManager, IDisposable
    {
        private FlexPivotEngineProviderManager _providerManager;
        private Dictionary<string,Workspace> _workspaces;
        private string _workspaceFolder;

        public void Setup(IApplicationBuilder app, string workspaceFolder)
        {
            _providerManager = app.UseDataEngineProviders();
            _workspaceFolder = workspaceFolder;
            _workspaces = new Dictionary<string,Workspace>();
        }

        public bool Contains(string key)
        {
            return _providerManager.Contains(key);
        }

        private string GenerateUniqueWorkspaceFolder()
        {
            return Path.GetFullPath($@"{_workspaceFolder}\Workspace_{Guid.NewGuid()}");
        }

        public bool AddDataEngine(string name, DataTable data)
        {
            if (Contains(name))
            {
                Remove(name);
            }

            string workspacePath = GenerateUniqueWorkspaceFolder();

            var ws = new Workspace();
            _workspaces[name] = ws;
            ws.Init(workspacePath);
            //ws.KeepFiles = KeepFileType.IndexAndJoin;
            DbConnector.GetData(ws, data, name);
            ws.Save();
            ws.Dispose();


            _providerManager.AddDataEngine(name, workspacePath, name);
           
            return true;
        }

        public bool Remove(string key)
        {
            if (!Contains(key))
                return true;

            _providerManager.Remove(key);
            var ws = _workspaces[key];
            ws.KeepFiles = KeepFileType.None;
            ws.Clear();
            ws.Dispose();
            _workspaces.Remove(key);
            
            return !Contains(key);
        }

        public string GetOlapUrl(string key)
        {/*
            if (!Verify(key))
                return null;*/
            return $"~/api/dataengine/{key}";
        }

        public void Dispose()
        {
            foreach (var dataEngineName in _providerManager.Items.Keys.ToList())
            {
                Remove(dataEngineName);
            }
            _providerManager = null;
        }
    }

    public interface IDataEngineManager
    {
        void Setup(IApplicationBuilder app, string workspaceFolder);

        bool Contains(string key);
        bool AddDataEngine(string name, DataTable data);
        bool Remove(string key);

        string GetOlapUrl(string key);
    }

    public class DataEngineManagerExcetpion : Exception
    {
        public DataEngineManagerExcetpion() : base("An uknown error has occured.") { }
        public DataEngineManagerExcetpion(string message) : base(message) { }
        public DataEngineManagerExcetpion(string message, Exception exception) : base(message, exception) { }
    }
}
