﻿using System;
using System.Collections.Generic;
using System.Linq;
using NeoSmart.Hashing.XXHash;
using NeoSmart.Hashing.XXHash.Core;

namespace Analytics.Utilities.Misc
{
    public static class Hash
    {
        public static byte[] GetLEBytes(int value)
        {
            var b = new byte[4];
            b[0] = (byte) (value & 0xFF);
            b[1] = (byte) ((value >> 8) & 0xFF);
            b[2] = (byte) ((value >> 16) & 0xFF);
            b[3] = (byte) ((value >> 24) & 0xFF);
            return b;
        }


        public static long GetHash(List<int> values)
        {
            var state64 = XXHash.CreateState64(0L);
            XXHash.UpdateState64(state64, values.OrderBy(o => o).SelectMany(GetLEBytes).ToArray());
            return (long) XXHash.DigestState64(state64);
        }
    }
}