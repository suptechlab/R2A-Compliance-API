﻿using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Analytics.Indicators.Models;
using Analytics.Utilities.Indicators.Entities;

namespace Analytics.Utilities.Indicators
{
    public class IndicatorQuery
    {
        public static IndicatorQueryResult Query(IndicatorQueryParams queryParams, SqlConnection sqlConnection)
        {
            return Query(queryParams, sqlConnection, null);
        }

        public static IndicatorQueryResult Query(IndicatorQueryParams queryParams, SqlConnection sqlConnection,
            SqlTransaction sqlTransaction)
        {
            Dictionary<int, IndicatorQueryResult.ResultIndicator> indicatorMap;
            var indicatorQueryResult =
                PrepareIndicatorQueryResult(queryParams.SubCode, queryParams.Quarter.HasValue ? "K" : "G",
                    queryParams.ReportCode, sqlConnection, sqlTransaction, out indicatorMap);
            BuildAndExecuteQuery(indicatorQueryResult, queryParams.SubCode, queryParams.Year, queryParams.Quarter,
                queryParams.SubjectGroupId, queryParams.SubjectId, null, sqlConnection, sqlTransaction);

            return indicatorQueryResult;
        }

        public static IndicatorQueryResult Query(InstanceInfo instanceInfo, SqlConnection sqlConnection)
        {
            return Query(instanceInfo, sqlConnection, null);
        }


        public static IndicatorQueryResult Query(InstanceInfo instanceInfo, SqlConnection sqlConnection,
            SqlTransaction sqlTransaction)
        {
            Dictionary<int, IndicatorQueryResult.ResultIndicator> indicatorMap;

            if (instanceInfo == null)
            {
                return null;
            } 
            
            var indicatorQueryResult =
                PrepareIndicatorQueryResult(null, instanceInfo.Report.ReportPeriodType.Code, instanceInfo.Report.Code, sqlConnection, sqlTransaction, out indicatorMap);
            BuildAndExecuteQuery(indicatorQueryResult, null, null, null,
                null, null, instanceInfo.Id, sqlConnection, sqlTransaction);

            return indicatorQueryResult;
        }

        private static void BuildAndExecuteQuery(IndicatorQueryResult indicatorQueryResult, string subType, int? year,
            int? quarter, int? subjectGroupId, int? subjectId,
            int? instanceId,
            SqlConnection sqlConnection,
            SqlTransaction sqlTransaction)
        {
            var sqlIndicatorValues = new StringBuilder()
                .Append(
                    "SELECT iv.[indicatorId], r.[Code], iv.[numerator], iv.[denominator], iv.[value] ")
                .Append("FROM [data_whs].[indicator_value] AS iv ")
                .Append("INNER JOIN [dbo].[SubmittedReport] AS i ON iv.[instanceId] = i.[Id] ")
                .Append("INNER JOIN [dbo].[Report] AS r ON r.[Id] = i.[ReportId] ")
                .Append("WHERE iv.[status] = 1 ")
                .Append("AND iv.[numerator] IS NOT NULL ")
                .Append("AND iv.[denominator] IS NOT NULL ")
                .Append("AND iv.[isDefault] = 1 ");

            var sqlParameters = new List<SqlParameter>();
            if (!string.IsNullOrWhiteSpace(subType))
            {
                sqlIndicatorValues.Append(
                    "AND iv.[indicatorId] IN (SELECT ix.[id] FROM [data_whs].[indicator] AS ix WHERE ix.[indicatorGroupId] IN (SELECT igx.[id] FROM [data_whs].[indicator_group] AS igx WHERE igx.code LIKE @groupCode)) ");
                sqlParameters.Add(new SqlParameter("@groupCode", subType + "%"));
            }
            var yearPeriodCondition = "";
            if(year.HasValue)
            {
                yearPeriodCondition = year.Value.ToString();
            }
            if(quarter.HasValue)
            {
                var month = quarter.Value * 3;
                yearPeriodCondition = $"{yearPeriodCondition}-{(month > 9 ? "":"0")}{month}";
            }

            if (!string.IsNullOrEmpty(yearPeriodCondition))
            {
                    sqlIndicatorValues.Append(
                        "AND i.ReportingPeriod = @period  "
                    );
                    sqlParameters.Add(new SqlParameter("@period", yearPeriodCondition));
            }

            if (subjectId.HasValue)
            {
                sqlIndicatorValues.Append(
                    "AND i.UndertakingId = @subjectId "
                );
                sqlParameters.Add(new SqlParameter("@subjectId", subjectId.Value));
            }

            if (instanceId.HasValue)
            {
                sqlIndicatorValues.Append(
                    "AND i.Id = @instanceId "
                );
                sqlParameters.Add(new SqlParameter("@instanceId", instanceId.Value));
            }

            sqlIndicatorValues.Append("ORDER BY iv.[indicatorId], r.[Code] ");


            IndicatorQueryData indicatorQueryData = null;
            var indicatorQueryDatas = new List<IndicatorQueryData>();

            var indicatorsMap = indicatorQueryResult.Groups.SelectMany(g => g.Indicators)
                .ToDictionary(i => i.Id, i => i);


            using (var stmt = new SqlCommand(sqlIndicatorValues.ToString(), sqlConnection, sqlTransaction))
            {
                stmt.Parameters.AddRange(sqlParameters.ToArray());
                using (var reader = stmt.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var indId = reader.GetInt32(0);
                        if (indicatorQueryData == null || indicatorQueryData.ResultIndicator.Id != indId)
                        {
                            IndicatorQueryResult.ResultIndicator resultIndicator;
                            if (!indicatorsMap.TryGetValue(indId, out resultIndicator))
                            {
                                continue;
                            }
                            indicatorQueryData = new IndicatorQueryData(resultIndicator);
                            indicatorQueryDatas.Add(indicatorQueryData);
                        }
                        var rCode = reader.GetString(1);
                        indicatorQueryData.AddValue(rCode, reader.GetDecimal(2), reader.GetDecimal(3),
                            reader.GetDecimal(4));
                    }
                }
            }
            indicatorQueryDatas.ForEach(x => x.AggregateIndicators());
        }

        private static HashSet<int> GetApplicableIndicatorIdList(string reportPeriodTypeCode, string reportCode,
            SqlConnection sqlConnection, SqlTransaction sqlTransaction)
        {
            var indicatorIdSet = new HashSet<int>();

            const string sqlIndicatorIds =
                "WITH TMP(indicatorId, reportCode, reports) AS ( " +
                "    SELECT indicatorId, CAST(RTRIM(LTRIM(LEFT(reports, CHARINDEX(',', reports+',')-1))) COLLATE Croatian_CI_AS AS VARCHAR(64)), STUFF(reports, 1, CHARINDEX(',',reports+','), '') " +
                "    FROM data_whs.indicator_specification " +
                "    UNION ALL " +
                "    SELECT indicatorId, CAST(RTRIM(LTRIM(LEFT(reports, CHARINDEX(',', reports+',')-1))) COLLATE Croatian_CI_AS AS VARCHAR(64)), STUFF(reports, 1, CHARINDEX(',',reports+','), '') " +
                "    FROM TMP " +
                "    WHERE reports > '' " +
                ") " +
                "SELECT DISTINCT TMP.indicatorId " +
                "FROM TMP " +
                "INNER JOIN data.report AS r ON r.code = TMP.reportCode " +
                "INNER JOIN data.report_period_type AS rpt ON rpt.id = r.report_period_type_id " +
                "WHERE rpt.period_code = @reportPeriodCode " +
                "and r.code LIKE @reportCode";

            using (var stmt = new SqlCommand(sqlIndicatorIds, sqlConnection, sqlTransaction))
            {
                stmt.Parameters.AddWithValue("@reportPeriodCode", reportPeriodTypeCode);
                stmt.Parameters.AddWithValue("@reportCode", (reportCode ?? "") + "%");
                using (var reader = stmt.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        indicatorIdSet.Add(reader.GetInt32(0));
                    }
                }
            }

            return indicatorIdSet;
        }

        private static IndicatorQueryResult PrepareIndicatorQueryResult(
            string subCode, string reportPeriodTypeCode, string reportCode,
            SqlConnection sqlConnection, SqlTransaction sqlTransaction,
            out Dictionary<int, IndicatorQueryResult.ResultIndicator> indicatorMap)
        {
            //var applicableIndicatorIdList =
                //GetApplicableIndicatorIdList(reportPeriodTypeCode, reportCode, sqlConnection, sqlTransaction);

            const string sqlIndicators =
                "SELECT ig.id AS gId, ig.code AS gCode, ig.name AS gName, ig.ordinal AS gOrdinal, " +
                " i.id AS iId, i.code AS iCode, i.name AS iName, i.ordinal AS iOrdinal, " +
                "i.decimalPlaces AS iDecimalPlaces, i.formattingType AS iFormattingType, i.aggregationType as iAggregationType, " +
                "i.shortName AS shortName " +
                "FROM [data_whs].[indicator_group] AS ig " +
                "INNER JOIN [data_whs].[indicator] AS i ON i.[indicatorGroupId] = ig.[id] " +
                "WHERE ig.code LIKE @code " +
                "AND i.reports = @reportCode " +
                "ORDER BY ig.ordinal, ig.id, i.ordinal, i.id";

            var indicatorQueryResult = new IndicatorQueryResult();

            indicatorMap = new Dictionary<int, IndicatorQueryResult.ResultIndicator>();

            IndicatorQueryResult.ResultGroup indicatorGroup = null;
            using (var stmt = new SqlCommand(sqlIndicators, sqlConnection, sqlTransaction))
            {
                stmt.Parameters.AddWithValue("@code", (subCode ?? "") + "%");
                stmt.Parameters.AddWithValue("@reportCode", reportCode);
                using (var reader = stmt.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var gId = reader.GetInt32(0);
                        if (indicatorGroup == null || gId != indicatorGroup.Id)
                        {
                            indicatorGroup = new IndicatorQueryResult.ResultGroup
                            {
                                Id = gId,
                                Code = reader.GetString(1),
                                Name = reader.GetString(2),
                                Ordinal = reader.GetInt32(3)
                            };
                            indicatorQueryResult.Groups.Add(indicatorGroup);
                        }

                        var indicator = new IndicatorQueryResult.ResultIndicator
                        {
                            Id = reader.GetInt32(4),
                            Code = reader.GetString(5),
                            Name = reader.GetString(11),
                            Ordinal = reader.GetInt32(7),
                            DecimalPlaces = reader.GetInt32(8),
                            FormattingType = reader.GetInt32(9),
                            IsApplicable = true// applicableIndicatorIdList.Contains(reader.GetInt32(4))
                        };
                        indicatorGroup.Indicators.Add(indicator);
                        var aggregationType = reader.GetInt32(10);
                        switch (aggregationType)
                        {
                            case 0:
                                indicator.AggregationType = Indicator.AggregationTypeEnum.WeightedAverage;
                                break;
                            case 1:
                                indicator.AggregationType = Indicator.AggregationTypeEnum.Average;
                                break;
                            case 2:
                                indicator.AggregationType = Indicator.AggregationTypeEnum.Sum;
                                break;
                            case 3:
                                indicator.AggregationType = Indicator.AggregationTypeEnum.Median90ThAverage;
                                break;
                            default:
                                indicator.AggregationType = Indicator.AggregationTypeEnum.WeightedAverage;
                                break;
                        }
                        indicatorMap.Add(indicator.Id, indicator);
                    }
                }
            }
            return indicatorQueryResult;
        }
    }
}