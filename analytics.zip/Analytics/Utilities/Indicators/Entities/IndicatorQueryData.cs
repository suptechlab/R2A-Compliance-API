﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace Analytics.Utilities.Indicators.Entities
{
    public class IndicatorQueryData
    {
        public class IndicatorValue
        {
            public decimal Numerator { get; }
            public decimal Denominator { get; }
            public decimal Value { get; }

            public IndicatorValue(decimal numerator, decimal denominator, decimal value)
            {
                Numerator = numerator;
                Denominator = denominator;
                Value = value;
            }
        }


        public IndicatorQueryResult.ResultIndicator ResultIndicator { get; }
        public Dictionary<string, List<IndicatorValue>> Data { get; } = new Dictionary<string, List<IndicatorValue>>();

        public IndicatorQueryData(IndicatorQueryResult.ResultIndicator resultIndicator)
        {
            ResultIndicator = resultIndicator;
        }

        public void AddValue(string reportCode, decimal numerator, decimal denominator, decimal value)
        {
            List<IndicatorValue> values;
            if (!Data.TryGetValue(reportCode, out values))
            {
                values = new List<IndicatorValue>();
                Data.Add(reportCode, values);
            }
            values.Add(new IndicatorValue(numerator, denominator, value));
        }

        public void AggregateIndicators()
        {
            foreach (var keyValuePair in Data)
            {
                var resultValue = new IndicatorQueryResult.ResultValue {ReportCode = keyValuePair.Key};
                switch (ResultIndicator.AggregationType)
                {
                    case Indicator.AggregationTypeEnum.WeightedAverage:
                        resultValue.Value = keyValuePair.Value.Sum(x => x.Numerator) /
                                            keyValuePair.Value.Sum(x => x.Denominator);
                        break;
                    case Indicator.AggregationTypeEnum.Average:
                        resultValue.Value = keyValuePair.Value.Average(x => x.Value);
                        break;
                    case Indicator.AggregationTypeEnum.Sum:
                        resultValue.Value = keyValuePair.Value.Sum(x => x.Value);
                        break;
                    case Indicator.AggregationTypeEnum.Median90ThAverage:
                        keyValuePair.Value.Sort((a,b) => decimal.Compare(a.Value, b.Value));
                        resultValue.Value = (NthPercentile(keyValuePair.Value, 0.5m) +
                                             NthPercentile(keyValuePair.Value, 0.9m)) / 2m;
                        break;
                    default:
                        throw new ArgumentOutOfRangeException(nameof(ResultIndicator.AggregationType), ResultIndicator.AggregationType, null);
                }
                ResultIndicator.Values.Add(resultValue);
            }
            ResultIndicator.Values.Sort((a,b) => string.CompareOrdinal(a.ReportCode, b.ReportCode));
        }

        public static decimal NthPercentile(List<IndicatorValue> values, decimal percentile)
        {
            var cnt = values.Count;
            switch (cnt)
            {
                case 0:
                    return 0;
                case 1:
                    return values[0].Value;
                default:
                    var idx = decimal.ToInt32(
                        Math.Max(Math.Min(Math.Round(percentile * cnt, MidpointRounding.AwayFromZero), cnt), 1));
                    return values[idx - 1].Value;
            }
        }
    }
}