﻿using System.Collections.Generic;

namespace Analytics.Utilities.Indicators.Entities
{
    public class Indicator
    {
        public enum AggregationTypeEnum
        {
            WeightedAverage = 0,
            Average = 1,
            Sum = 2,
            Median90ThAverage = 3
        }

        public enum FormattingTypeEnum
        {
            Number = 0,
            Percentage = 1,
            Currency = 2
        }

        public int Id { get; }
        public string Code { get; }
        public string Name { get; }
        public string ShortName { get; }
        public AggregationTypeEnum AggregationType { get; }
        public int Ordinal { get; }
        public int DecimalPlaces { get; }
        public FormattingTypeEnum FormattingType { get; }
        public HashSet<string> ReportCodes { get; } = new HashSet<string>();
        public List<IndicatorSpecification> Specifications { get; } = new List<IndicatorSpecification>();

        public Indicator(int id, string code, string name, string shortName, int aggregationType, int ordinal,
            string reportCodes, int decimalPlaces, int formattingType)
        {
            Id = id;
            Code = code;
            Name = name;
            ShortName = shortName;
            Ordinal = ordinal;
            DecimalPlaces = decimalPlaces;

            switch (aggregationType)
            {
                case 0:
                    AggregationType = AggregationTypeEnum.WeightedAverage;
                    break;
                case 1:
                    AggregationType = AggregationTypeEnum.Average;
                    break;
                case 2:
                    AggregationType = AggregationTypeEnum.Sum;
                    break;
                case 3:
                    AggregationType = AggregationTypeEnum.Median90ThAverage;
                    break;
                default:
                    AggregationType = AggregationTypeEnum.WeightedAverage;
                    break;
            }

            switch (formattingType)
            {
                case 0:
                    FormattingType = FormattingTypeEnum.Number;
                    break;
                case 1:
                    FormattingType = FormattingTypeEnum.Percentage;
                    break;
                case 2:
                    FormattingType = FormattingTypeEnum.Currency;
                    break;
                default:
                    FormattingType = FormattingTypeEnum.Number;
                    break;
            }

            if (!string.IsNullOrWhiteSpace(reportCodes))
            {
                foreach (var s in reportCodes.Split(','))
                {
                    if (!string.IsNullOrWhiteSpace(s))
                    {
                        ReportCodes.Add(s.Trim());
                    }
                }
            }
        }
    }
}