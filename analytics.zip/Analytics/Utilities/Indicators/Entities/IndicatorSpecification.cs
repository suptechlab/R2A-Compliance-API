﻿using System.Collections.Generic;

namespace Analytics.Utilities.Indicators.Entities
{
    public class IndicatorSpecification
    {
        public enum StatusEnum
        {
            NeverParsed = 0,
            SyntaxOk = 1,
            ParseError = 2,
            AxisError = 3,
            BaseFormError = 4
        }

        public int Id { get; }
        public string BaseFormCode { get; }
        public string NumeratorFormula { get; }
        public string DenominatorFormula { get; }
        public bool IsDefault { get; }
        public HashSet<string> ReportCodes { get; } = new HashSet<string>();
        public StatusEnum Status { get; }

        public IndicatorSpecification(int id, string baseFormCode, string axisLoop, string numeratorFormula,
            string denominatorFormula, bool isDefault, string excludeDimensionCodes, string reportCodes, int status)
        {
            Id = id;
            BaseFormCode = baseFormCode;
            NumeratorFormula = numeratorFormula;
            DenominatorFormula = denominatorFormula;
            IsDefault = isDefault;
            
            switch (status)
            {
                case 1:
                    Status = StatusEnum.SyntaxOk;
                    break;
                case 2:
                    Status = StatusEnum.ParseError;
                    break;
                default:
                    Status = StatusEnum.NeverParsed;
                    break;
            }
            
            if (!string.IsNullOrWhiteSpace(reportCodes))
            {
                foreach (var s in reportCodes.Split(','))
                {
                    if (!string.IsNullOrWhiteSpace(s))
                    {
                        ReportCodes.Add(s.Trim());
                    }
                }
            }
        }
    }
}