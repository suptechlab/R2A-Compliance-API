﻿using System.Collections.Generic;

namespace Analytics.Utilities.Indicators.Entities
{
    public class IndicatorQueryResult
    {
        public class ResultValue
        {
            public string ReportCode { get; set; }
            public decimal? Value { get; set; }
        }

        public class ResultIndicator
        {
            public int Id { get; set; }
            public string Code { get; set; }
            public string Name { get; set; }
            public bool IsApplicable { get; set; }
            public int Ordinal { get; set; }
            public int DecimalPlaces { get; set; }
            public int FormattingType { get; set; }
            public Indicator.AggregationTypeEnum AggregationType { get; set; }
            public List<ResultValue> Values { get; set; } = new List<ResultValue>();
        }
        
        public class ResultGroup
        {
            public int Id { get; set; }
            public string Code { get; set; }
            public string Name { get; set; }
            public int Ordinal { get; set; }
            public List<ResultIndicator> Indicators { get; set; } = new List<ResultIndicator>();
        }
        
        public List<ResultGroup> Groups { get; set; } = new List<ResultGroup>();
    }
}