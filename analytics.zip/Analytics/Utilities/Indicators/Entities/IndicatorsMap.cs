﻿using System.Collections.Generic;

namespace Analytics.Utilities.Indicators.Entities
{
    public class IndicatorsMap
    {
        public class Dict<T>
        {
            public List<T> List { get; } = new List<T>();
            public IDictionary<int, T> ById { get; } = new Dictionary<int, T>();
            public IDictionary<string, T> ByCode { get; } = new Dictionary<string, T>();
        }    
        
        
        public Dict<IndicatorGroup> Groups = new Dict<IndicatorGroup>();
        public Dict<Indicator> Indicators = new Dict<Indicator>();
    }
}