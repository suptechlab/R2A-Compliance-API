﻿namespace Analytics.Utilities.Indicators.Entities
{
    public class IndicatorValue
    {

        public enum StatusEnum
        {
            Ok = 1, CalcError = 2, DuplicateValue = 3
        }
        public int InstanceId { get; set;  }
        public int IndicatorId { get; set;  }
        public decimal? Value { get; set; } = null;
        public decimal? Numerator { get; set;  } = null;
        public decimal? Denominator { get; set;  } = null;
        public StatusEnum Status { get; set;  }
        public bool IsDefault { get; set; }
    }
}