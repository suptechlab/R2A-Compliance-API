﻿namespace Analytics.Utilities.Indicators.Entities
{
    public class IndicatorGroup
    {
        public int Id { get; }
        public string Code { get; }
        public string Name { get; }
        public int Ordinal { get; }

        public IndicatorsMap.Dict<Indicator> Indicators { get; } = new IndicatorsMap.Dict<Indicator>();


        public IndicatorGroup(int id, string code, string name, int ordinal)
        {
            Id = id;
            Code = code;
            Name = name;
            Ordinal = ordinal;
        }
    }
}