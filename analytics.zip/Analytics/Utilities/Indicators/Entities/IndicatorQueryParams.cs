﻿namespace Analytics.Utilities.Indicators.Entities
{
    public class IndicatorQueryParams
    {
        public string SubCode { get; set; }
        public int Year { get; set; }
        public int? Quarter { get; set; }
        public int? SubjectGroupId { get; set; } = null;
        public int? SubjectId { get; set; }
        public string ReportCode { get; set; } = "FRP";
    }
}