﻿using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Analytics.Utilities.AdHocQuery.Entity;
using BSP.ReportDataConverter.Implementations.Warehouse.Model;

namespace Analytics.Utilities.AdHocQuery
{
    public static class AdHocQuery
    {
        public static AdHocResultSet Query(AdHocQueryParam queryParams, AdHocResultSet adHocResultSet,
            SqlConnection sqlConnection)
        {
            using (var sqlTransaction = sqlConnection.BeginTransaction(IsolationLevel.ReadCommitted))
            {
                adHocResultSet.ResetDimensionMaps();

                QueryModel(queryParams, adHocResultSet, sqlConnection, sqlTransaction);
                sqlTransaction.Commit();
            }

            return adHocResultSet;
        }

        private static void QueryModel(AdHocQueryParam queryParams, AdHocResultSet adHocResultSet,
            SqlConnection sqlConnection, SqlTransaction sqlTransaction)
        {
            AdHocQueryHelper.FilterInstances(queryParams, sqlConnection, sqlTransaction);
            AdHocQueryHelper.BuildInstanceDimensionMap(adHocResultSet, sqlConnection, sqlTransaction);


            if (queryParams.Warehouse == 0)
            {
                BuildAndExecuteIndicatorQuery(
                    adHocResultSet, 
                    sqlConnection,
                    sqlTransaction);
            }
            else
            {
                BuildAndExecuteQuery(
                    adHocResultSet, 
                    sqlConnection, 
                    sqlTransaction);
            }

            AdHocQueryHelper.CleanUpInstances(sqlConnection, sqlTransaction);
        }

        private const string SqlQueryIndicator = @"
                SELECT	indg.name as DIndGrp, 
                        ind.code AS DIndCode, 
                        ind.name AS DIndicator, 
                        indv.value AS MValue, 
                        indv.numerator AS MNominator, 
                        indv.denominator AS MDenominator, 
                        indv.id AS entryId,
                        indv.instanceId AS instanceId
                FROM data_whs.indicator_value AS indv
                INNER JOIN data_whs.indicator AS ind ON ind.id = indv.indicatorId
                INNER JOIN data_whs.indicator_group AS indg ON indg.id = ind.indicatorGroupId
                WHERE indv.status = 1
                AND indv.instanceId IN (SELECT id FROM #INSTANCES)
        ";

        private static void BuildAndExecuteIndicatorQuery(
            AdHocResultSet adHocResultSet,
            SqlConnection sqlConnection,
            SqlTransaction sqlTransaction)
        {
            var dimensionInfos = adHocResultSet.WarehouseInfo.Dimensions.Values.OrderBy(d => d.Index).ToList();

            var metricInfos = adHocResultSet.WarehouseInfo.Metrics.Values.OrderBy(mi => mi.Index).ToList();

            var firstMetricIdx = dimensionInfos.Count;
            var entityIdIdx = firstMetricIdx + metricInfos.Count;
            var instanceIdIdx = entityIdIdx + 1;

            using (var whsCmd = new SqlCommand(SqlQueryIndicator, sqlConnection, sqlTransaction))
            {
                using (var reader = whsCmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var entityId = reader.GetInt32(entityIdIdx);
                        var instanceId = reader.GetInt32(instanceIdIdx);

                        for (var idx = 0; idx < firstMetricIdx; idx++)
                        {
                            adHocResultSet.AddContextDimensionValue(entityId, idx, reader.GetString(idx));
                        }

                        var metricIdx = 0;
                        for (var idx = firstMetricIdx; idx < entityIdIdx; idx++)
                        {
                            if (!reader.IsDBNull(idx))
                            {
                                adHocResultSet.AddEntryMetricValue(
                                    entityId,
                                    instanceId,
                                    entityId,
                                    metricIdx,
                                    reader.GetValue(idx));
                            }

                            metricIdx++;
                        }
                    }
                }
            }
        }

        private static void BuildAndExecuteQuery(
            AdHocResultSet adHocResultSet,
            SqlConnection sqlConnection,
            SqlTransaction sqlTransaction)
        {
            var sb = new StringBuilder();
            sb.Append("SELECT ");
            var dimensionInfos = adHocResultSet.WarehouseInfo.Dimensions.Values.OrderBy(d => d.Index).ToList();

            dimensionInfos.ForEach(di =>
            {
                if (di.DomainInfo.DataType == DataType.Enum)
                {
                    sb.Append("d")
                        .Append(di.Index)
                        .Append(".Name AS ")
                        .Append(di.DbFieldName)
                        .Append(", ");
                }
                else
                {
                    sb.Append("d")
                        .Append(di.Index)
                        .Append(".Value AS ")
                        .Append(di.DbFieldName)
                        .Append(", ");
                }
            });

            var metricInfos = adHocResultSet.WarehouseInfo.Metrics.Values.OrderBy(mi => mi.Index).ToList();
            metricInfos.ForEach(mi =>
            {
                sb.Append("whs.")
                    .Append(mi.DbFieldName)
                    .Append(", ");
            });
            sb.Append(" whs.Id, whs.InstanceId ").Append("FROM ").Append(adHocResultSet.WarehouseInfo.DbTableName).Append(" as whs");
            dimensionInfos.ForEach(di =>
            {
                if (di.DomainInfo.DataType == DataType.Enum)
                {
                    sb.Append(" INNER JOIN data_whs.DomainValue AS d")
                        .Append(di.Index)
                        .Append(" ON d")
                        .Append(di.Index)
                        .Append(".Id = whs.")
                        .Append(di.DbFieldName);
                }
                else
                {
                    sb.Append(" INNER JOIN data_whs.DomainTypedValue AS d")
                        .Append(di.Index)
                        .Append(" ON d")
                        .Append(di.Index)
                        .Append(".Id = whs.")
                        .Append(di.DbFieldName);
                }
            });

            sb.Append(" WHERE whs.InstanceId IN (SELECT id FROM #INSTANCES)");
            var firstMetricIdx = dimensionInfos.Count;
            var entityIdIdx = firstMetricIdx + metricInfos.Count;
            var instanceIdIdx = entityIdIdx + 1;

            using (var whsCmd = new SqlCommand(sb.ToString(), sqlConnection, sqlTransaction))
            {
                using (var reader = whsCmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var entityId = reader.GetInt32(entityIdIdx);
                        var instanceId = reader.GetInt32(instanceIdIdx);

                        for (var idx = 0; idx < firstMetricIdx; idx++)
                        {
                            adHocResultSet.AddContextDimensionValue(entityId, idx, reader.GetString(idx));
                        }

                        var metricIdx = 0;
                        for (var idx = firstMetricIdx; idx < entityIdIdx; idx++)
                        {
                            if (!reader.IsDBNull(idx))
                            {
                                adHocResultSet.AddEntryMetricValue(
                                    entityId,
                                    instanceId,
                                    entityId,
                                    metricIdx,
                                    reader.GetValue(idx));
                            }

                            metricIdx++;
                        }
                    }
                }
            }
        }
    }
}