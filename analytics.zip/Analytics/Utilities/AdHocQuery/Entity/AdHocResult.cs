﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Analytics.Utilities.AdHocQuery.Entity
{
    public class AdHocResult : IDisposable
    {
        public enum WijmoAggregateType
        {
            None = 0,
            Sum = 1,
            Cnt = 2,
            Avg = 3,
            Max = 4,
            Min = 5,
            Rng = 6,
            Std = 7,
            Var = 8,
            StdPop = 9,
            VarPop = 10,
            CntAll = 11,
            First = 12,
            Last = 13

        }

        public enum WijmoDataType
        {
            Object = 0,
            String = 1,
            Number = 2,
            Boolean = 3,
            Date = 4,
            Array = 5
        }

        public static WijmoField GetWijmoField(AdHocResultSet.IDimension dimension)
        {
            var wijmoField = new WijmoField()
            {
                FieldName = dimension.Name,
                FieldBinding = dimension.Binding,
                AggregateType = (int)WijmoAggregateType.None,
                FieldFormat = dimension.FieldFormat,
                WeightField = null,
                IsMeasure = false
            };
            var wijmoDataType = WijmoDataType.String;
            if (dimension.DataType == typeof(int) ||
                dimension.DataType == typeof(decimal) ||
                dimension.DataType == typeof(short) ||
                dimension.DataType == typeof(long) ||
                dimension.DataType == typeof(byte))
            {
                wijmoDataType = WijmoDataType.Number;
                wijmoField.AggregateType = (int) WijmoAggregateType.Sum;
                wijmoField.IsMeasure = true;
            }
            else if (dimension.DataType == typeof(bool))
            {
                wijmoDataType = WijmoDataType.String;
            }
            else if (dimension.DataType == typeof(DateTime))
            {
                wijmoDataType = WijmoDataType.Date;
            }

            wijmoField.DataType = (int)wijmoDataType;
            if (dimension.Values.Count <= 500 && dimension.Values.Count > 0)
            {
                if (wijmoDataType == WijmoDataType.String)
                {
                    wijmoField.UniqueValues =
                        dimension.Values.Select(v => (object)(v == null ? "" : v.ToString())).ToList();
                }
                else
                {
                    wijmoField.UniqueValues = dimension.Values.ToList();
                }
            }
            return wijmoField;
        }

        public class WijmoField
        {
            public string FieldName { get; set; }
            public string FieldBinding { get; set; }
            public List<object> UniqueValues { get; set; }
            public string FieldFormat { get; set; }
            public int AggregateType { get; set; }
            public int DataType { get; set; }
            public string WeightField { get; set; }
            public bool IsMeasure { get; set; }
        }

        public DataTable DataTable { get; set; }
        public List<WijmoField> Fields { get; } = new List<WijmoField>();

        public void Dispose()
        {
            DataTable?.Dispose();
        }
    }
}