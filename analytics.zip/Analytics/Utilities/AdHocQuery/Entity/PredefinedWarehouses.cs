﻿using System.Collections.Generic;
using BSP.ReportDataConverter.Implementations.Warehouse.Model;

namespace Analytics.Utilities.AdHocQuery.Entity
{
    public static class PredefinedWarehouses
    {
        private static WarehouseInfo _indicatorWarehouse;


        public static WarehouseInfo GetIndicatorWarehouse()
        {
            if (_indicatorWarehouse == null)
            {
                _indicatorWarehouse = new WarehouseInfo
                {
                    Id = 0,
                    Code = "INDICATORS",
                    Name = "Indicators",
                    DbTableName = "data_whs.indicator_value"
                };
                
                _indicatorWarehouse.Domains = new Dictionary<string, DomainInfo>
                {
                    {
                        "INDGRP", new DomainInfo
                        {
                            Id = 1,
                            Code = "INDGRP",
                            Name = "Indicator group",
                            DataType = DataType.String,
                            DomainDefaultValueStr = "N/A",
                            DomainDefaulValue = null,
                            DomainValueByCode = null,
                            DomainValues = null
                        }
                    },
                    {
                        "INDCODE", new DomainInfo
                        {
                            Id = 3,
                            Code = "INDCODE",
                            Name = "Indicator Code",
                            DataType = DataType.String,
                            DomainDefaultValueStr = "N/A",
                            DomainDefaulValue = null,
                            DomainValueByCode = null,
                            DomainValues = null
                        }
                    },
                    {
                        "INDICATOR", new DomainInfo
                        {
                            Id = 2,
                            Code = "INDICATOR",
                            Name = "Indicator name",
                            DataType = DataType.String,
                            DomainDefaultValueStr = "N/A",
                            DomainDefaulValue = null,
                            DomainValueByCode = null,
                            DomainValues = null
                        }
                    }
                };

                _indicatorWarehouse.Dimensions = new Dictionary<string, DimensionInfo>
                {
                    {
                        "INDGRP", new DimensionInfo
                        {
                            Id = 1,
                            Code = "INDGRP",
                            Name = "Indicator Group",
                            DbFieldName = "DIndGrp",
                            Index = 0,
                            DomainInfo = _indicatorWarehouse.Domains["INDGRP"]
                        }
                    },
                    {
                        "INDCODE", new DimensionInfo
                        {
                            Id = 3,
                            Code = "INDCODE",
                            Name = "Indicator Code",
                            DbFieldName = "DIndCode",
                            Index = 2,
                            DomainInfo = _indicatorWarehouse.Domains["INDCODE"]
                        }
                    },
                    {
                        "INDICATOR", new DimensionInfo
                        {
                            Id = 2,
                            Code = "INDICATOR",
                            Name = "Indicator Name",
                            DbFieldName = "DIndicator",
                            Index = 1,
                            DomainInfo = _indicatorWarehouse.Domains["INDICATOR"]
                        }
                    }
                };

                _indicatorWarehouse.DimensionValues = new Dictionary<DimensionValue, DimensionValue>();
                _indicatorWarehouse.Metrics = new Dictionary<string, MetricInfo>
                {
                    {
                        "VALUE", new MetricInfo
                        {
                            Id = 1,
                            Code = "VALUE",
                            DataType = DataType.Decimal,
                            DbFieldName = "MValue",
                            Index = 0,
                            DomainInfo = null,
                            Name = "Indicator Value"
                            
                        }
                    },
                    {
                        "NOMINATOR", new MetricInfo
                        {
                            Id = 2,
                            Code = "NOMINATOR",
                            DataType = DataType.Decimal,
                            DbFieldName = "MNominator",
                            Index = 1,
                            DomainInfo = null,
                            Name = "Indicator Numerator"
                            
                        }
                    },
                    {
                        "DENOMINATOR", new MetricInfo
                        {
                            Id = 3,
                            Code = "DENOMINATOR",
                            DataType = DataType.Decimal,
                            DbFieldName = "MDenominator",
                            Index = 2,
                            DomainInfo = null,
                            Name = "Indicator Denominator"
                            
                        }
                    }
                };
            }
            _indicatorWarehouse.DefaultDimensionValueSet = new List<DimensionValue>
            {
                new DimensionValue
                {
                    Id = 1,
                    Value = "N/A",
                    DimensionInfo = _indicatorWarehouse.Dimensions["INDGRP"]
                },
                new DimensionValue
                {
                    Id = 2,
                    Value = "N/A",
                    DimensionInfo = _indicatorWarehouse.Dimensions["INDICATOR"]
                },
                new DimensionValue
                {
                    Id = 3,
                    Value = "N/A",
                    DimensionInfo = _indicatorWarehouse.Dimensions["INDCODE"]
                }
            };
            _indicatorWarehouse.DefaultMetricValueSet = new List<object> {null, null, null};

            return _indicatorWarehouse;
        }
    }
}