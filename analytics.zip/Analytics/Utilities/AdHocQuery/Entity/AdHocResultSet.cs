﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using BSP.ReportDataConverter.Implementations.Warehouse.Model;

namespace Analytics.Utilities.AdHocQuery.Entity
{
    public class AdHocResultSet
    {
        public enum PredefinedDimension
        {
            YearDimension = -5,
            MonthDimension = -1,
            QuarterDimension = -2,
            HalfYearDimension = -3,
            WeekDimension = -4,
            SubmissionDateDimension = -6,
            SubjectDimension = -7,
            SubjectTypeDimension = -8,
            ReportDimension = -9,
            ReportVersionDimension = -20,
            ReportFormDimension = -10,
            ReportFormVersionDimension = -19,
            ColumnCodeDimension = -11,
            ColumnTitleDimension = -12,
            RowCodeDimension = -13,
            RowTitleDimension = -14,
            FieldCodeDimension = -15,
            FieldMetricDimension = -16,
            FinalSubmissionDimension = -17
        }


        public interface IDimensionValue
        {
            IDimension Dimension { get; }
            object Value { get; }
        }

        public interface IDimension
        {
            string Name { get; }
            string Binding { get; }
            int Id { get; }
            Type DataType { get; }
            int Ordinal { get; }
            HashSet<object> Values { get; }
            string FieldFormat { get; }
            void AppendTypeToName();


            IDimensionValue NewValue(object value);
        }

        public interface IResultEntry
        {
            List<object> MetricValues { get; }

            List<IDimensionValue> InstanceDimensionValues { get; }
            List<IDimensionValue> ContextDimensionValues { get; }
        }


        private class AdHocDimension : IDimension
        {
            private class DimensionValue : IDimensionValue
            {
                public IDimension Dimension { get; }
                public object Value { get; }

                public DimensionValue(IDimension dimension, object value)
                {
                    Dimension = dimension;
                    Value = value;
                }
            }

            public string Name { get; private set; }
            public string Binding => Name;
            public int Id { get; }
            public Type DataType { get; }
            public int Ordinal { get; }
            public string FieldFormat { get; }

            private bool _typeAppended;
            public HashSet<object> Values { get; } = new HashSet<object>();


            public static string CleanName(string originalName, string replaceWith = "_")
            {
                var newName = originalName.Trim(Path.GetInvalidFileNameChars());
                newName = newName.Trim();

                //clean bad filename chars  
                foreach (var badChar in Path.GetInvalidFileNameChars())
                {
                    newName = newName.Replace(badChar.ToString(), replaceWith);
                }

                if (string.IsNullOrWhiteSpace(replaceWith) == false)
                {
                    newName = newName.Replace(replaceWith + replaceWith, replaceWith);
                }

                return newName;
            }

            public AdHocDimension(int id, string name, Type dataType, int ordinal, string fieldFormat)
            {
                Id = id;
                Name = CleanName(name);
                DataType = dataType;
                Ordinal = ordinal;
                FieldFormat = fieldFormat;
            }

            public void AppendTypeToName()
            {
                if (_typeAppended) return;

                _typeAppended = true;
                Name = Name + " [" + GetNameForType(DataType) + "]";
            }

            public override bool Equals(object obj)
            {
                var item = obj as AdHocDimension;
                return item != null && Id == item.Id;
            }

            public override int GetHashCode()
            {
                var hash = 13;
                hash = hash * 7 + Id;
                return hash;
            }

            public IDimensionValue NewValue(object value)
            {
                if (DataType == typeof(string) && value == null)
                {
                    value = "";
                }

                Values.Add(value);
                return new DimensionValue(this, value);
            }

            private static string GetNameForType(Type type)
            {
                if (type == typeof(string))
                {
                    return "text";
                }

                if (type == typeof(int))
                {
                    return "integer";
                }

                if (type == typeof(decimal))
                {
                    return "numeric";
                }

                if (type == typeof(DateTime))
                {
                    return "date";
                }

                if (type == typeof(bool))
                {
                    return "bool";
                }

                var s = type.ToString();
                return s.Substring(s.LastIndexOf('.'));
            }
        }


        private class Entry : IResultEntry
        {
            public List<object> MetricValues { get; }

            public List<IDimensionValue> InstanceDimensionValues { get; }
            public List<IDimensionValue> ContextDimensionValues { get; }

            public Entry(
                List<object> metricValues,
                List<IDimensionValue> instanceDimensionValues,
                List<IDimensionValue> explciDimensionValues
            )
            {
                MetricValues = metricValues;
                InstanceDimensionValues = instanceDimensionValues;
                ContextDimensionValues = explciDimensionValues;
            }
        }

        public readonly WarehouseInfo WarehouseInfo;
        private readonly int _metricCount;
        private readonly int _dimensionCount;
        private readonly List<AdHocDimension> _metricDimensionList;

        private readonly Dictionary<int, IDimension> _dimensionMap = new Dictionary<int, IDimension>();

        private readonly Dictionary<int, List<IDimensionValue>> _instanceDimensionMap =
            new Dictionary<int, List<IDimensionValue>>();

        private readonly Dictionary<int, List<IDimensionValue>> _contextDimensionMap =
            new Dictionary<int, List<IDimensionValue>>();

        public AdHocResultSet(WarehouseInfo warehouseInfo)
        {
            WarehouseInfo = warehouseInfo;
            _dimensionCount = 0;
            _dimensionCount = warehouseInfo.Dimensions.Count;
            _metricCount = warehouseInfo.Metrics.Count;
            _metricDimensionList = new List<AdHocDimension>();
            WarehouseInfo.Metrics.Values.OrderBy(mInfo => mInfo.Id).ToList().ForEach(mInfo =>
            {
                _metricDimensionList.Add(
                    new AdHocDimension(
                        mInfo.Index,
                        mInfo.Name,
                        DataTypeUtils.ToType(mInfo.DataType),
                        mInfo.Index,
                        DataTypeUtils.ToFieldFormat(mInfo.DataType)
                    )
                );
            });
        }

        public Dictionary<int, IResultEntry> Data { get; } = new Dictionary<int, IResultEntry>();

        public IDimensionValue GetDimensionValue(int dimensionIdx, object value)
        {
            IDimension dimension;
            if (!_dimensionMap.TryGetValue(dimensionIdx, out dimension))
            {
                if (dimensionIdx < 0 || dimensionIdx >= _dimensionCount)
                {
                    throw new ArgumentOutOfRangeException(nameof(dimensionIdx), dimensionIdx, null);
                }

                var dimensionInfo = WarehouseInfo.DefaultDimensionValueSet[dimensionIdx].DimensionInfo;

                dimension = new AdHocDimension(
                    dimensionIdx,
                    dimensionInfo.Name,
                    typeof(string),
                    _dimensionMap.Count,
                    null);
                _dimensionMap.Add(dimensionIdx, dimension);
            }

            return dimension.NewValue(value);
        }


        private IDimensionValue GetPredefinedDimensionValue(PredefinedDimension predefinedDimension, object value)
        {
            IDimension dimension;
            if (!_dimensionMap.TryGetValue((int) predefinedDimension, out dimension))
            {
                switch (predefinedDimension)
                {
                    case PredefinedDimension.YearDimension:
                        dimension = new AdHocDimension((int) predefinedDimension, "Reporting Year", typeof(string),
                            _dimensionMap.Count, null);
                        break;
                    case PredefinedDimension.MonthDimension:
                        dimension = new AdHocDimension((int) predefinedDimension, "Reporting Month", typeof(string),
                            _dimensionMap.Count, null);
                        break;
                    case PredefinedDimension.QuarterDimension:
                        dimension = new AdHocDimension((int) predefinedDimension, "Reporting Quarter", typeof(string),
                            _dimensionMap.Count, null);
                        break;
                    case PredefinedDimension.HalfYearDimension:
                        dimension = new AdHocDimension((int) predefinedDimension, "Reporting Half-Year", typeof(string),
                            _dimensionMap.Count, null);
                        break;
                    case PredefinedDimension.WeekDimension:
                        dimension = new AdHocDimension((int) predefinedDimension, "Reporting Week", typeof(string),
                            _dimensionMap.Count, null);
                        break;
                    case PredefinedDimension.SubmissionDateDimension:
                        dimension = new AdHocDimension((int) predefinedDimension, "Submission Date", typeof(DateTime),
                            _dimensionMap.Count, "dd.MM.yyyy HH:mm");
                        break;
                    case PredefinedDimension.SubjectDimension:
                        dimension = new AdHocDimension((int) predefinedDimension, "Bank name", typeof(string),
                            _dimensionMap.Count, null);
                        break;
                    case PredefinedDimension.SubjectTypeDimension:
                        dimension = new AdHocDimension((int) predefinedDimension, "Bank Type", typeof(string),
                            _dimensionMap.Count, null);
                        break;
                    case PredefinedDimension.ReportDimension:
                        dimension = new AdHocDimension((int) predefinedDimension, "Report Code", typeof(string),
                            _dimensionMap.Count, null);
                        break;
                    case PredefinedDimension.ReportVersionDimension:
                        dimension = new AdHocDimension((int) predefinedDimension, "Report Version", typeof(string),
                            _dimensionMap.Count, null);
                        break;
                    case PredefinedDimension.ReportFormDimension:
                        dimension = new AdHocDimension((int) predefinedDimension, "Report Form Code", typeof(string),
                            _dimensionMap.Count, null);
                        break;
                    case PredefinedDimension.ReportFormVersionDimension:
                        dimension = new AdHocDimension((int) predefinedDimension, "Report Form Code and Version ",
                            typeof(string),
                            _dimensionMap.Count, null);
                        break;
                    case PredefinedDimension.ColumnCodeDimension:
                        dimension = new AdHocDimension((int) predefinedDimension, "Column Code", typeof(string),
                            _dimensionMap.Count, null);
                        break;
                    case PredefinedDimension.ColumnTitleDimension:
                        dimension = new AdHocDimension((int) predefinedDimension, "Column Title", typeof(string),
                            _dimensionMap.Count, null);
                        break;
                    case PredefinedDimension.RowCodeDimension:
                        dimension = new AdHocDimension((int) predefinedDimension, "Row Code", typeof(string),
                            _dimensionMap.Count, null);
                        break;
                    case PredefinedDimension.RowTitleDimension:
                        dimension = new AdHocDimension((int) predefinedDimension, "Row Title", typeof(string),
                            _dimensionMap.Count, null);
                        break;
                    case PredefinedDimension.FieldCodeDimension:
                        dimension = new AdHocDimension((int) predefinedDimension, "Field Code", typeof(string),
                            _dimensionMap.Count, null);
                        break;
                    case PredefinedDimension.FieldMetricDimension:
                        dimension = new AdHocDimension((int) predefinedDimension, "Field Metric", typeof(string),
                            _dimensionMap.Count, null);
                        break;
                    case PredefinedDimension.FinalSubmissionDimension:
                        dimension = new AdHocDimension((int) predefinedDimension, "Final Version", typeof(bool),
                            _dimensionMap.Count, null);
                        break;
                    default:
                        throw new ArgumentOutOfRangeException(nameof(predefinedDimension), predefinedDimension, null);
                }

                _dimensionMap.Add(dimension.Id, dimension);
            }

            return dimension.NewValue(value);
        }

        private void AddDimensionValue(int id, IDimensionValue dimensionValue,
            IDictionary<int, List<IDimensionValue>> dimensionMap)
        {
            List<IDimensionValue> valueList;
            if (!dimensionMap.TryGetValue(id, out valueList))
            {
                valueList = new List<IDimensionValue>();
                dimensionMap.Add(id, valueList);
            }

            valueList.Add(dimensionValue);
        }

        public void AddInstanceDimensionValue(int instanceId, PredefinedDimension predefinedDimension, object value)
        {
            AddDimensionValue(instanceId, GetPredefinedDimensionValue(predefinedDimension, value),
                _instanceDimensionMap);
        }


        public void AddContextDimensionValue(int contextId, int dimensionIdx, object value)
        {
            AddDimensionValue(contextId, GetDimensionValue(dimensionIdx, value), _contextDimensionMap);
        }


        public void ResetDimensionMaps()
        {
            _instanceDimensionMap.Clear();
            _contextDimensionMap.Clear();
        }


        public void AddEntryMetricValue(int entryId, int instanceId, int contextId, int metricIdx, object value)
        {
            _instanceDimensionMap.TryGetValue(instanceId, out var instaceDimensionValues);

            _contextDimensionMap.TryGetValue(contextId, out var contextDimensionValues);

            if (!Data.TryGetValue(entryId, out var entry))
            {
                entry = new Entry(
                    new List<object>(WarehouseInfo.DefaultMetricValueSet),
                    instaceDimensionValues,
                    contextDimensionValues
                );
                Data.Add(entryId, entry);
            }

            if (metricIdx < 0 && metricIdx >= _metricCount)
            {
                throw new ArgumentOutOfRangeException(nameof(metricIdx));
            }

            entry.MetricValues[metricIdx] = value;
        }

        public AdHocResult GenerateResult()
        {
            var adHocResult = new AdHocResult {DataTable = GenerateDataTable()};
            _dimensionMap.Values.OrderBy(d => d.Ordinal).ToList().ForEach(d =>
            {
                adHocResult.Fields.Add(AdHocResult.GetWijmoField(d));
            });

            _metricDimensionList.ForEach(mDim =>
            {
                adHocResult.Fields.Add(AdHocResult.GetWijmoField(
                    mDim
                ));
            });

            return adHocResult;
        }

        private DataTable GenerateDataTable()
        {
            var dataTable = new DataTable();

            _dimensionMap.Values.OrderBy(d => d.Ordinal).ToList().ForEach(d =>
            {
                dataTable.Columns.Add(
                    new DataColumn(d.Binding, d.DataType == typeof(bool) ? typeof(string) : d.DataType)
                    {
                        AllowDBNull = true
                    });
            });
            
            _metricDimensionList.ForEach(mDim =>
            {
                dataTable.Columns.Add(
                    new DataColumn(mDim.Binding, mDim.DataType == typeof(bool) ? typeof(string) : mDim.DataType)
                    {
                        AllowDBNull = true
                    });
            });

            var firstMetricIdx = _dimensionMap.Count;
            
            foreach (var entry in Data.Values)
            {
                
                var dataRow = dataTable.NewRow();
                var idx = firstMetricIdx;
                entry.MetricValues.ForEach(v => { dataRow[idx++] = v ?? DBNull.Value; });
                
                entry.InstanceDimensionValues.ForEach(dv => { dataRow[dv.Dimension.Ordinal] = dv.Value ?? DBNull.Value; });
                entry.ContextDimensionValues.ForEach(dv => { dataRow[dv.Dimension.Ordinal] = dv.Value ?? DBNull.Value; });
                
                dataTable.Rows.Add(dataRow);
            }

            return dataTable;
        }
    }
}