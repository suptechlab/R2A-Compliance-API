﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Analytics.Utilities.AdHocQuery.Entity
{
    public class AdHocQueryParam
    {
        public List<YearPeriod> Periods { get; set; }
        public List<int> Subjects { get; set; }
        public int Warehouse { get; set; }
    }

    public class YearPeriod
    {
        public int Year { get; set; }
        public int? Period { get; set; }
    }
}
