﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Analytics.Utilities.AdHocQuery.Entity;

namespace Analytics.Utilities.AdHocQuery
{
	public class AdHocQueryHelper
	{
		private const string SqlCleanUp =
			@"DROP TABLE #INSTANCES;";

		public static void CleanUpInstances(SqlConnection sqlConnection, SqlTransaction sqlTransaction)
		{
			using (var stmt = new SqlCommand(SqlCleanUp, sqlConnection, sqlTransaction))
			{
				stmt.ExecuteNonQuery();
			}
		}

		public static void FilterInstances(AdHocQueryParam queryParams, SqlConnection sqlConnection, SqlTransaction sqlTransaction)
		{
			var preSql = new StringBuilder();

			var sql = new StringBuilder();
			sql.Append("INSERT INTO #INSTANCES SELECT i.Id FROM [dbo].[SubmittedReport] AS i ");
			sql.Append(
				"INNER JOIN [dbo].[Report] AS r ON r.Id = i.ReportId ");
			sql.Append("WHERE 1=1 ");

			var sqlParams = new List<SqlParameter>();

			if (queryParams.Periods.Count > 0)
			{
				var cnt = 1;
				sql.Append("AND (1=0 ");
				queryParams.Periods.Select(p =>
					$"{p.Year}" + (p.Period.HasValue
						? (p.Period >= 10 ? $"-{p.Period.Value}" : $"-0{p.Period.Value}")
						: "")).ToList().ForEach(pCond =>
				{
					cnt++;
					sql.Append($"OR i.ReportingPeriod=@reportPeriod{cnt} ");
					sqlParams.Add(new SqlParameter($"@reportPeriod{cnt}", pCond));
				});
				sql.Append(") ");
			}


			if (queryParams.Subjects?.Count > 0)
			{
				preSql.Append("DECLARE @Undertakings TABLE (id int);");
				queryParams.Subjects.ForEach(u => { preSql.Append($"INSERT INTO @Undertakings VALUES({u});"); });
				sql.Append("AND i.UndertakingId IN (SELECT u.id FROM @Undertakings AS u) ");
			}
			sql.Append(";");
			preSql.Append(sql);

			using (var sqlCommand = new SqlCommand("CREATE TABLE #INSTANCES (id INT);", sqlConnection, sqlTransaction))
			{
				sqlCommand.ExecuteNonQuery();
			}

			using (var sqlCommand = new SqlCommand(preSql + "SELECT id FROM #INSTANCES;", sqlConnection,
				sqlTransaction))
			{
				sqlCommand.Parameters.AddRange(sqlParams.ToArray());
				sqlCommand.ExecuteNonQuery();
			}
		}

		public static void BuildInstanceDimensionMap(AdHocResultSet adHocResultSet, 
			SqlConnection sqlConnection,
			SqlTransaction sqlTransaction)
		{
			var sqlGetInstanceData =
				$@"SELECT i.[Id], i.[ReportingPeriod], i.[SubmissionTime], r.[RecurrenceType], s.[Title] as subjectName, sg.[Title] as subjectType,
				r.[Code], rv.[Version] 
				FROM #INSTANCES AS ii
				INNER JOIN [dbo].[SubmittedReport] AS i ON i.[Id] = ii.[id]
				INNER JOIN [bsp].[Bank] AS s ON s.[Id] = i.[UndertakingId]
				INNER JOIN [bsp].[BankType] AS sg ON sg.[Id] = s.[BankTypeId]
				INNER JOIN [dbo].[Report] AS r ON r.[Id] = i.[ReportId]
				INNER JOIN [dbo].[ReportVersion] AS rv ON rv.[Id] = i.[ReportVersionId]
			";

			using (var stmt = new SqlCommand(sqlGetInstanceData, sqlConnection, sqlTransaction))
			{
				using (var reader = stmt.ExecuteReader())
				{
					while (reader.Read())
					{
						var insId = reader.GetInt32(0);
						int? reportYear = null;
						int? reportPeriod = null;
						
						var reportingPeriod = reader.GetString(1);
						if (reportingPeriod != null)
						{
							var strings = reportingPeriod.Split('-');
							if (int.TryParse(strings[0], out var rYear))
							{
								reportYear = rYear;
							}

							if (strings.Length == 2)
							{
								if (int.TryParse(strings[1], out var rMonth))
								{
									reportPeriod = rMonth;
								}
							}
						} 
						var submissionDate = reader.GetDateTime(2);
						var periodType = reader.GetString(3);
						var subjectName = reader.GetString(4);
						var subjectType = reader.IsDBNull(5) ? "" : reader.GetString(5);
						var final = true;
						var reportCode = reader.GetString(6);
						var rVersion = reader.GetString(7);

						var reportVersion = (string.IsNullOrWhiteSpace(rVersion)
												? "0"
												: rVersion.Trim());
						

						if (reportYear.HasValue)
						{
							adHocResultSet.AddInstanceDimensionValue(insId,
								AdHocResultSet.PredefinedDimension.YearDimension, reportYear.Value.ToString());
						}
						else
						{
							adHocResultSet.AddInstanceDimensionValue(insId,
								AdHocResultSet.PredefinedDimension.YearDimension, "N/A");
						}

						if (reportPeriod.HasValue)
						{
							switch (periodType)
							{
								case "Q":
									adHocResultSet.AddInstanceDimensionValue(insId,
										AdHocResultSet.PredefinedDimension.QuarterDimension, "Q" + reportPeriod.Value);
									break;
								case "M":
									adHocResultSet.AddInstanceDimensionValue(insId,
										AdHocResultSet.PredefinedDimension.MonthDimension, "M" + reportPeriod.Value.ToString("D2"));
									break;
								case "S":
									adHocResultSet.AddInstanceDimensionValue(insId,
										AdHocResultSet.PredefinedDimension.HalfYearDimension, "S" + reportPeriod.Value);
									break;
								case "W":
									adHocResultSet.AddInstanceDimensionValue(insId,
										AdHocResultSet.PredefinedDimension.WeekDimension, "W" + reportPeriod.Value.ToString("D2"));
									break;
							}
						}

						adHocResultSet.AddInstanceDimensionValue(insId,
							AdHocResultSet.PredefinedDimension.SubmissionDateDimension,
							submissionDate != null ? submissionDate : DateTime.MinValue);
						//adHocResultSet.AddInstanceDimensionValue(insId,
						//	AdHocResultSet.PredefinedDimension.FinalSubmissionDimension, final);
						adHocResultSet.AddInstanceDimensionValue(insId,
							AdHocResultSet.PredefinedDimension.SubjectDimension, subjectName ?? string.Empty);
						adHocResultSet.AddInstanceDimensionValue(insId,
							AdHocResultSet.PredefinedDimension.SubjectTypeDimension, subjectType ?? string.Empty);
						adHocResultSet.AddInstanceDimensionValue(insId,
							AdHocResultSet.PredefinedDimension.ReportDimension, reportCode ?? string.Empty);
						adHocResultSet.AddInstanceDimensionValue(insId,
							AdHocResultSet.PredefinedDimension.ReportVersionDimension, reportVersion ?? string.Empty);
					}
				}
			}
		}
	}
}