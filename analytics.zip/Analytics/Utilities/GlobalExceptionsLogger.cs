﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using NLog;

namespace Analytics.Utilities
{
    public class GlobalExceptionsLogger
    {
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();
        public async Task Invoke(HttpContext context, Func<Task> next)
        {
            // Do something before
            try
            {
                await next();
            }
            // Do something after
            catch (Exception e)
            {
                Logger.Error(e);
                throw;
            }
        }
    }
}
