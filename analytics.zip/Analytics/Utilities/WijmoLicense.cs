﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Analytics.Utilities
{
    public class WijmoLicense
    {
        public string Key { get; set; }
    }
}
